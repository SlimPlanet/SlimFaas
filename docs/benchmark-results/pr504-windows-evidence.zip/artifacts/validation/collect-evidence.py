"""Extract every planned attempt and archive the original JSON/log evidence."""
import gzip
import hashlib
import json
import re
import base64
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / 'artifacts'
OUT = ROOT / 'docs/benchmark-results'
raw = {}

def read(path):
    blob = path.read_bytes()
    key = str(path.relative_to(ROOT)).replace('\\','/')
    raw[key] = {'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'mtime_ns':path.stat().st_mtime_ns,
                'base64':base64.b64encode(blob).decode('ascii'),
                'text':blob.decode('utf-8-sig',errors='replace')}
    return json.loads(raw[key]['text'])

def sampled_counters(samples):
    if len(samples)<2:
        return {'sampling_window':'insufficient samples'}
    first,last=samples[0],samples[-1]
    gc={}
    for generation in range(3):
        key=f'dotnet_collection_count_total{{generation="{generation}"}}'
        gc[str(generation)]=sum(row.get(key,0) for row in last['runtime_counters_by_node'])-sum(row.get(key,0) for row in first['runtime_counters_by_node'])
    io={}
    before=first.get('windows_io_by_node') or []
    after=last.get('windows_io_by_node') or []
    if {row['pid'] for row in before}=={row['pid'] for row in after}:
        for key in ('read_operations','write_operations','other_operations','read_bytes','write_bytes','other_bytes'):
            io[key]=sum(row[key] for row in after)-sum(row[key] for row in before)
    return {'sample_count':len(samples),'observed_gc_collections':gc,'observed_windows_io':io,
            'note':'First-to-last sampled window only; Windows I/O includes network and cached transfers, not physical disk bytes.'}

def correlations(attempt,samples,summary):
    receipts=[json.loads(line) for line in (attempt/'acceptances.jsonl').read_text().splitlines()] if (attempt/'acceptances.jsonl').exists() else []
    deliveries=[json.loads(line) for line in (attempt/'deliveries.jsonl').read_text().splitlines()] if (attempt/'deliveries.jsonl').exists() else []
    logs=(attempt/'local.log').read_text(encoding='utf-8',errors='replace').splitlines()
    file_events=json.loads((attempt/'file-observations.json').read_text())['samples']
    files_by_queue={}
    for line in logs:
        found=re.search(r'MetaKey=data:file:(sf-internal-[0-9a-f]+-internal):meta Tags=.*?QueueElementId=([0-9a-f-]+)',line,re.I)
        if found:
            file_id,queue_id=found.groups()
            files_by_queue.setdefault(queue_id,set()).add(file_id)
    accepted=[row for row in receipts if row.get('status')==202]
    start=min((row['sent_ns'] for row in receipts),default=0)
    end=(attempt/'summary.json').stat().st_mtime_ns if (attempt/'summary.json').exists() else max((row['time_ns'] for row in samples),default=0)
    leadership=[]; body_errors=[]; undated=[]
    for line in logs:
        leader=re.search(r'leader.*(?:chang|elect)|(?:chang|elect).*leader|consensus cannot be reached|quorum',line,re.I)
        body_error='FileNotFoundException' in line or 'Unable to load offloaded body' in line
        if not leader and not body_error:
            continue
        timestamp=re.search(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z',line)
        if not timestamp:
            undated.append(line)
            continue
        ns=int(datetime.fromisoformat(timestamp.group()).timestamp()*1e9)
        if start<=ns<=end:
            if leader: leadership.append(line)
            if body_error: body_errors.append(line)
    wanted=set((summary or {}).get('missing_ids',[]))
    wanted.update((summary or {}).get('duplicates',{}))
    for field in ('http_errors','body_mismatches','queue_id_mismatches'):
        wanted.update(row['request_id'] for row in (summary or {}).get(field,[]))
    if accepted:
        wanted.add(accepted[0]['request_id'])
    examples=[]
    for receipt in receipts:
        if receipt['request_id'] not in wanted:
            continue
        matching_deliveries=[row for row in deliveries if row['request_id']==receipt['request_id']]
        queue=receipt.get('element_id') or next((row['element_id'] for row in matching_deliveries),None)
        files=sorted(files_by_queue.get(queue,set()))
        encoded=[base64.urlsafe_b64encode(file.encode()).decode().rstrip('=') for file in files]
        examples.append({'receipt':receipt,'resolved_queue_id':queue,'file_ids':files,
            'deliveries':matching_deliveries,
            'file_observations':[row for row in file_events if row['file_id'] in files],
            'log_lines':[line for line in logs if (queue and queue in line) or receipt['request_id'] in line or
                any(file in line for file in files+encoded)]})
    return {'window_start_ns':start,'window_end_ns':end,
        'accepted_with_queue_to_offload_mapping':sum(bool(files_by_queue.get(row.get('element_id'))) for row in accepted),
        'accepted_with_positive_body_file_poll':sum(any(event['event']=='appeared' and event['file_id'] in files_by_queue.get(row.get('element_id'),set()) for event in file_events) for row in accepted),
        'leadership_or_quorum_lines_in_window':leadership,'body_read_error_lines_in_window':body_errors,
        'undated_reliability_lines':undated,'examples':examples,
        'note':'Window covers first send through summary write, before supervisor shutdown. Metadata tags join queue IDs to offload IDs; file polling gives positive observations, not deletion syscall timestamps. Startup elections and shutdown errors are outside this window when timestamped.'}

campaigns={}
for name,expected in (('pr504-files-streams',8),('pr504-files-fixed',4),('pr504-files-final',4),('pr504-sets-streams',8),('pr504-sets-headroom',8)):
    root=ART/name
    manifest=read(root/'manifest.json')
    attempts=sorted(root.glob('round-*'))
    assert len(attempts)==expected,(name,len(attempts))
    rows=[]
    for attempt in attempts:
        row={'attempt':attempt.name,'complete':(attempt/'complete.json').exists(),
             'failure':read(attempt/'failed.json') if (attempt/'failed.json').exists() else None,
             'shutdown':read(attempt/'shutdown.json') if (attempt/'shutdown.json').exists() else None}
        for path in sorted(attempt.rglob('*.json')):
            data=read(path)
            relative=str(path.relative_to(attempt)).replace('\\','/')
            if relative.startswith('verified-files/') and path.stem in ('reused','unique'):
                row[relative]={'summary':data['summary'],'sampled_counters':sampled_counters(data['resources'])}
            elif relative in ('slimdata-set/summary.json','streams/summary.json'):
                row[relative]=data
            elif relative in ('slimdata-set/resources.json','streams/resources.json'):
                row[relative]=sampled_counters(data['samples'])
        rows.append(row)
    campaigns[name]={'manifest':manifest,'attempts':rows}

traces=[]
trace_root=ART/'pr504-async-headroom'
plan=read(trace_root/'plan.json')
for attempt in sorted(trace_root.glob('round-*')):
    row={'attempt':attempt.name,'manifest':read(attempt/'manifest.json') if (attempt/'manifest.json').exists() else None,
         'not_started':read(attempt/'not-started.json') if (attempt/'not-started.json').exists() else None,
         'summary':read(attempt/'summary.json') if (attempt/'summary.json').exists() else None,
         'shutdown':read(attempt/'shutdown.json') if (attempt/'shutdown.json').exists() else None}
    samples=read(attempt/'resources.json') if (attempt/'resources.json').exists() and (attempt/'resources.json').stat().st_size else []
    row['sampled_counters']=sampled_counters(samples)
    row['minimum_sampled_free_disk_bytes']=min((item['free_disk_bytes'] for item in samples),default=None)
    row['correlation']=correlations(attempt,samples,row['summary']) if (attempt/'file-observations.json').exists() else None
    traces.append(row)
assert len(traces)==12,len(traces)
demo=read(ART/'pr504-demo-final/summary.json')
failed_demo=read(ART/'pr504-demo/summary.json')
publications={name:read(ART/name/'source.json') for name in ('runtime-filefix','runtime-filefix-final')}
set_headroom_plan=read(ART/'validation/sets-headroom-plan.json')

roots=[ART/name for name in campaigns]+[trace_root,ART/'pr504-async',ART/'pr504-demo',ART/'pr504-demo-final']
for root in roots:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or 'state' in path.relative_to(root).parts:
            continue
        if path.suffix not in ('.json','.jsonl','.log','.py','.yaml'):
            continue
        blob=path.read_bytes()
        raw[str(path.relative_to(ROOT)).replace('\\','/')]={'sha256':hashlib.sha256(blob).hexdigest(),'mtime_ns':path.stat().st_mtime_ns,
            'base64':base64.b64encode(blob).decode('ascii'),
            'bytes':len(blob),'text':blob.decode('utf-8-sig',errors='replace')}
for pattern in ('publish-*.log','full-tests*.log','file-*.log','compressed-*.json','smoke-real-demo.py',
                'async-round-*.log','async-headroom-round-*.log','sets-streams-campaign.log','sets-headroom-campaign.log','files-*-campaign.log','demo-final.log','demo-prebuilt-final.log','build-fibonacci*-final.log',
                'run-remaining.ps1','run-async-headroom.ps1','run-sets-headroom.ps1','publish-final.ps1'):
    for path in sorted((ART/'validation').glob(pattern)):
        blob=path.read_bytes()
        raw[str(path.relative_to(ROOT)).replace('\\','/')]={'sha256':hashlib.sha256(blob).hexdigest(),'mtime_ns':path.stat().st_mtime_ns,
            'base64':base64.b64encode(blob).decode('ascii'),
            'bytes':len(blob),'text':blob.decode('utf-8-sig',errors='replace')}
for name in ('trace-async-offload.py','slimfaas-zlinq-benchmark.py','summarize-collection-probe.py'):
    path=ROOT/'.bin'/name
    blob=path.read_bytes()
    raw['.bin/'+name]={'sha256':hashlib.sha256(blob).hexdigest(),'mtime_ns':path.stat().st_mtime_ns,'bytes':len(blob),'base64':base64.b64encode(blob).decode('ascii'),'text':blob.decode('utf-8')}
path=Path(__file__)
blob=path.read_bytes()
raw[str(path.relative_to(ROOT)).replace('\\','/')]={'sha256':hashlib.sha256(blob).hexdigest(),'mtime_ns':path.stat().st_mtime_ns,
    'base64':base64.b64encode(blob).decode('ascii'),
    'bytes':len(blob),'text':blob.decode('utf-8')}
archive=OUT/'pr504-windows-evidence.json.gz'
with gzip.open(archive,'wt',encoding='utf-8',compresslevel=9) as target:
    json.dump(raw,target,separators=(',',':'))
summary={'campaigns':campaigns,'set_headroom_plan':set_headroom_plan,'async_plan':plan,'async_traces':traces,'interrupted_async_experiment':read(ART/'pr504-async/interrupted.json'),'demo':demo,'unprepared_demo_attempt':failed_demo,'publications':publications,
    'raw_evidence':{'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                    'file_count':len(raw),'note':'All original attempt JSON, receipts, logs and helper sources; persistent binary state remains under artifacts/pr504-async locally.'}}
(OUT/'pr504-windows-local.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
lines=['# PR 504 Windows local runtime attempts','',
       'Every fixed planned attempt is included. Runtime-node CPU/RSS exclude the driver, target and supervisor. '
       'GC and I/O deltas cover the first-to-last sampled window. Windows process I/O includes cached and network transfers; it is not physical disk traffic. '
       'Failed file attempts have invalid rates because workers stop on their first error. Two repetitions give limited timing precision.','',
       '[Full summaries and manifests](pr504-windows-local.json) · [Original evidence, receipts, logs and sources](pr504-windows-evidence.json.gz)','',
       '## Byte-verified files','',
       '| Campaign | Attempt | IDs | Result | Verified cycles | Cycles/s | Upload p95/p99 ms | Download p95/p99 ms | CPU ms/cycle | Peak RSS MiB | GC 0/1/2 | Sampled I/O MiB read/write |',
       '|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
def gc_io(stats):
    if 'observed_gc_collections' not in stats:
        return 'unavailable','unavailable'
    gc=stats.get('observed_gc_collections',{})
    io=stats.get('observed_windows_io',{})
    return ('/'.join(str(int(gc.get(str(g),0))) for g in range(3)),
            f"{io['read_bytes']/1048576:.1f}/{io['write_bytes']/1048576:.1f}" if io else 'unavailable')
for name,campaign in campaigns.items():
    for row in campaign['attempts']:
        for mode in ('reused','unique'):
            case=row.get('verified-files/'+mode+'.json')
            if case is None:
                continue
            value=case['summary']
            valid=not value['errors'] and not value['sampling_errors'] and value['completed']>0
            rate=f"{value['rate']:.2f}" if valid else 'invalid'
            gc,io=gc_io(case['sampled_counters'])
            lines.append(f"| {name} | {row['attempt']} | {mode} | {'pass' if valid else 'FAIL'} | {value['completed']} | {rate} | "
                         f"{value['upload_ms']['p95']:.2f}/{value['upload_ms']['p99']:.2f} | "
                         f"{value['download_ms']['p95']:.2f}/{value['download_ms']['p99']:.2f} | "
                         f"{value['cpu_seconds']*1000/max(1,value['completed']):.2f} | {value['peak_rss_bytes']/1048576:.1f} | {gc} | {io} |")
lines += ['', '## Sets (4 KiB, 16 workers, 60 seconds)', '',
          '| Campaign | Attempt | Completed | Failed | Op/s | p95/p99 ms | CPU ms/op | Peak RSS MiB | GC 0/1/2 | Sampled I/O MiB read/write |',
          '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for name,row in ((name,row) for name in ('pr504-sets-streams','pr504-sets-headroom') for row in campaigns[name]['attempts']):
    value=row.get('slimdata-set/summary.json')
    if value is None:
        lines.append(f"| {name} | {row['attempt']} | not completed | | | | | | | |")
        continue
    load=value['load']; latency=load['Operations'][0]
    gc,io=gc_io(row['slimdata-set/resources.json'])
    lines.append(f"| {name} | {row['attempt']} | {load['Completed']} | {load['Failed']} | {load['Rate']:.2f} | "
                 f"{latency['P95Milliseconds']:.2f}/{latency['P99Milliseconds']:.2f} | {value['cpu_ms_per_operation']:.2f} | "
                 f"{value['peak_rss_bytes']/1048576:.1f} | {gc} | {io} |")
lines += ['', '## Streams (200 publications, 4 KiB, 16 publishers)', '',
          'Append latency measures HTTP acceptance. Target arrival latency measures delivery from the sender timestamp; it includes the dispatcher backlog. '
          'Successful bursts require 200 unique target IDs, no duplicates and committed progress with zero lag/pending.', '',
          '| Attempt | Unique/duplicates | Lag/pending | Publications/s | Append p95/p99 ms | Delivery p95/p99 ms | CPU ms/publication | Peak RSS MiB | GC 0/1/2 | Sampled I/O MiB read/write |',
          '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for row in campaigns['pr504-sets-streams']['attempts']:
    value=row.get('streams/summary.json')
    if value is None:
        lines.append(f"| {row['attempt']} | not completed | | | | | | | | |")
        continue
    delivery=value['delivery']; progress=value['progress']; gc,io=gc_io(row['streams/resources.json'])
    lines.append(f"| {row['attempt']} | {delivery['uniqueCount']}/{delivery['duplicateCount']} | {progress['Lag']}/{progress['PendingCount']} | "
                 f"{value['rate']:.3f} | {value['p95_ms']:.2f}/{value['p99_ms']:.2f} | "
                 f"{delivery['arrivalP95Milliseconds']:.2f}/{delivery['arrivalP99Milliseconds']:.2f} | {value['cpu_ms_per_operation']:.2f} | "
                 f"{value['peak_rss_bytes']/1048576:.1f} | {gc} | {io} |")
lines += ['', '## Async body diagnostics (2 MiB, 16 clients)', '',
          'Two fixed rounds, 20 seconds load, maximum 300 seconds delivery drain, no request retries. '
          'The Python target hashes and journals every body. These rates are not comparable to the .NET benchmark target or M4 campaign.', '',
          '| Attempt | HTTP 202 | Observed | Missing | Duplicate IDs | HTTP errors | Body mismatches | Queue ID errors | Minimum sampled disk free MiB |',
          '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for row in traces:
    value=row['summary']
    if value is None:
        lines.append(f"| {row['attempt']} | not completed | | | | | | | |")
        continue
    disk=row['minimum_sampled_free_disk_bytes']
    disk_text=f'{disk/1048576:.1f}' if disk is not None else 'unavailable'
    lines.append(f"| {row['attempt']} | {value['accepted']} | {value['observed']} | {len(value['missing_ids'])} | "
                 f"{len(value['duplicates'])} | {len(value['http_errors'])} | {len(value['body_mismatches'])} | "
                 f"{len(value['missing_queue_ids'])+len(value['queue_id_mismatches'])} | {disk_text} |")
(OUT/'pr504-windows-local.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Archived',len(raw),'files;',archive.stat().st_size,'compressed bytes')
