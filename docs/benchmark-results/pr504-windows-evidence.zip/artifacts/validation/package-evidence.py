"""Package original bytes once per file, avoiding redundant JSON/base64 log copies."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
ART=ROOT/'artifacts'
OUT=ROOT/'docs/benchmark-results'
report_path=OUT/'pr504-windows-local.json'
report=json.loads(report_path.read_text(encoding='utf-8'))
paths=set()
roots=[ART/name for name in report['campaigns']]+[ART/'pr504-async-headroom',ART/'pr504-async',ART/'pr504-demo',ART/'pr504-demo-final']
for root in roots:
    paths.update(path for path in root.rglob('*') if path.is_file() and 'state' not in path.relative_to(root).parts and
                 path.suffix in ('.json','.jsonl','.log','.py','.yaml'))
for pattern in ('publish-*.log','full-tests*.log','file-*.log','compressed-*.json','smoke-real-demo.py',
                'async-round-*.log','async-headroom-round-*.log','sets-streams-campaign.log','sets-headroom-campaign.log',
                'files-*-campaign.log','demo-final.log','demo-prebuilt-final.log','build-fibonacci*-final.log',
                'run-remaining.ps1','run-async-headroom.ps1','run-sets-headroom.ps1','publish-final.ps1'):
    paths.update((ART/'validation').glob(pattern))
paths.update(ROOT/'.bin'/name for name in ('trace-async-offload.py','slimfaas-zlinq-benchmark.py','summarize-collection-probe.py'))
paths.update((ART/name/'source.json') for name in ('runtime-filefix','runtime-filefix-final'))
paths.update((ART/'validation'/'collect-evidence.py',ART/'validation'/'sets-headroom-plan.json'))
assert len(paths)==report['raw_evidence']['file_count'],(len(paths),report['raw_evidence']['file_count'])
paths.add(Path(__file__).resolve())
manifest={}
archive=OUT/'pr504-windows-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as target:
    for path in sorted(paths):
        data=path.read_bytes()
        key=str(path.relative_to(ROOT)).replace('\\','/')
        manifest[key]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mtime_ns':path.stat().st_mtime_ns}
        target.writestr(key,data)
    target.writestr('evidence-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as source:
    for key,metadata in manifest.items():
        data=source.read(key)
        assert len(data)==metadata['bytes'] and hashlib.sha256(data).hexdigest()==metadata['sha256'],key
previous=report['raw_evidence']
report['raw_evidence']={'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'file_count':len(manifest),'bytes':archive.stat().st_size,
    'note':'Byte-exact original inputs/logs/receipts/helpers, independently verified against evidence-manifest.json. Persistent binary state stays under artifacts locally.',
    'local_redundant_json_archive':previous}
report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
md=OUT/'pr504-windows-local.md'
md.write_text(md.read_text(encoding='utf-8').replace('pr504-windows-evidence.json.gz','pr504-windows-evidence.zip'),encoding='utf-8')
print('Verified ZIP:',len(manifest),'original files;',archive.stat().st_size,'bytes;',report['raw_evidence']['sha256'])
assert archive.stat().st_size<100*1024*1024,'Archive exceeds GitHub per-file limit'
