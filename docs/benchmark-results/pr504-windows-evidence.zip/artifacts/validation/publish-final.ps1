$ErrorActionPreference='Stop'
$env:PATH='C:\github\SlimFaas\artifacts\dotnet-10.0.403;'+$env:PATH
$env:DOTNET_ROOT='C:\github\SlimFaas\artifacts\dotnet-10.0.403'
$test=Get-CimInstance Win32_Process -Filter "Name='dotnet.exe'" | Where-Object {$_.CommandLine -like '*test*pr504-final.trx*'}
if($test){Wait-Process -Id $test.ProcessId -ErrorAction SilentlyContinue}
Start-Sleep -Seconds 1
$reports=Get-ChildItem tests,client/dotnet -Recurse -Filter pr504-final.trx
$passed=0
foreach($report in $reports){[xml]$xml=Get-Content -LiteralPath $report.FullName; $c=$xml.TestRun.ResultSummary.Counters; if([int]$c.failed -ne 0){throw 'Tests failed'}; $passed += [int]$c.passed}
if($reports.Count -ne 5 -or $passed -ne 1994){throw "Unexpected test evidence: $($reports.Count) reports, $passed passes"}
python .bin/test-zlinq-benchmark.py
if($LASTEXITCODE -ne 0){throw 'Python checks failed'}
git add src/SlimData/ClusterFiles/DiskFileRepository.cs tests/SlimData.Tests/ClusterFiles/DiskFileRepositoryCacheTests.cs docs/data-files.md
git commit -s -m 'fix(files): share transient replacement handles with readers'
if($LASTEXITCODE -ne 0){throw 'Commit failed'}
git push origin HEAD:perf/121-zlinq-local-benchmarks
if($LASTEXITCODE -ne 0){throw 'Push failed'}
dotnet publish src/SlimFaas -c Release -r win-x64 --self-contained true -p:PublishAot=false -p:PublishTrimmed=false -p:SkipClientAppBuild=true -o artifacts/runtime-filefix-final/candidate-jit -v:q *> artifacts/validation/publish-final-jit.log
if($LASTEXITCODE -ne 0){throw 'JIT publication failed'}
dotnet publish src/SlimFaas -c Release -r win-x64 -p:SkipClientAppBuild=true -p:IlcGenerateDgmlFile=false -o artifacts/runtime-filefix-final/candidate-aot -v:q *> artifacts/validation/publish-final-aot.log
if($LASTEXITCODE -ne 0){throw 'AOT publication failed'}
@{SourceCommit=(git rev-parse HEAD); JitFlags='self-contained true; PublishAot=false; PublishTrimmed=false; SkipClientAppBuild=true'; AotFlags='product defaults; SkipClientAppBuild=true; IlcGenerateDgmlFile=false (dependency graphs only)'; Tests=1994} | ConvertTo-Json | Set-Content artifacts/runtime-filefix-final/source.json
$symbols=(Resolve-Path artifacts/runtime-filefix-final/candidate-aot/SlimFaas.pdb).Path
$before=(Get-FileHash -LiteralPath $symbols -Algorithm SHA256).Hash
compact.exe /C /I $symbols
if($LASTEXITCODE -ne 0 -or $before -ne (Get-FileHash -LiteralPath $symbols -Algorithm SHA256).Hash){throw 'Symbol compression failed validation'}
dotnet build-server shutdown
'Final file variants published and build servers stopped.'
