import importlib.util
import json
from pathlib import Path
import subprocess
import socket
import time
import urllib.error
import urllib.request
import uuid

ROOT = Path.cwd()
for sample in ('Fibonacci','FibonacciBatch'):
    binary=ROOT/'samples'/sample/'bin/Release/net10.0'/(sample+'.dll')
    if not binary.is_file():
        raise FileNotFoundError('Build the sample before starting the native demo: '+str(binary))
for port in (30020,30021,30022,30023,3262,3263,3264):
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        probe.bind(('127.0.0.1',port))
spec = importlib.util.spec_from_file_location('campaign', ROOT / '.bin/slimfaas-zlinq-benchmark.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
output = ROOT / 'artifacts/pr504-demo-final'
output.mkdir(exist_ok=False)
runtime = ROOT / 'artifacts/runtime-filefix-final/candidate-aot/SlimFaas.exe'
overlay = {'state': {'mode': 'ephemeral'}, 'functions': {}, 'jobs': {}}
for name in ('fibonacci1','fibonacci2','fibonacci3','fibonacci4'):
    overlay['functions'][name] = {'command': ['dotnet', str(ROOT / 'samples/Fibonacci/bin/Release/net10.0/Fibonacci.dll')],
                                  'workingDirectory': str(ROOT / 'samples/Fibonacci')}
for name in ('fibonacci','fibonacci5','fibonacci-ws'):
    overlay['jobs'][name] = {'command': ['dotnet', str(ROOT / 'samples/FibonacciBatch/bin/Release/net10.0/FibonacciBatch.dll')],
                             'workingDirectory': str(ROOT / 'samples/FibonacciBatch'),
                             'annotations': {'SlimFaas/Schedules':'[]'}}
manifest = output / 'overlay.json'
manifest.write_text(json.dumps(overlay, indent=2))
args = ['-f', str(ROOT / 'slimfaas.local.yaml'), '-f', str(manifest)]
def request(path, method='GET', value=None, raw=None):
    data = json.dumps(value).encode() if value is not None else raw
    req = urllib.request.Request('http://127.0.0.1:30020'+path, data=data, method=method,
        headers={'Content-Type': 'application/json' if value is not None else 'text/plain'})
    with C.HTTP.open(req, timeout=60) as response:
        return response.status, response.read(), dict(response.headers)
process = None
report = {'overlay': overlay, 'runtime': str(runtime), 'sample_build': 'Release/net10.0, prebuilt; no concurrent builds'}
try:
    with (output/'local.log').open('w') as log:
        subprocess.run([str(runtime),'local','validate',*args], check=True, stdout=log, stderr=subprocess.STDOUT)
        process = C.start_local([str(runtime),'local','up',*args], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic()+180
        while True:
            try:
                request('/ready')
                break
            except OSError:
                if process.poll() is not None or time.monotonic()>deadline:
                    raise RuntimeError('Demo did not become ready')
                time.sleep(.25)
        report['functions'] = json.loads(request('/status-functions')[1])
        assert len(report['functions']) == 4
        report['hello'] = request('/function/fibonacci1/hello/local')[1].decode()
        assert report['hello'] == 'Hello local!'
        report['fibonacci'] = json.loads(request('/function/fibonacci1/fibonacci','POST',{'Input':10})[1])
        assert report['fibonacci']['result'] == 55
        tour = 'pr504-'+uuid.uuid4().hex
        request('/data/sets/'+tour+'-dlq-ready?ttl=600000','POST',raw=b'ready')
        status,_,headers = request('/async-function/fibonacci1/tour/dlq/'+tour,'POST',{'orderId':tour})
        assert status == 202
        element = next(value for key,value in headers.items() if key.lower()=='slimfaas-element-id')
        deadline = time.monotonic()+60
        while True:
            try:
                completed = request('/data/sets/'+tour+'-dlq-completed')[1].decode()
                break
            except urllib.error.HTTPError as error:
                if error.code != 404 or time.monotonic()>deadline:
                    raise
                time.sleep(.25)
        assert completed == element
        report['async'] = {'status':status,'accepted_element_id':element,'observed_element_id':completed}
        report['catalog_page']=json.loads(request('/data/streams?limit=1')[1])
        report['orders_metadata']=json.loads(request('/data/streams/orders')[1])
        report['orders_functions_page']=json.loads(request('/data/streams/orders/functions?limit=1')[1])
        status,body,_=request('/publish-stream/orders/compute','POST',{'Input':10})
        assert status==202
        report['stream_receipt']=json.loads(body)
        deadline=time.monotonic()+60
        while True:
            progress={name:json.loads(request('/data/streams/orders/functions/'+name)[1])
                      for name in ('fibonacci1','fibonacci2')}
            if all(row['Lag']==0 and row['PendingCount']==0 for row in progress.values()):
                report['stream_progress']=progress
                break
            if time.monotonic()>deadline:
                raise RuntimeError('Demo Stream did not drain: '+json.dumps(progress))
            time.sleep(.25)
        job = json.loads(request('/job/fibonacci','POST',{'Args':['10'],'TtlSecondsAfterFinished':60})[1])
        deadline=time.monotonic()+60
        while True:
            jobs=json.loads(request('/job/fibonacci')[1])
            matching=[row for row in jobs if row['Id']==job['Id']]
            if matching and matching[0]['Status']=='Succeeded':
                report['job']=matching[0]
                break
            if time.monotonic()>deadline:
                raise RuntimeError('Job did not succeed: '+json.dumps(jobs))
            time.sleep(.25)
        report['success']=True
finally:
    try:
        if process is not None:
            C.stop(process)
            report['shutdown_exit_code']=process.returncode
    finally:
        C.save(output/'summary.json',report)
print(json.dumps(report,indent=2))
