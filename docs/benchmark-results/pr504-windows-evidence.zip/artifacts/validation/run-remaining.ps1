$ErrorActionPreference='Stop'
$env:PATH='C:\github\SlimFaas\artifacts\dotnet-10.0.403;'+$env:PATH
$env:DOTNET_ROOT='C:\github\SlimFaas\artifacts\dotnet-10.0.403'
if(@(Get-ChildItem artifacts/pr504-files-final/round-*/complete.json).Count -ne 4){throw 'Final file verification is incomplete'}
python .bin/slimfaas-zlinq-benchmark.py --publish-root artifacts/runtime --output artifacts/pr504-sets-streams --rounds 2 --duration 20 --warmup 5 --data-duration 60 --data-scenarios slimdata-set --stream-messages 200 --skip-http --continue-after-failure --variants baseline-jit,candidate-jit,candidate-aot,baseline-aot *> artifacts/validation/sets-streams-campaign.log
$dataExit=$LASTEXITCODE
$variants=@('baseline-jit','candidate-jit','candidate-fixed-jit','candidate-fixed-aot','candidate-aot','baseline-aot')
$traceRoot=Join-Path (Resolve-Path artifacts).Path 'pr504-async'
New-Item -ItemType Directory -Path $traceRoot -ErrorAction Stop | Out-Null
@{Variants=$variants; Rounds=2; Round1=$variants; Round2=@($variants[5..0]); Clients=16; PayloadBytes=2097152; LoadSeconds=20; DrainSeconds=300; DispatchCapacity=16; WarmupSeconds=0; Retries=0; ContinueAfterFailure=$true; Note='Diagnostic Python hash/journal target, not comparable to .NET target or M4 throughput. Persistent state is retained. No builds run concurrently.'} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $traceRoot 'plan.json')
$ledger=@()
foreach($round in 1,2){
    $order=if($round -eq 1){$variants}else{@($variants[5..0])}
    foreach($variant in $order){
        $attempt=Join-Path $traceRoot "round-$round-$variant"
        python .bin/trace-async-offload.py --variant $variant --output $attempt --duration 20 --clients 16 *> "artifacts/validation/async-round-$round-$variant.log"
        $code=$LASTEXITCODE
        $ledger += @{Round=$round; Variant=$variant; ExitCode=$code; Output=$attempt}
        $ledger | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $traceRoot 'ledger.json')
        "TRACE round=$round variant=$variant exit=$code"
    }
}
python artifacts/validation/smoke-real-demo.py *> artifacts/validation/demo-final.log
$demoExit=$LASTEXITCODE
Get-Content artifacts/validation/demo-final.log -Tail 12
if($dataExit -ne 0 -or $demoExit -ne 0 -or @($ledger | Where-Object ExitCode -ne 0).Count -ne 0){throw 'One or more fixed planned phases failed; evidence is retained'}
'All remaining planned runtime phases completed.'
