$ErrorActionPreference='Stop'
$env:PATH='C:\github\SlimFaas\artifacts\dotnet-10.0.403;'+$env:PATH
$env:DOTNET_ROOT='C:\github\SlimFaas\artifacts\dotnet-10.0.403'
$variants=@('baseline-jit','candidate-jit','candidate-fixed-jit','candidate-fixed-aot','candidate-aot','baseline-aot')
$traceRoot=Join-Path (Resolve-Path artifacts).Path 'pr504-async-headroom'
New-Item -ItemType Directory -Path $traceRoot -ErrorAction Stop | Out-Null
if((Get-Item -LiteralPath $traceRoot).Attributes -band [IO.FileAttributes]::Compressed){throw 'New diagnostic state must start uncompressed'}
@{Variants=$variants; Rounds=2; Round1=$variants; Round2=@($variants[5..0]); Clients=16; PayloadBytes=2097152; LoadSeconds=20; DrainSeconds=300; DispatchCapacity=16; WarmupSeconds=0; Retries=0; MinimumFreeDiskBytes=4GB; InstrumentationCommit=(git rev-parse HEAD); ContinueAfterFailure=$true; PrecedingInterruptedExperiment='artifacts/pr504-async: first baseline JIT attempt aborted on ENOSPC, no completed drain, remaining 11 not started'; StopPolicy='Execute each of the 12 planned attempts once; no retry. Compress only closed retained states between attempts, never live state.'; Note='Python hash/journal target and Debug logging differ from .NET/M4 performance target; no throughput comparison. Runtime/DLLs and live state remain uncompressed.'} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $traceRoot 'plan.json')
$ledger=@()
foreach($round in 1,2){
    $order=if($round -eq 1){$variants}else{@($variants[5..0])}
    foreach($variant in $order){
        $attempt=Join-Path $traceRoot "round-$round-$variant"
        $freeBefore=(Get-PSDrive C).Free
        python .bin/trace-async-offload.py --variant $variant --output $attempt --duration 20 --clients 16 *> "artifacts/validation/async-headroom-round-$round-$variant.log"
        $code=$LASTEXITCODE
        $forced=@()
        $processFile=Join-Path $attempt 'processes.json'
        $manifestFile=Join-Path $attempt 'manifest.json'
        if((Test-Path -LiteralPath $processFile) -and (Test-Path -LiteralPath $manifestFile)){
            $recorded=@(Get-Content -Raw -LiteralPath $processFile | ConvertFrom-Json)
            $runtime=(Get-Content -Raw -LiteralPath $manifestFile | ConvertFrom-Json).runtime
            foreach($record in $recorded){
                $live=Get-CimInstance Win32_Process -Filter "ProcessId=$($record.ProcessId)"
                if($live -and $live.ExecutablePath -eq $runtime -and $live.ParentProcessId -eq $record.ParentProcessId){
                    Stop-Process -Id $live.ProcessId -Force
                    $forced += $live.ProcessId
                }
            }
        }
        $entry=@{Round=$round; Variant=$variant; ExitCode=$code; ForcedStopPids=$forced; Output=$attempt; FreeDiskBeforeBytes=$freeBefore}
        $ledger += $entry
        $ledger | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $traceRoot 'ledger.json')
        $hashes=@{}
        $closedFiles=@(Get-ChildItem -LiteralPath $attempt -Recurse -File)
        foreach($closedFile in $closedFiles){$hashes[$closedFile.FullName]=(Get-FileHash -LiteralPath $closedFile.FullName -Algorithm SHA256).Hash}
        compact.exe /C /I /Q ('/S:'+$attempt) '*' *> "artifacts/validation/compress-async-headroom-round-$round-$variant.log"
        if($LASTEXITCODE -ne 0){throw 'Closed-state compression failed'}
        foreach($closedFile in $closedFiles){if($hashes[$closedFile.FullName] -ne (Get-FileHash -LiteralPath $closedFile.FullName -Algorithm SHA256).Hash){throw 'Closed state changed content'}}
        $hashes | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $traceRoot "compression-round-$round-$variant.json")
        "TRACE round=$round variant=$variant exit=$code forced=$($forced.Count) freeGiB=$([math]::Round((Get-PSDrive C).Free/1GB,2))"
    }
}
python artifacts/validation/smoke-real-demo.py *> artifacts/validation/demo-final.log
$demoExit=$LASTEXITCODE
Get-Content artifacts/validation/demo-final.log -Tail 15
if($demoExit -ne 0 -or @($ledger | Where-Object {$_.ExitCode -ne 0 -or $_.ForcedStopPids.Count -gt 0}).Count -ne 0){throw 'One or more planned phases failed; all evidence is retained'}
'Completed the fixed diagnostic matrix and native demo.'
