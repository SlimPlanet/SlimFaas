$ErrorActionPreference='Stop'
$env:PATH='C:\github\SlimFaas\artifacts\dotnet-10.0.403;'+$env:PATH
$env:DOTNET_ROOT='C:\github\SlimFaas\artifacts\dotnet-10.0.403'
if((Get-PSDrive C).Free -lt 4GB){throw 'The isolated set control requires at least 4 GiB free'}
@{Reason='The first isolated set campaign ran near disk exhaustion and has a negative NativeAOT row; repeat the fixed matrix once with adequate initial headroom to investigate that confound, retaining every original result.'; Baseline='999ca1524df7a47e24e9aa84a14ec0fcf4e99531'; RuntimeCandidate='5251820a5f215c1c9f30eddc4486321cdd1eaeb7'; Rounds=2; Variants=@('baseline-jit','candidate-jit','candidate-aot','baseline-aot'); ReverseSecondRound=$true; WarmupSeconds=5; LoadSeconds=60; PayloadBytes=4096; Workers=16; RequestRetries=0; StopPolicy='Exactly eight attempts, no retries; preserve unsuccessful attempts'; MinimumInitialFreeDiskBytes=4GB; ActualInitialFreeDiskBytes=(Get-PSDrive C).Free; Streams=0; ConcurrentBuilds=0} | ConvertTo-Json -Depth 5 | Set-Content artifacts/validation/sets-headroom-plan.json
python .bin/slimfaas-zlinq-benchmark.py --publish-root artifacts/runtime --output artifacts/pr504-sets-headroom --rounds 2 --duration 20 --warmup 5 --data-duration 60 --data-scenarios slimdata-set --stream-messages 0 --skip-http --continue-after-failure --variants baseline-jit,candidate-jit,candidate-aot,baseline-aot *> artifacts/validation/sets-headroom-campaign.log
$code=$LASTEXITCODE
Get-Content artifacts/validation/sets-headroom-campaign.log -Tail 12
exit $code
