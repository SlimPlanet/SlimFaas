"""Fixed final-runtime data and common-.NET-target campaigns; retain all attempts."""
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / 'artifacts'
spec = importlib.util.spec_from_file_location('pr504_harness', ROOT / '.bin/slimfaas-zlinq-benchmark.py')
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
original_run = harness.run
original_benchmark = harness.benchmark
plan_path = ART / 'validation/extra-benchmarks-plan.json'
assert not plan_path.exists(), 'Never overwrite a predetermined plan'
plan = {
    'created_utc_ns': time.time_ns(), 'runner_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'publications': json.loads((ART / 'runtime-final-comparison/source.json').read_text()),
    'minimum_initial_free_bytes': 4 * 1024**3, 'emergency_free_bytes': 512 * 1024**2,
    'rounds': 2, 'round_1': ['baseline-jit', 'candidate-jit', 'candidate-aot', 'baseline-aot'],
    'round_2': ['baseline-aot', 'candidate-aot', 'candidate-jit', 'baseline-jit'],
    'retry_policy': 'Each planned attempt runs once. Preserve failures and resource errors. No retry until green.',
    'driver_sha256': hashlib.sha256((ROOT / 'benchmarks/SlimFaasBenchmark/bin/Release/net10.0/SlimFaasBenchmark.dll').read_bytes()).hexdigest(),
    'memorylab_sha256': hashlib.sha256((ROOT / 'tools/SlimFaas.MemoryLab/bin/Release/net10.0/SlimFaas.MemoryLab.dll').read_bytes()).hexdigest(),
    'campaigns': {
        'pr504-final-data': {'http': False, 'scenarios': ['slimdata-set', 'slimdata-mixed', 'files'], 'load_seconds': 60,
                             'warmup_seconds': 5, 'clients': 16, 'value_bytes': 4096, 'file_bytes': 262144},
        'pr504-final-http': {'http': True, 'profile': 'async-queue', 'payload_bytes': [2097152], 'clients': [16],
                            'load_seconds': 20, 'warmup_seconds': 5, 'delivery_drain_seconds': 300,
                            'paced_messages': 100, 'paced_interval_ms': 100, 'burst_messages': 1000, 'burst_clients': 64,
                            'dispatch_parallelism': 16, 'resource_sample_seconds': 0.5,
                            'body_verification': 'Common original .NET target drains the complete body and records unique IDs; it does not hash content. Separate earlier file/hash diagnostics remain distinct.'}
    }
}
plan_path.write_text(json.dumps(plan, indent=2) + '\n')

def guarded_benchmark(args, variant, round_number):
    available = shutil.disk_usage(ROOT).free
    if available < plan['minimum_initial_free_bytes']:
        directory = args.output / f'round-{round_number}-{variant}'
        directory.mkdir()
        harness.save(directory / 'not-started.json', {'reason': 'initial disk reserve', 'free_bytes': available})
        raise RuntimeError(f'Not started: only {available} free bytes')
    print(f'START {args.output.name} round={round_number} variant={variant} free={available}', flush=True)
    return original_benchmark(args, variant, round_number)

def sampled_run(command, log, **kwargs):
    if len(command) < 3 or not str(command[1]).endswith('SlimFaasBenchmark.dll') or command[2] != 'run':
        return original_run(command, log, **kwargs)
    samples, errors = [], []
    finished = threading.Event()

    def sample():
        while not finished.is_set():
            try:
                samples.append({'time_ns': time.time_ns(), 'free_disk_bytes': shutil.disk_usage(ROOT).free, **harness.resources()})
            except Exception as error:
                errors.append({'time_ns': time.time_ns(), 'error': str(error)})
            if finished.wait(0.5):
                break

    monitor = threading.Thread(target=sample)
    monitor.start()
    disk_abort = False
    print('RUN common .NET HTTP driver with 500 ms runtime GC/I/O/RSS sampling', flush=True)
    try:
        with log.open('w') as output:
            process = subprocess.Popen(list(map(str, command)), cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, **kwargs)
            harness.save(log.parent / 'http-driver-process.json', {'pid': process.pid, 'command': list(map(str, command))})
            while process.poll() is None:
                if shutil.disk_usage(ROOT).free < plan['emergency_free_bytes']:
                    disk_abort = True
                    process.terminate()
                    try:
                        process.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=20)
                    break
                time.sleep(0.25)
    finally:
        finished.set()
        monitor.join(timeout=30)
        if monitor.is_alive():
            errors.append({'error': 'resource monitor did not finish'})
        harness.save(log.parent / 'http-resource-samples.json', {'samples': samples, 'sampling_errors': errors,
            'emergency_disk_abort': disk_abort, 'scope': 'Three runtime nodes only; target, supervisor and load driver excluded. Process I/O includes cached/network traffic.'})
    if disk_abort:
        raise RuntimeError('Emergency disk reserve reached; load stopped and attempt retained as failed')
    if process.returncode:
        raise subprocess.CalledProcessError(process.returncode, command)
    if errors:
        raise RuntimeError('HTTP resource sampling errors; retain attempt without valid resource comparison')

harness.benchmark = guarded_benchmark
harness.run = sampled_run
outcomes = []
for name, settings in plan['campaigns'].items():
    assert not (ART / name).exists(), 'Use a new campaign directory'
    arguments = ['slimfaas-zlinq-benchmark.py', '--publish-root', str(ART / 'runtime-final-comparison'), '--output', str(ART / name),
                 '--rounds', '2', '--duration', '20', '--warmup', '5', '--data-duration', '60', '--data-concurrency', '16',
                 '--stream-messages', '0', '--dispatch-parallelism', '16', '--continue-after-failure']
    if settings['http']:
        arguments += ['--payloads', '2097152', '--concurrency', '16', '--data-scenarios=']
    else:
        arguments += ['--skip-http', '--data-scenarios', ','.join(settings['scenarios'])]
    print('CAMPAIGN', name, flush=True)
    sys.argv = arguments
    started = time.time_ns()
    try:
        harness.main()
        outcome = {'campaign': name, 'success': True}
    except Exception as error:
        outcome = {'campaign': name, 'success': False, 'error': str(error), 'traceback': traceback.format_exc()}
    outcome.update(started_ns=started, finished_ns=time.time_ns())
    outcomes.append(outcome)
    harness.save(ART / 'validation/extra-benchmarks-outcomes.json', outcomes)
    print('CAMPAIGN OUTCOME', json.dumps(outcome), flush=True)
print('FIXED CAMPAIGNS FINISHED', flush=True)
