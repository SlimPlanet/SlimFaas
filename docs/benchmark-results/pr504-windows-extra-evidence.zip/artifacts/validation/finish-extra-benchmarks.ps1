$ErrorActionPreference = 'Stop'
$env:PATH = 'C:\github\SlimFaas\artifacts\dotnet-10.0.403;' + $env:PATH
$env:DOTNET_ROOT = 'C:\github\SlimFaas\artifacts\dotnet-10.0.403'
$env:PYTHONIOENCODING = 'utf-8'
do {
 $taskMainFinished = $false
 try {
  if (Test-Path -LiteralPath 'artifacts/validation/extra-benchmarks-outcomes.json') {
   $taskOutcomes = Get-Content -LiteralPath 'artifacts/validation/extra-benchmarks-outcomes.json' -Raw | ConvertFrom-Json
   $taskMainFinished = @($taskOutcomes).Count -eq 2
  }
 } catch { $taskMainFinished = $false }
 if (-not $taskMainFinished) { Start-Sleep -Seconds 30 }
} while (-not $taskMainFinished)
Write-Output 'Both fixed main campaigns finished. Starting the separate four-attempt native thread-state diagnostic.'
python -m py_compile artifacts/validation/run-native-wait-profiles.py artifacts/validation/analyze-extra-benchmarks.py
if ($LASTEXITCODE -ne 0) { throw 'Diagnostic or extraction syntax error' }
python artifacts/validation/run-native-wait-profiles.py *> artifacts/validation/native-wait-profiles.log
$taskProfileExit = $LASTEXITCODE
[PSCustomObject]@{ExitCode=$taskProfileExit;Finished=(Get-Date -Format o)} | ConvertTo-Json | Set-Content -LiteralPath 'artifacts/validation/native-wait-profiles-exit.json' -Encoding utf8
Write-Output "Thread-state diagnostic finished with exit $taskProfileExit; preserving every attempt."
python artifacts/validation/analyze-extra-benchmarks.py *> artifacts/validation/analyze-extra-benchmarks.log
if ($LASTEXITCODE -ne 0) { throw 'Evidence extraction failed; originals left untouched' }
Write-Output 'Additional evidence extracted and archive verified.'
