"""Retain all final-runtime attempts and build a byte-exact independent archive."""
import collections
import hashlib
import json
import statistics
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / 'artifacts'
OUT = ROOT / 'docs/benchmark-results'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else None

def sampled(samples):
    if len(samples) < 2:
        return {'sample_count': len(samples)}
    first, last = samples[0], samples[-1]
    gc = {}
    for generation in range(3):
        key = f'dotnet_collection_count_total{{generation="{generation}"}}'
        gc[str(generation)] = sum(n.get(key, 0) for n in last['runtime_counters_by_node']) - sum(n.get(key, 0) for n in first['runtime_counters_by_node'])
    before, after = first.get('windows_io_by_node') or [], last.get('windows_io_by_node') or []
    io = {}
    if before and {x['pid'] for x in before} == {x['pid'] for x in after}:
        for name in ('read_operations', 'write_operations', 'other_operations', 'read_bytes', 'write_bytes', 'other_bytes'):
            io[name] = sum(x[name] for x in after) - sum(x[name] for x in before)
    return {'sample_count': len(samples), 'gc_collections': gc, 'process_io': io,
            'sampled_runtime_cpu_seconds': last['cpu_seconds'] - first['cpu_seconds'],
            'sampled_peak_rss_bytes': max(s['rss_bytes'] for s in samples),
            'note': 'First-to-last sampled window; I/O includes cached and network transfers, not physical disk attribution.'}

def phase(path):
    summary = read(path / 'summary.json')
    raw_load = read(path / 'load.json')
    resource = read(path / 'resources.json') or {}
    load = raw_load.get('report') if raw_load else None
    row = {'name': path.name, 'summary': summary, 'reported_load': load, 'not_started': load is None,
           'sampling_errors': resource.get('errors', []), 'sampled_counters': sampled(resource.get('samples', [])),
           'valid': bool(summary and load and load['Completed'] > 0 and load['Failed'] == 0 and not resource.get('errors'))}
    if summary is None and load:
        row['invalid_rate_reason'] = 'Driver or validation failed before phase summary. Preserve reported successful/failed operations; no correctness-checked throughput comparison.'
    return row

campaigns = {}
for name, expected in (('pr504-final-data', 8), ('pr504-final-http', 8), ('pr504-native-thread-waits', 4)):
    directory = ART / name
    campaign_manifest = read(directory / 'manifest.json')
    scenarios = campaign_manifest['settings']['data_scenarios'].split(',') if campaign_manifest['settings']['data_scenarios'] else []
    attempts = sorted(directory.glob('round-*'))
    assert len(attempts) == expected, (name, len(attempts), expected)
    rows = []
    for attempt in attempts:
        complete, failure = read(attempt / 'complete.json'), read(attempt / 'failed.json')
        assert complete or failure, f'Attempt is still running: {attempt}'
        row = {'attempt': attempt.name, 'complete': complete, 'failure': failure, 'shutdown': read(attempt / 'shutdown.json'),
               'not_started': read(attempt / 'not-started.json'), 'startup': read(attempt / 'startup.json')}
        row['data_phases'] = [phase(attempt / (scenario + suffix)) for scenario in scenarios for suffix in ('-warmup', '')]
        row['http_results'] = read(attempt / 'results.json')
        http_resources = read(attempt / 'http-resource-samples.json')
        if http_resources:
            row['http_counters'] = sampled(http_resources['samples'])
            row['http_sampling_errors'] = http_resources['sampling_errors']
            row['http_emergency_disk_abort'] = http_resources['emergency_disk_abort']
            row['minimum_sampled_free_bytes'] = min((s['free_disk_bytes'] for s in http_resources['samples']), default=None)
        profiles = []
        for p in sorted(attempt.glob('*/thread-states.jsonl')):
            window = read(p.parent / 'profile-window.json')
            frames = [json.loads(line) for line in p.read_text(encoding='utf-8-sig').splitlines()]
            load_frames = [f for f in frames if f['phase'] == 'load' and f['time_unix_ms'] * 1_000_000 >= window['driver_start_ns']]
            states, waits, errors = collections.Counter(), collections.Counter(), 0
            first_cpu, last_cpu = {}, {}
            for frame in load_frames:
                errors += len(frame['query_errors'])
                for thread in frame['threads']:
                    states[thread['state']] += 1
                    if thread['wait_reason']:
                        waits[thread['wait_reason']] += 1
                    key = (thread['pid'], thread['thread_id'])
                    first_cpu.setdefault(key, thread['cpu_ms'])
                    last_cpu[key] = thread['cpu_ms']
            cpu = sorted(({'pid': k[0], 'thread_id': k[1], 'observed_cpu_ms': last_cpu[k] - v} for k, v in first_cpu.items()),
                         key=lambda item: item['observed_cpu_ms'], reverse=True)
            profiles.append({'phase': p.parent.name, 'frames': len(load_frames), 'thread_state_samples': dict(states),
                'wait_reason_samples': dict(waits), 'query_errors': errors, 'top_thread_cpu_deltas': cpu[:12],
                'sampler_result': read(p.parent / 'thread-sampler-result.json'),
                'note': 'Snapshots, not scheduler dwell times or stacks; idle threads contribute and recycled thread IDs may affect CPU deltas.'})
        row['thread_profiles'] = profiles
        rows.append(row)
    campaigns[name] = {'manifest': campaign_manifest, 'attempts': rows}

comparisons = []
for mode in ('jit', 'aot'):
    for scenario in ('slimdata-set', 'slimdata-mixed', 'files'):
        grouped = {}
        for variant in ('baseline-' + mode, 'candidate-' + mode):
            phases = [p for row in campaigns['pr504-final-data']['attempts'] if row['attempt'].endswith(variant)
                      for p in row['data_phases'] if p['name'] == scenario]
            grouped[variant] = phases
        valid = all(len(rows) == 2 and all(p['valid'] for p in rows) for rows in grouped.values())
        result = {'mode': mode, 'scenario': scenario, 'comparable': valid,
                  'valid_counts': {v: sum(p['valid'] for p in rows) for v, rows in grouped.items()}}
        if valid:
            medians = {v: statistics.median(p['reported_load']['Rate'] for p in rows) for v, rows in grouped.items()}
            result.update(rate_medians=medians, change_percent=100 * (medians['candidate-' + mode] / medians['baseline-' + mode] - 1))
        comparisons.append(result)

standard = read(ART / 'validation/cache-compression-20261110.json')
lzx = read(ART / 'validation/cache-lzx-compression-20261110.json')
cleanup = {'deletion': 'Automatically rejected: blocked by policy; no cache deletion performed.',
           'method': 'Filesystem compression of closed caches/copies and one closed Copilot history database; content hashes checked.',
           'initial_free_bytes': standard['BeforeFree'], 'final_free_bytes': lzx['AfterFree'],
           'standard_compression_free_delta': standard['AfterFree'] - standard['BeforeFree'],
           'note': 'Initial standard compression reduced free reserve; its local audit is retained. LZX compression recovered reserve. These are observed whole-volume free-space values, including unrelated activity.'}
assert all(r['HashesVerified'] for r in standard['Roots'] + lzx['Roots'])
assert read(ART / 'validation/closed-copilot-history-compression.json')['ContentVerified']

report = {'runner_plan': read(ART / 'validation/extra-benchmarks-plan.json'),
          'thread_profile_plan': read(ART / 'validation/native-wait-profile-plan.json'),
          'outcomes': read(ART / 'validation/extra-benchmarks-outcomes.json'), 'cleanup': cleanup,
          'campaigns': campaigns, 'balanced_data_comparisons': comparisons}

paths = set()
for name in campaigns:
    paths.update(p for p in (ART / name).rglob('*') if p.is_file() and 'state' not in p.relative_to(ART / name).parts)
for name in ('prepare-final-comparison.py', 'run-extra-benchmarks.py', 'extra-benchmarks-plan.json', 'extra-benchmarks-outcomes.json',
             'extra-benchmarks.log', 'sample-native-thread-waits.ps1', 'run-native-wait-profiles.py', 'native-wait-profile-plan.json',
             'native-wait-profiles.log', 'native-thread-preflight.jsonl', 'native-thread-preflight.log',
             'finish-extra-benchmarks.ps1', 'analyze-extra-benchmarks.py'):
    p = ART / 'validation' / name
    assert p.exists(), name
    paths.add(p)
paths.add(ART / 'runtime-final-comparison/source.json')
archive = OUT / 'pr504-windows-extra-evidence.zip'
assert not archive.exists(), 'Never overwrite the evidence archive'
manifest = {}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for p in sorted(paths):
        blob = p.read_bytes()
        name = p.relative_to(ROOT).as_posix()
        manifest[name] = {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()}
        target.writestr(name, blob)
    target.writestr('evidence-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as source:
    for name, entry in manifest.items():
        blob = source.read(name)
        assert len(blob) == entry['bytes'] and hashlib.sha256(blob).hexdigest() == entry['sha256'], name
report['raw_evidence'] = {'path': archive.name, 'files': len(manifest), 'bytes': archive.stat().st_size,
                          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(OUT / 'pr504-windows-extra.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

md = ['# PR 504 additional final-runtime Windows campaigns', '',
      'Baseline `999ca152` versus final runtime `dc7e4812`, same immutable JIT/NativeAOT publications through hard-linked aliases. Two fixed reverse-order rounds, no retries, no concurrent builds/compression. Every failed attempt remains included. Two repetitions give limited timing precision.', '',
      '[All summaries, plans and hashes](pr504-windows-extra.json) · [Byte-exact original evidence and helper sources](pr504-windows-extra-evidence.zip)', '',
      'Runtime CPU/RSS sum three nodes and exclude target/supervisor/driver. Process I/O includes cache/network traffic. Sampled GC/I/O cover first-to-last sample windows. The common .NET target drains full bodies and records IDs; it does not hash their contents. Earlier hash-verified diagnostics remain separate.', '',
      '## Data loads', '',
      '| Attempt | Scenario | Valid | Completed / failed | Reported op/s | p95 / p99 ms | CPU ms/op | Peak RSS MiB | GC 0/1/2 |',
      '|---|---|---|---:|---:|---:|---:|---:|---|']
for row in campaigns['pr504-final-data']['attempts']:
    for p in row['data_phases']:
        if p['name'].endswith('-warmup'):
            continue
        if not p['reported_load']:
            md.append(f"| {row['attempt']} | {p['name']} | NOT STARTED / no completed load report | — | — | — | — | — | — |")
            continue
        load, summary, gc = p['reported_load'], p['summary'] or {}, p['sampled_counters'].get('gc_collections', {})
        op = load['Operations'][0]
        cpu, rss = summary.get('cpu_ms_per_operation'), summary.get('peak_rss_bytes')
        md.append(f"| {row['attempt']} | {p['name']} | {'yes' if p['valid'] else 'FAIL'} | {load['Completed']} / {load['Failed']} | {load['Rate']:.2f}{'' if p['valid'] else ' (invalid)'} | {op['P95Milliseconds']:.2f} / {op['P99Milliseconds']:.2f} | {cpu:.2f} | {rss/1024**2:.1f} | {'/'.join(str(gc.get(str(n), '?')) for n in range(3))} |" if cpu is not None else
                  f"| {row['attempt']} | {p['name']} | FAIL | {load['Completed']} / {load['Failed']} | {load['Rate']:.2f} (invalid) | {op['P95Milliseconds']:.2f} / {op['P99Milliseconds']:.2f} | no valid summary | — | {'/'.join(str(gc.get(str(n), '?')) for n in range(3))} |")
md += ['', 'Balanced medians are reported only when both repetitions on each side pass phase validation:', '',
       '| Mode | Scenario | Before → after op/s | Change |', '|---|---|---:|---:|']
for c in comparisons:
    if c['comparable']:
        rates = c['rate_medians']; mode = c['mode']
        md.append(f"| {mode} | {c['scenario']} | {rates['baseline-'+mode]:.2f} → {rates['candidate-'+mode]:.2f} | {c['change_percent']:+.2f}% |")
    else:
        md.append(f"| {c['mode']} | {c['scenario']} | not comparable: correctness failure / incomplete phase | — |")
md += ['', '## Common .NET HTTP target: 2 MiB / 16 clients', '',
       '| Attempt | Route | HTTP completed / failed | HTTP req/s | HTTP p95 / p99 ms | Missing / duplicates | Observed |',
       '|---|---|---:|---:|---:|---:|---:|']
for row in campaigns['pr504-final-http']['attempts']:
    results = row['http_results']
    if not results:
        md.append(f"| {row['attempt']} | incomplete driver | — | — | — | unknown | unknown |")
        continue
    for r in results['LatencyRuns']:
        observed = (r.get('AsyncDelivery') or {}).get('UniqueCount', '—')
        md.append(f"| {row['attempt']} | {r['Mode']} | {r['Completed']} / {r['Failed']} | {r['RatePerSecond']:.2f} | {r['P95Milliseconds']:.2f} / {r['P99Milliseconds']:.2f} | {r['AsyncMissing']} / {r['AsyncDuplicates']} | {observed} |")
md += ['', 'HTTP acceptance throughput is distinct from delivery. A missing/duplicate delivery invalidates an end-to-end correctness/performance claim. Per-case CPU, RSS, arrival/completion latencies, focused 4 KiB paced/burst and scaling results remain in the full JSON; global HTTP GC/I/O samples cover the entire driver, not one route.', '',
       '## Native thread-state diagnostic', '',
       'A separate four-attempt set-only diagnostic samples Windows ProcessThread states/wait reasons and cumulative thread CPU. Snapshots include idle threads, are not exact wait durations, and contain no native stacks. WPR is installed but the current token is not elevated; no elevation was attempted.', '',
       '| Attempt | Phase | Frames | Thread-state samples | Wait-reason samples | Query errors |', '|---|---|---:|---|---|---:|']
for row in campaigns['pr504-native-thread-waits']['attempts']:
    for p in row['thread_profiles']:
        if p['phase'].endswith('-warmup'):
            continue
        md.append(f"| {row['attempt']} | {p['phase']} | {p['frames']} | {json.dumps(p['thread_state_samples'],sort_keys=True)} | {json.dumps(p['wait_reason_samples'],sort_keys=True)} | {p['query_errors']} |")
md += ['', f"The original evidence archive contains {len(manifest)} byte-verified files; SHA-256 `{report['raw_evidence']['sha256']}`.", '',
       'The earlier M4 and Windows campaigns, all failed/negative controls, and the original evidence ZIP remain unchanged. No Linux production benchmark or native wait-stack attribution is established by these Windows measurements.', '']
(OUT / 'pr504-windows-extra.md').write_text('\n'.join(md), encoding='utf-8')
print('Archived', len(manifest), 'files;', archive.stat().st_size, 'bytes;', report['raw_evidence']['sha256'])
for c in comparisons:
    print(c)
