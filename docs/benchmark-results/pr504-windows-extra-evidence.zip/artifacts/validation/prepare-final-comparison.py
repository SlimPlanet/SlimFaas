"""Give immutable publications distinct benchmark names without copying payloads."""
import hashlib
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parents[2]
destination = root / 'artifacts/runtime-final-comparison'
assert not destination.exists(), 'Never replace an existing publication set'
destination.mkdir()
sources = {
    'baseline-jit': ('runtime/baseline-jit', '999ca1524df7a47e24e9aa84a14ec0fcf4e99531'),
    'baseline-aot': ('runtime/baseline-aot', '999ca1524df7a47e24e9aa84a14ec0fcf4e99531'),
    'candidate-jit': ('runtime-filefix-final/candidate-jit', 'dc7e48126c979d5ce7dcbd0993a158cb5cedf148'),
    'candidate-aot': ('runtime-filefix-final/candidate-aot', 'dc7e48126c979d5ce7dcbd0993a158cb5cedf148'),
}
manifest = {}
for variant, (relative, commit) in sources.items():
    original = root / 'artifacts' / relative
    target = destination / variant
    target.mkdir()
    files = {}
    for source in sorted(original.rglob('*')):
        if not source.is_file():
            continue
        name = source.relative_to(original)
        alias = target / name
        alias.parent.mkdir(parents=True, exist_ok=True)
        os.link(source, alias)
        assert os.path.samefile(source, alias)
        if source.suffix.lower() in ('.exe', '.dll', '.json'):
            with source.open('rb') as stream:
                files[str(name)] = {'bytes': source.stat().st_size,
                                    'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
    manifest[variant] = {'source': str(original), 'product_commit': commit, 'files': files}
(destination / 'source.json').write_text(json.dumps({'method': 'NTFS hard links, immutable original publications unchanged',
                                                   'variants': manifest}, indent=2) + '\n')
print('Prepared four frozen publication aliases; no publication was rebuilt or overwritten')
