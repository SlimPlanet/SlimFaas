param([string]$RuntimePidsCsv, [string]$OutputPath, [string]$PhasePath, [string]$StopPath)
$ErrorActionPreference = 'Stop'
$taskRuntimeIds = $RuntimePidsCsv.Split(',') | ForEach-Object { [int]$_ }
$taskWriter = [IO.StreamWriter]::new($OutputPath, $false, [Text.UTF8Encoding]::new($false))
try {
 while (-not (Test-Path -LiteralPath $StopPath)) {
  $taskRows = @()
  $taskErrors = @()
  foreach ($taskRuntimeId in $taskRuntimeIds) {
   $taskProcess = $null
   try {
    $taskProcess = [Diagnostics.Process]::GetProcessById($taskRuntimeId)
    foreach ($taskThread in $taskProcess.Threads) {
     try {
      $taskState = $taskThread.ThreadState.ToString()
      $taskWait = if ($taskState -eq 'Wait') { $taskThread.WaitReason.ToString() } else { $null }
      $taskRows += [PSCustomObject]@{pid=$taskRuntimeId;thread_id=$taskThread.Id;state=$taskState;wait_reason=$taskWait;cpu_ms=$taskThread.TotalProcessorTime.TotalMilliseconds}
     } catch {
      $taskErrors += [PSCustomObject]@{pid=$taskRuntimeId;thread_id=$taskThread.Id;error=$_.Exception.Message}
     } finally { $taskThread.Dispose() }
    }
   } catch { $taskErrors += [PSCustomObject]@{pid=$taskRuntimeId;error=$_.Exception.Message} }
   finally { if ($null -ne $taskProcess) { $taskProcess.Dispose() } }
  }
  $taskPhase = if (Test-Path -LiteralPath $PhasePath) { [IO.File]::ReadAllText($PhasePath).Trim() } else { 'not-started' }
  $taskFrame = [PSCustomObject]@{time_unix_ms=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();phase=$taskPhase;threads=$taskRows;query_errors=$taskErrors}
  $taskWriter.WriteLine(($taskFrame | ConvertTo-Json -Depth 5 -Compress))
  $taskWriter.Flush()
  [Threading.Thread]::Sleep(500)
 }
} finally { $taskWriter.Dispose() }
