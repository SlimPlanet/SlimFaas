"""Separate four-attempt set diagnostic, sampling native Windows thread states."""
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ART = ROOT / 'artifacts'
OUTPUT = ART / 'pr504-native-thread-waits'
spec = importlib.util.spec_from_file_location('native_wait_harness', ROOT / '.bin/slimfaas-zlinq-benchmark.py')
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
original_run = harness.run
original_benchmark = harness.benchmark
sampler = ART / 'validation/sample-native-thread-waits.ps1'
assert not OUTPUT.exists(), 'Never overwrite a diagnostic campaign'
preflight = ART / 'validation/native-thread-preflight.jsonl'
stop_preflight = ART / 'validation/native-thread-preflight.stop'
assert not preflight.exists() and not stop_preflight.exists()
with (ART / 'validation/native-thread-preflight.log').open('w') as output:
    probe = subprocess.Popen(['pwsh', '-NoProfile', '-File', str(sampler), '-RuntimePidsCsv', str(os.getpid()),
        '-OutputPath', str(preflight), '-PhasePath', str(stop_preflight), '-StopPath', str(stop_preflight)],
        cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        deadline = time.monotonic() + 20
        while not preflight.exists() or not preflight.stat().st_size:
            if probe.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError('Thread-state capability preflight failed before measured attempts')
            time.sleep(0.1)
    finally:
        stop_preflight.write_text('stop\n')
        probe.wait(timeout=20)
    frames = [json.loads(line) for line in preflight.read_text().splitlines()]
    assert probe.returncode == 0 and frames and frames[0]['threads'] and not frames[0]['query_errors'], 'Preflight query did not work'
plan = {'rounds': 2, 'order': [['baseline-aot', 'candidate-aot'], ['candidate-aot', 'baseline-aot']],
        'load_seconds': 60, 'warmup_seconds': 5, 'clients': 16, 'payload_bytes': 4096,
        'sample_seconds': 0.5, 'initial_disk_reserve_bytes': 4 * 1024**3,
        'scope': 'ProcessThread state/wait-reason and cumulative CPU snapshots on three native runtime nodes. Not stack traces or exact scheduler dwell times; idle pool threads contribute.',
        'kernel_stack_limit': 'WPR installed but current Windows token is not elevated; no elevation attempted.',
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sampler_sha256': hashlib.sha256(sampler.read_bytes()).hexdigest(),
        'publications': json.loads((ART / 'runtime-final-comparison/source.json').read_text()),
        'retry_policy': 'One attempt per planned slot, no retries.'}
plan_path = ART / 'validation/native-wait-profile-plan.json'
assert not plan_path.exists()
plan_path.write_text(json.dumps(plan, indent=2) + '\n')

def guarded_benchmark(args, variant, round_number):
    if shutil.disk_usage(ROOT).free < plan['initial_disk_reserve_bytes']:
        directory = args.output / f'round-{round_number}-{variant}'
        directory.mkdir()
        harness.save(directory / 'not-started.json', {'reason': 'initial disk reserve'})
        raise RuntimeError('Disk precondition failed before diagnostic runtime startup')
    return original_benchmark(args, variant, round_number)

def profiled_run(command, log, **kwargs):
    if len(command) < 3 or not str(command[1]).endswith('SlimFaas.MemoryLab.dll') or command[2] != 'load':
        return original_run(command, log, **kwargs)
    output = log.parent / 'thread-states.jsonl'
    stop = log.parent / 'thread-sampler.stop'
    with (log.parent / 'thread-sampler.log').open('w') as sampler_log:
        monitor = subprocess.Popen(['pwsh', '-NoProfile', '-File', str(sampler), '-RuntimePidsCsv', ','.join(map(str, harness.NODE_PIDS)),
            '-OutputPath', str(output), '-PhasePath', str(log.parent / 'phase'), '-StopPath', str(stop)],
            cwd=ROOT, stdout=sampler_log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            deadline = time.monotonic() + 20
            while not output.exists() or not output.stat().st_size:
                if monitor.poll() is not None or time.monotonic() > deadline:
                    raise RuntimeError('Thread sampler did not become ready; diagnostic not started')
                time.sleep(0.1)
            harness.save(log.parent / 'profile-window.json', {'driver_start_ns': time.time_ns(), 'monitor_pid': monitor.pid})
            return original_run(command, log, **kwargs)
        finally:
            stop.write_text('stop\n')
            try:
                monitor.wait(timeout=20)
            except subprocess.TimeoutExpired:
                monitor.terminate()
                monitor.wait(timeout=20)
            harness.save(log.parent / 'thread-sampler-result.json', {'exit_code': monitor.returncode, 'finished_ns': time.time_ns()})
            if monitor.returncode:
                raise RuntimeError('Thread sampler failed; preserve the partial diagnostic')

harness.run = profiled_run
harness.benchmark = guarded_benchmark
sys.argv = ['slimfaas-zlinq-benchmark.py', '--publish-root', str(ART / 'runtime-final-comparison'), '--output', str(OUTPUT),
            '--rounds', '2', '--variants', 'baseline-aot,candidate-aot', '--duration', '20', '--warmup', '5',
            '--data-duration', '60', '--data-concurrency', '16', '--data-scenarios', 'slimdata-set',
            '--stream-messages', '0', '--dispatch-parallelism', '16', '--skip-http', '--continue-after-failure']
harness.main()
