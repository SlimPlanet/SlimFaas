# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T04:00:46.4991593+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 1.985 ms | 382.3 MiB |
| sync | 2 MiB | 16 | 28.200 ms | 470.5 MiB |
| async | 2 MiB | 16 | 171.313 ms | 504.0 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 25.186 ms | 103.241 ms | +78.055 ms (+309.9%) | 48.601 ms | 168.766 ms | +120.165 ms (+247.2%) | 60.714 ms | 208.271 ms | +147.557 ms (+243.0%) | 26.0 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 639 | 0 | 0 | 0 | 31.2/s | 507.945 ms | 485.221 ms | 778.449 ms | 1070.109 ms | 15230.657 ms | 17775.209 ms | 18940.035 ms | 19118.470 ms | 177.108 ms | 0.7402 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 7.3/s | 30.442 ms | 50.595 ms | 56.022 ms | 84.922 ms | 284.531 ms | 3.0500 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 206.8/s | 302.187 ms | 370.475 ms | 4299.188 ms | 4660.862 ms | 18.578 ms | 0.1610 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 30.128 ms |
| all HTTP 202 responses | 289.356 ms |
| desired replicas >= 1 | 1098.707 ms |
| ready replicas >= 1 | 3107.050 ms |
| desired replicas >= 4 | 4315.545 ms |
| ready replicas >= 4 | 9520.934 ms |
| queue drained | 24896.872 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
