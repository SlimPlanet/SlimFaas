# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T03:52:34.2542401+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 0.466 ms | 209.1 MiB |
| sync | 2 MiB | 16 | 28.688 ms | 263.2 MiB |
| async | 2 MiB | 16 | 137.659 ms | 298.5 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 37.294 ms | 110.156 ms | +72.862 ms (+195.4%) | 60.107 ms | 195.500 ms | +135.392 ms (+225.3%) | 72.539 ms | 242.989 ms | +170.451 ms (+235.0%) | 32.8 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 648 | 0 | 0 | 0 | 31.8/s | 500.201 ms | 492.495 ms | 684.444 ms | 744.772 ms | 11768.545 ms | 14234.271 ms | 14769.077 ms | 14836.725 ms | 136.140 ms | 0.8565 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 7.3/s | 30.112 ms | 45.827 ms | 56.903 ms | 81.159 ms | 292.969 ms | 2.9900 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 238.6/s | 261.675 ms | 328.662 ms | 3908.048 ms | 4142.383 ms | 12.906 ms | 0.1920 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 39.108 ms |
| all HTTP 202 responses | 305.574 ms |
| desired replicas >= 1 | 1085.315 ms |
| ready replicas >= 1 | 2148.787 ms |
| desired replicas >= 4 | 4338.230 ms |
| ready replicas >= 4 | 8553.444 ms |
| queue drained | 23871.114 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
