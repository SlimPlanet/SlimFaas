# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T03:47:13.2403792+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 1.838 ms | 375.3 MiB |
| sync | 2 MiB | 16 | 26.117 ms | 472.2 MiB |
| async | 2 MiB | 16 | 171.526 ms | 509.7 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 26.276 ms | 100.375 ms | +74.099 ms (+282.0%) | 50.828 ms | 165.961 ms | +115.132 ms (+226.5%) | 63.589 ms | 203.449 ms | +139.861 ms (+219.9%) | 27.7 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 626 | 0 | 0 | 0 | 30.6/s | 516.347 ms | 484.139 ms | 825.534 ms | 909.826 ms | 14617.124 ms | 16763.417 ms | 17331.350 ms | 17482.904 ms | 186.527 ms | 0.7444 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 6.6/s | 44.037 ms | 56.379 ms | 74.266 ms | 93.801 ms | 275.781 ms | 2.7100 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 222.2/s | 281.207 ms | 372.954 ms | 4034.343 ms | 4278.897 ms | 17.750 ms | 0.1440 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 18.590 ms |
| all HTTP 202 responses | 1204.648 ms |
| desired replicas >= 1 | 1015.991 ms |
| ready replicas >= 1 | 4209.530 ms |
| desired replicas >= 4 | 5258.821 ms |
| ready replicas >= 4 | 12669.319 ms |
| queue drained | 28904.357 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
