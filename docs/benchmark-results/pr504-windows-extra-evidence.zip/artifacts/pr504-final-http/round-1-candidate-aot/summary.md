# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T03:49:56.2863078+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 0.275 ms | 212.3 MiB |
| sync | 2 MiB | 16 | 21.531 ms | 261.5 MiB |
| async | 2 MiB | 16 | 138.258 ms | 287.9 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 23.309 ms | 79.761 ms | +56.452 ms (+242.2%) | 42.088 ms | 159.424 ms | +117.336 ms (+278.8%) | 54.253 ms | 223.029 ms | +168.776 ms (+311.1%) | 28.9 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 680 | 0 | 0 | 0 | 32.7/s | 478.451 ms | 474.899 ms | 631.875 ms | 730.236 ms | 12902.382 ms | 15070.038 ms | 16664.658 ms | 16835.276 ms | 128.125 ms | 0.8191 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 7.2/s | 32.112 ms | 37.529 ms | 57.020 ms | 66.028 ms | 333.594 ms | 2.6700 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 233.4/s | 267.304 ms | 349.402 ms | 3978.048 ms | 4224.662 ms | 13.391 ms | 0.1650 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 15.839 ms |
| all HTTP 202 responses | 260.509 ms |
| desired replicas >= 1 | 1086.346 ms |
| ready replicas >= 1 | 4264.668 ms |
| desired replicas >= 4 | 5360.669 ms |
| ready replicas >= 4 | 7551.884 ms |
| queue drained | 24727.274 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
