# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T03:57:53.5706940+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 0.204 ms | 212.3 MiB |
| sync | 2 MiB | 16 | 23.546 ms | 266.8 MiB |
| async | 2 MiB | 16 | 137.963 ms | 290.7 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 21.302 ms | 85.957 ms | +64.655 ms (+303.5%) | 37.734 ms | 174.948 ms | +137.214 ms (+363.6%) | 47.469 ms | 232.529 ms | +185.060 ms (+389.9%) | 24.6 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 681 | 0 | 0 | 0 | 33.5/s | 474.432 ms | 467.535 ms | 634.887 ms | 736.474 ms | 12831.653 ms | 14777.530 ms | 15104.704 ms | 15241.874 ms | 132.985 ms | 0.8605 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 7.5/s | 26.284 ms | 36.122 ms | 52.013 ms | 68.378 ms | 226.562 ms | 2.8800 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 242.8/s | 256.782 ms | 337.239 ms | 3923.690 ms | 4205.586 ms | 12.656 ms | 0.1590 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 22.136 ms |
| all HTTP 202 responses | 293.731 ms |
| desired replicas >= 1 | 1098.853 ms |
| ready replicas >= 1 | 3150.253 ms |
| desired replicas >= 4 | 4232.876 ms |
| ready replicas >= 4 | 6333.861 ms |
| queue drained | 23873.718 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
