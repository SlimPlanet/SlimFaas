# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T04:03:25.7804246+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 3.903 ms | 384.4 MiB |
| sync | 2 MiB | 16 | 34.440 ms | 459.2 MiB |
| async | 2 MiB | 16 | 245.293 ms | 504.0 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 43.336 ms | 122.088 ms | +78.753 ms (+181.7%) | 72.647 ms | 183.687 ms | +111.040 ms (+152.8%) | 86.907 ms | 205.784 ms | +118.876 ms (+136.8%) | 35.8 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 239 | 0 | 0 | 0 | 11.5/s | 1383.226 ms | 496.793 ms | 8677.392 ms | 8811.189 ms | 5364.434 ms | 6139.473 ms | 7176.773 ms | 7306.138 ms | 240.782 ms | 0.7657 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 6.6/s | 49.283 ms | 26.260 ms | 65.418 ms | 52.108 ms | 197.344 ms | 3.2900 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 267.2/s | 232.169 ms | 274.592 ms | 3728.402 ms | 4168.071 ms | 14.781 ms | 0.1690 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 26.085 ms |
| all HTTP 202 responses | 987.081 ms |
| desired replicas >= 1 | 983.838 ms |
| ready replicas >= 1 | 5425.046 ms |
| desired replicas >= 4 | 6399.008 ms |
| ready replicas >= 4 | 12712.594 ms |
| queue drained | 26825.632 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
