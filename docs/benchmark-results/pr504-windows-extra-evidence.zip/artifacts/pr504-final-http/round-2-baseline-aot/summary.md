# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T03:55:13.9180501+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 0.215 ms | 209.7 MiB |
| sync | 2 MiB | 16 | 25.692 ms | 268.4 MiB |
| async | 2 MiB | 16 | 140.906 ms | 297.9 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 21.295 ms | 90.109 ms | +68.815 ms (+323.2%) | 35.691 ms | 178.906 ms | +143.215 ms (+401.3%) | 44.305 ms | 222.042 ms | +177.737 ms (+401.2%) | 23.3 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 667 | 0 | 0 | 0 | 32.7/s | 486.974 ms | 479.213 ms | 683.549 ms | 757.121 ms | 12382.789 ms | 14876.697 ms | 15523.842 ms | 15795.519 ms | 133.527 ms | 0.8651 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 7.2/s | 30.675 ms | 44.809 ms | 57.366 ms | 77.540 ms | 308.438 ms | 2.5900 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 248.6/s | 250.340 ms | 315.739 ms | 3748.827 ms | 4062.405 ms | 12.828 ms | 0.1710 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 26.141 ms |
| all HTTP 202 responses | 319.283 ms |
| desired replicas >= 1 | 1100.227 ms |
| ready replicas >= 1 | 3262.046 ms |
| desired replicas >= 4 | 3262.046 ms |
| ready replicas >= 4 | 6497.088 ms |
| queue drained | 23719.236 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
