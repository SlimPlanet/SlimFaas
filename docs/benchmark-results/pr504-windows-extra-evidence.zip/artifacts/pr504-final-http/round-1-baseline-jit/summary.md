# SlimFaas local latency and scaling benchmark

Generated at `2026-11-10T03:44:13.1347277+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 10.0.14`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 2 MiB | 16 | 4.648 ms | 382.5 MiB |
| sync | 2 MiB | 16 | 35.260 ms | 460.2 MiB |
| async | 2 MiB | 16 | 167.432 ms | 514.5 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 49.416 ms | 133.348 ms | +83.932 ms (+169.8%) | 81.943 ms | 192.129 ms | +110.186 ms (+134.5%) | 105.701 ms | 220.470 ms | +114.770 ms (+108.6%) | 37.6 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 MiB | 16 | 619 | 0 | 0 | 0 | 30.5/s | 523.667 ms | 476.841 ms | 896.097 ms | 1328.764 ms | 14736.484 ms | 17367.015 ms | 18750.387 ms | 18990.942 ms | 176.747 ms | 0.7318 |

## Focused asynchronous workloads

| shape | repetition | messages | concurrency | failed | missing | duplicates | rate | HTTP mean | HTTP p95 | arrival mean | arrival p95 | CPU/msg | Raft/msg |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| paced | 1 | 100 | 1 | 0 | 0 | 0 | 5.0/s | 96.105 ms | 27.966 ms | 121.864 ms | 53.288 ms | 295.625 ms | 2.9300 |
| burst | 1 | 1000 | 64 | 0 | 0 | 0 | 193.9/s | 322.613 ms | 1143.811 ms | 3269.550 ms | 4086.116 ms | 16.250 ms | 0.1650 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 19.475 ms |
| all HTTP 202 responses | 234.796 ms |
| desired replicas >= 1 | 1090.237 ms |
| ready replicas >= 1 | 4285.810 ms |
| desired replicas >= 4 | 5353.518 ms |
| ready replicas >= 4 | 11709.114 ms |
| queue drained | 26160.113 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
