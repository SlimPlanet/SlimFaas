"""After WAL/replay closure, retain all four fixed-geometry threshold screens."""
from pathlib import Path
import json,subprocess,sys,time
E=Path.cwd()/'artifacts/pr506';P=E/'preflight/net11-91-offload-screen-sequence.json';assert not P.exists()
state=dict(started=time.time(),phase='waiting-for-90',passed=False,cases=[],
    source='189826231fe43fe3069e8a1f7724f83589432c6f',
    scope='Ungated 200x1MiB/C16 at fixed fresh WAL64KiB and two-copy policy; thresholds1MiB/512KiB/256KiB/128KiB, normal probes and full180s observation. All completed unhealthy observations are retained. Screening completion does not imply healthy results or performance acceptance. Defaults unchanged.')
def save(**kw):
    state.update(kw);t=P.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');t.replace(P)
try:
    save()
    while True:
        p=E/'preflight/net11-90-wal-replay-sequence.json'
        if p.exists():
            j=json.loads(p.read_text());assert j['phase']!='failed',j.get('error')
            if j.get('passed'):break
        time.sleep(5)
    for threshold in [1048576,524288,262144,131072]:
        label='net11-91-threshold-'+str(threshold)+'-01';namespace='slimfaas-pr506-os82-th'+str(threshold)+'-01';save(phase=label)
        args=[sys.executable,E/'profiles/offload-screen-net11-82/run-one.py','--namespace',namespace,
            '--chunk-size','65536','--variant','after','--offload-threshold',str(threshold),'--required-copies','2','--probes','normal']
        with(E/'logs'/(label+'.log')).open('xb')as f:
            r=subprocess.run([sys.executable,str(E/'run-net11-03-followup-command.py'),'--',*map(str,args)],stdout=f,stderr=subprocess.STDOUT)
        closed=json.loads((E/'profiles/offload-screen-net11-82'/namespace/'state.json').read_text())
        assert closed['phase']=='closed' and closed['quiescent_originals_indexed']
        state['cases'].append(dict(threshold_bytes=threshold,namespace=namespace,exit_code=r.returncode,workload_passed=closed['passed'],finished=time.time()));save()
    save(phase='closed',passed=True,finished=time.time(),healthy_all_cases=all(row['workload_passed']for row in state['cases']))
except BaseException as e:
    save(phase='failed',finished=time.time(),error=repr(e));raise
