"""Apply unchanged budget ratios to every enclosing reference, retaining all observations."""
from pathlib import Path
import argparse, hashlib, json, math, subprocess, time

p = argparse.ArgumentParser()
p.add_argument('--repeat', action='store_true')
a = p.parse_args()
E = Path.cwd() / 'artifacts/pr506'
B = E / 'profiles/offload-screen-net11-82'
output = E / ('preflight/net11-94-cost-comparison-repeat-01.json' if a.repeat else 'preflight/net11-94-cost-comparison-first-01.json')
assert not output.exists()
rows = []
inputs = []
for ordinal, copies in enumerate([0, 1, 2, 2, 1, 0], 1):
    name = 'slimfaas-pr506-os82-cost-' + ('r1-' if a.repeat else '') + str(ordinal) + '-copies' + str(copies)
    root = B / name
    state = json.loads((root / 'state.json').read_text())
    assert state['passed'] and state['quiescent_originals_indexed']
    report = json.loads((root / 'report.json').read_text())
    lat = report['latencies']
    cpu = report['resources']['scopes']['after-drain']['per_confirmed_message']['cpu_seconds']
    rows.append({'ordinal': ordinal, 'copies': copies, 'namespace': name,
        'accepted_rate': report['accepted_per_second'], 'delivery_rate': lat['delivery_rate_per_second'],
        'acceptance_p50': lat['acceptance_http_seconds']['p50'], 'acceptance_p95': lat['acceptance_http_seconds']['p95'],
        'acceptance_p99': lat['acceptance_http_seconds']['p99'],
        'delivery_p50': lat['delivery_intent_to_first_success_seconds']['p50'],
        'delivery_p95': lat['delivery_intent_to_first_success_seconds']['p95'],
        'delivery_p99': lat['delivery_intent_to_first_success_seconds']['p99'],
        'cpu_seconds_per_message': cpu, 'sampled_peak_runtime_rss_bytes': report['resources']['sampled_peak_aggregate_runtime_rss_bytes'],
        'confirmed': report['accepted'], 'unknown': report['unknown_count'], 'missing': report['missing_confirmed'],
        'extra_deliveries': report['bounded_repeated_deliveries'],
        'report_sha256': hashlib.sha256((root / 'report.json').read_bytes()).hexdigest()})
    index = json.loads((root / 'vm-file-index.json').read_text())
    frames = []
    for phase in ['before-send', 'after-drain']:
        names = [name for name in index['files'] if name.startswith('profile/resources-') and name.endswith('-' + phase + '.json')]
        assert len(names) == 1
        frames.append({'path': index['root'] + '/' + names[0], 'sha256': index['files'][names[0]]['sha256']})
    inputs.append(frames)
code = '''from pathlib import Path
import hashlib,json
inputs=INPUTS
result=[]
for frames in inputs:
 values=[]
 for frame in frames:
  raw=Path(frame['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==frame['sha256']
  doc=json.loads(raw);metric='slimdata_command_batch_raft_total'
  values.append(sum(n['metrics'][metric]for n in doc['nodes'])if all(metric in n['metrics']for n in doc['nodes'])else None)
 result.append(None if None in values else values[1]-values[0])
print(json.dumps(result))
'''.replace('INPUTS', repr(inputs))
raft = json.loads(subprocess.check_output(['podman', 'machine', 'ssh', 'sudo python3 -'], input=code, text=True))
for row, delta in zip(rows, raft):
    row['raft_batches_per_message'] = delta / row['confirmed'] if delta is not None else None
criteria = {'accepted_rate': ('min', .90), 'delivery_rate': ('min', .90),
    'acceptance_p95': ('max', 1.10), 'acceptance_p99': ('max', 1.10),
    'delivery_p95': ('max', 1.10), 'delivery_p99': ('max', 1.10),
    'cpu_seconds_per_message': ('max', 1.20), 'sampled_peak_runtime_rss_bytes': ('max', 1.10),
    'raft_batches_per_message': ('max', 2.0)}
pairs = {}
for reference in [rows[0], rows[5]]:
    for candidate in rows[1:5]:
        checks, ratios = {}, {}
        for name, (direction, threshold) in criteria.items():
            left, right = reference[name], candidate[name]
            if left is None or right is None or not all(math.isfinite(v) and v > 0 for v in [left, right]):
                checks[name], ratios[name] = None, None
            else:
                ratios[name] = right / left
                checks[name] = ratios[name] >= threshold if direction == 'min' else ratios[name] <= threshold
        pairs[str(reference['ordinal']) + '-' + str(candidate['ordinal'])] = {'checks': checks, 'ratios': ratios,
            'verdict': 'INCONCLUSIVE' if None in checks.values() else 'PASS' if all(checks.values()) else 'FAIL'}
conflict = any({pairs['1-' + str(n)]['verdict'],pairs['6-' + str(n)]['verdict']}=={'PASS','FAIL'} for n in range(2, 6))
result = {'created': time.time(), 'source': '189826231fe43fe3069e8a1f7724f83589432c6f',
    'scope': 'Same-source bounded200x1MiB/C16, WAL64KiB/offload512KiB, policies0/1/2/2/1/0. Diagnostic budget screen, not the formal HTTP matrix. CPU from first intent-to-drain resource window; final180s CPU includes idle polling and remains in original reports. All three runtime processes; sampled RSS; function/generator CPU excluded. Raft counter sums the existing batch-append metric across all runtimes, matching the formal comparer.',
    'repeat': a.repeat, 'rows': rows, 'criteria': criteria, 'pairs': pairs, 'contradictory_brackets': conflict,
    'verdict': 'INCONCLUSIVE' if conflict or any(x['verdict'] == 'INCONCLUSIVE' for x in pairs.values())
               else 'PASS' if all(x['verdict'] == 'PASS' for x in pairs.values()) else 'FAIL'}
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'file': str(output), 'contradictory_brackets': conflict, 'verdict': result['verdict'],
                 'pairs': {k: v['verdict'] for k, v in pairs.items()}}))
