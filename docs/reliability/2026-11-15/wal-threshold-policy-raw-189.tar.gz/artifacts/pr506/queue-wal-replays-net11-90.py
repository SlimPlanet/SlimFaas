"""Run fresh geometries serially after current-source ABBA controls close."""
from pathlib import Path
import json,subprocess,sys,time
E=Path.cwd()/'artifacts/pr506';P=E/'preflight/net11-90-wal-replay-sequence.json'
assert not P.exists()
state=dict(started=time.time(),phase='waiting-for-recovery89',source='189826231fe43fe3069e8a1f7724f83589432c6f',phases=[],passed=False,
    scope='Fresh 4/8/16/32/64 KiB WALs; fixed offload512KiB, RequiredDurableCopies2, 200x1MiB/C16, normal probes, full180s healthy observation. Separate gated confirmed async/Set/Files seeds followed by all-three-runtime restart on original volumes and another full180s observation. Diagnostic selection only; unchanged defaults.')
def save(**kw):
    state.update(kw);t=P.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');t.replace(P)
try:
    save()
    while True:
        p=E/'recovery-net11-89/report.json'
        if p.exists():
            j=json.loads(p.read_text());assert j['passed'],j.get('error')
            original=json.loads((E/'recovery-net11-89/original-preservation.json').read_text())
            assert original['original_still_matches_closed_index']
            break
        time.sleep(5)
    time.sleep(2)
    for size in [4096,8192,16384,32768,65536]:
        label='net11-90-wal-'+str(size)+'-01';save(phase=label)
        command=[sys.executable,E/'profiles/wal-replay-net11-88/run-one.py','--namespace','slimfaas-pr506-wr88-wal'+str(size)+'-01',
            '--chunk-size',str(size),'--variant','after','--offload-threshold','524288','--required-copies','2','--probes','normal']
        with(E/'logs'/(label+'.log')).open('xb')as f:
            r=subprocess.run([sys.executable,str(E/'run-net11-03-followup-command.py'),'--',*map(str,command)],stdout=f,stderr=subprocess.STDOUT)
        state['phases'].append(dict(label=label,chunk_bytes=size,exit_code=r.returncode,finished=time.time()));save();r.check_returncode()
    save(phase='closed',passed=True,finished=time.time())
except BaseException as e:
    save(phase='failed',finished=time.time(),error=repr(e));raise
