"""Current-source policy costs after closed threshold screens, with at most one repeat."""
from pathlib import Path
import json,subprocess,sys,time
E=Path.cwd()/'artifacts/pr506';P=E/'preflight/net11-92-current-cost-sequence.json';assert not P.exists()
state=dict(started=time.time(),source='189826231fe43fe3069e8a1f7724f83589432c6f',phase='waiting-for-91',passed=False,phases=[])
def save(**kw):
    state.update(kw);t=P.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');t.replace(P)
def run(label,args):
    save(phase=label)
    with(E/'logs'/(label+'.log')).open('xb')as f:r=subprocess.run([sys.executable,str(E/'run-net11-03-followup-command.py'),'--',*map(str,args)],stdout=f,stderr=subprocess.STDOUT)
    state['phases'].append(dict(label=label,exit_code=r.returncode,finished=time.time()));save();r.check_returncode()
def series(repeat):
    for ordinal,copies in enumerate([0,1,2,2,1,0],1):
        suffix=('r1-'if repeat else'')+str(ordinal)+'-copies'+str(copies)
        run('net11-92-cost-'+suffix,[sys.executable,E/'profiles/offload-screen-net11-82/run-one.py',
            '--namespace','slimfaas-pr506-os82-cost-'+suffix,'--chunk-size','65536','--variant','after',
            '--offload-threshold','524288','--required-copies',str(copies),'--probes','normal'])
    run('net11-94-cost-analysis-'+('repeat'if repeat else'first'),[sys.executable,E/'compare-current-durability-cost-net11-94.py',*(['--repeat']if repeat else[])])
try:
    save()
    while True:
        p=E/'preflight/net11-91-offload-screen-sequence.json'
        if p.exists():
            j=json.loads(p.read_text());assert j['phase']!='failed',j.get('error')
            if j.get('passed'):break
        time.sleep(5)
    time.sleep(2);series(False)
    first=json.loads((E/'preflight/net11-94-cost-comparison-first-01.json').read_text())
    if first['contradictory_brackets']:series(True)
    save(phase='closed',passed=True,finished=time.time(),scope='Completion only. Numerical policy-cost verdicts remain authoritative, including all failures/inconclusive observations; no repeat beyond one complete six-pass series.')
except BaseException as e:
    save(phase='failed',finished=time.time(),error=repr(e));raise
