"""Run an allocation probe only after the complete allowed cost repeat closes."""
from pathlib import Path
import hashlib, json, subprocess, sys, time

E = Path.cwd() / 'artifacts/pr506'
P = E / 'preflight/net11-47-pooled-hash-probe.json'
assert not P.exists()
state = {'started': time.time(), 'phase': 'waiting-for-cost-repeat', 'passed': False, 'phases': [],
    'scope': 'Isolated hashing-buffer allocation/CPU probe, no product change or application performance acceptance.'}

def save(**kw):
    state.update(kw)
    p = P.with_suffix('.tmp')
    p.write_text(json.dumps(state, indent=2) + '\n')
    p.replace(P)

try:
    save()
    while True:
        prior = json.loads((E / 'preflight/net11-43-cost-repeat-sequence.json').read_text())
        if prior['phase'] in ['closed', 'failed']:
            assert prior['passed'], prior
            break
        time.sleep(5)
    project = E / 'probes/pooled-hash-net11-47'
    commands = [
        ('build', ['dotnet', 'build', str(project / 'Probe.csproj'), '-c', 'Release', '-nr:false']),
        ('probe', ['dotnet', str(project / 'bin/Release/net11.0/Probe.dll'), str(project / 'observations')])]
    for name, command in commands:
        save(phase=name, command=command)
        log = E / 'logs' / ('net11-47-file-buffer-' + name + '.log')
        with log.open('xb') as stream:
            result = subprocess.run([sys.executable, str(E / 'run-net11-03-followup-command.py'), '--', *command], stdout=stream, stderr=subprocess.STDOUT)
        state['phases'].append({'name': name, 'exit_code': result.returncode, 'log': str(log.relative_to(E)),
                                'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
        save()
        result.check_returncode()
    save(phase='closed', passed=True, finished=time.time())
except BaseException as error:
    save(phase='failed', finished=time.time(), error=repr(error))
    raise
