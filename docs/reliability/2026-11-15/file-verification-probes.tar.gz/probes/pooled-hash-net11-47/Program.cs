using System.Buffers;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FileBufferProbe;

internal static class Program
{
    private const int Operations = 128;

    public static async Task Main(string[] args)
    {
        string directory = Path.GetFullPath(args[0]);
        Directory.CreateDirectory(directory);
        using var deadline = new CancellationTokenSource(TimeSpan.FromMinutes(10));
        using var process = Process.GetCurrentProcess();
        var rows = new List<BufferProbeRow>();
        foreach (int size in new[] { 64, 4096, 65536, 262144, 1048576, 4194304 })
        {
            byte[] payload = new byte[size];
            for (int index = 0; index < payload.Length; index++) payload[index] = (byte)(index % 251);
            byte[] checksum = SHA256.HashData(payload);
            string path = Path.Combine(directory, "body-" + size.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin");
            await File.WriteAllBytesAsync(path, payload, deadline.Token).ConfigureAwait(false);
            foreach (int concurrency in new[] { 1, 16 })
            {
                foreach (int bufferSize in new[] { 131072, -131072, -131072, 131072 })
                {
                    await ExerciseAsync(path, checksum, bufferSize, concurrency, 32, deadline.Token).ConfigureAwait(false);
                    long allocated = GC.GetTotalAllocatedBytes(precise: true);
                    TimeSpan cpu = process.TotalProcessorTime;
                    long started = Stopwatch.GetTimestamp();
                    await ExerciseAsync(path, checksum, bufferSize, concurrency, Operations, deadline.Token).ConfigureAwait(false);
                    double seconds = Stopwatch.GetElapsedTime(started).TotalSeconds;
                    TimeSpan cpuUsed = process.TotalProcessorTime - cpu;
                    long bytes = GC.GetTotalAllocatedBytes(precise: true) - allocated;
                    rows.Add(new(size, concurrency, Math.Abs(bufferSize), bufferSize < 0 ? "pooled-128KiB" : "framework", Operations, seconds, cpuUsed.TotalSeconds, bytes,
                        Convert.ToHexString(checksum), "Managed macOS microprobe: warm file cache, one shared read-only file per size, SHA256.HashDataAsync verification, all process allocations/CPU including task scheduling. No repository cache advice, persistence barriers or application-load verdict."));
                    Console.WriteLine(JsonSerializer.Serialize(rows[^1], ProbeJsonContext.Default.BufferProbeRow));
                }
            }
        }
        await File.WriteAllTextAsync(Path.Combine(directory, "results.json"),
            JsonSerializer.Serialize(rows.ToArray(), ProbeJsonContext.Default.BufferProbeRowArray), deadline.Token).ConfigureAwait(false);
    }

    private static async Task ExerciseAsync(string path, byte[] expected, int bufferSize, int concurrency, int operations, CancellationToken ct)
    {
        for (int completed = 0; completed < operations; completed += concurrency)
        {
            var tasks = new Task[Math.Min(concurrency, operations - completed)];
            for (int index = 0; index < tasks.Length; index++) tasks[index] = VerifyAsync(path, expected, bufferSize, ct);
            await Task.WhenAll(tasks).ConfigureAwait(false);
        }
    }

    private static async Task VerifyAsync(string path, byte[] expected, int bufferSize, CancellationToken ct)
    {
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read,
            Math.Abs(bufferSize), FileOptions.Asynchronous);
        byte[] actual = bufferSize < 0
            ? await PooledHashAsync(stream, ct).ConfigureAwait(false)
            : await SHA256.HashDataAsync(stream, ct).ConfigureAwait(false);
        if (!CryptographicOperations.FixedTimeEquals(actual, expected))
            throw new InvalidDataException("Hash verification failed in the buffer probe.");
    }
    private static async Task<byte[]> PooledHashAsync(Stream stream, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        byte[] buffer = ArrayPool<byte>.Shared.Rent(128 * 1024);
        try
        {
            int count;
            while ((count = await stream.ReadAsync(buffer.AsMemory(0, 128 * 1024), ct).ConfigureAwait(false)) != 0)
                hash.AppendData(buffer, 0, count);
            ct.ThrowIfCancellationRequested();
            return hash.GetHashAndReset();
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer, clearArray: true);
        }
    }

}

internal sealed record BufferProbeRow(int PayloadBytes, int Concurrency, int FileStreamBufferBytes, string Implementation,
    int Operations, double ElapsedSeconds, double CpuSeconds, long AllocatedBytes, string Sha256, string Scope);

[JsonSourceGenerationOptions(WriteIndented = true)]
[JsonSerializable(typeof(BufferProbeRow))]
[JsonSerializable(typeof(BufferProbeRow[]))]
internal sealed partial class ProbeJsonContext : JsonSerializerContext;
