"""One fresh, retained, explicitly scoped Kubernetes WAL diagnostic."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[4]
E=ROOT/'artifacts/pr506';BASE=Path(__file__).resolve().parent
K=['kubectl','--kubeconfig',str(E/'kubernetes/kubeconfig'),'--context','kind-slimfaas-pr506']
VARIANTS=json.loads((BASE/'variants.json').read_text())
p=argparse.ArgumentParser();p.add_argument('--namespace',required=True);p.add_argument('--chunk-size',type=int,choices=[4096,8192,16384,32768,65536],required=True);p.add_argument('--ready-only',action='store_true');p.add_argument('--fault-case',choices=['none','volume-loss','no-remote'],default='none');p.add_argument('--ingress-role',choices=['leader','follower'],default='follower');p.add_argument('--kind',choices=['async','file'],default='async');p.add_argument('--required-copies',type=int,choices=[0,1,2],default=2);p.add_argument('--probes',choices=['normal','endurance'],default='normal');p.add_argument('--variant',choices=['after'],required=True);p.add_argument('--offload-threshold',type=int,choices=[131072,262144,524288,1048576],required=True);p.add_argument('--payload-bytes',type=int,default=1048576);p.add_argument('--load-concurrency',type=int,choices=[1,16],default=16);p.add_argument('--messages',type=int,default=200);p.add_argument('--chunked',action='store_true');a=p.parse_args()
SOURCE=VARIANTS[a.variant]['source'];IMAGE=VARIANTS[a.variant]['image']
assert re.fullmatch(r'slimfaas-pr506-fa36-[a-z0-9-]+',a.namespace)and len(a.namespace)<=63
OUT=BASE/a.namespace;OUT.mkdir(exist_ok=False)
def write(name,value):
 path=OUT/name;t=path.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2)+'\n');t.replace(path)
def sha(path):
 with path.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
state={'started':time.time(),'namespace':a.namespace,'source':SOURCE,'image':IMAGE,'chunk_size':a.chunk_size,'ready_only':a.ready_only,'variant':a.variant,'offload_threshold_bytes':a.offload_threshold,'payload_bytes':a.payload_bytes,'concurrency':a.load_concurrency,'messages':a.messages,'chunked':a.chunked,'required_copies':a.required_copies,'probes':a.probes,'fault_case':a.fault_case,'ingress_role':a.ingress_role,'kind':a.kind};write('state.json',state)
# A reserve pause occurs before creating Kubernetes resources or starting traffic.
# Keep every completed ordinal and require 30 GiB after a low-space observation.
hold=E/'HOLD_NET11_04_MEASUREMENTS'
maintenance_started=None
while True:
 mac_free=shutil.disk_usage(ROOT).free
 vm_free=int(subprocess.check_output(['podman','machine','ssh','df','-B1','--output=avail','/'],text=True).splitlines()[-1])
 low=min(mac_free,vm_free)<20*2**30
 if low and not hold.exists():hold.write_text('Diagnostic preflight: free space below 20 GiB. Reclaim only verified inactive caches and restore 30 GiB before traffic.\n')
 if not low and not hold.exists():break
 if maintenance_started is None:maintenance_started=time.time()
 state.update(phase='waiting-for-disk-reserve',maintenance_started=maintenance_started,mac_free_bytes=mac_free,vm_free_bytes=vm_free);write('state.json',state)
 if min(mac_free,vm_free)>=30*2**30:
  state.update(maintenance_finished=time.time(),maintenance_gap_seconds=time.time()-maintenance_started);write('disk-maintenance.json',dict(state));hold.unlink(missing_ok=True);break
 time.sleep(10)
existing=subprocess.check_output(K+['get','namespace',a.namespace,'--ignore-not-found','-o','json'],text=True);assert not existing.strip()
vmroot='/var/home/core/slimfaas-pr506/runs/'+a.namespace
check='from pathlib import Path\np=Path('+repr(vmroot)+')\nassert not p.exists(),"Fresh diagnostic storage required"\n'
subprocess.run(['podman','machine','ssh','sudo python3 -'],input=check,text=True,check=True)
setup="from pathlib import Path\nmodule={}\nexec("+repr((ROOT/'.bin/slimdata_kubernetes_storage.py').read_text())+",module)\nmodule['prepare_control'](Path("+repr(vmroot)+")/'control',"+repr(a.namespace)+","+repr(SOURCE)+")\n"
subprocess.run(['podman','machine','ssh','sudo python3 -'],input=setup,text=True,check=True)
spec=importlib.util.spec_from_file_location('launcher',ROOT/'.bin/run-kubernetes-campaign.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
o=SimpleNamespace(namespace=a.namespace,controller_image=IMAGE,image=IMAGE,suite='chaos',probes=a.probes,source_commit=SOURCE,scenarios='payloads',roles='follower',durations='1',variant=a.variant,ordinal=1,workload_args=[])
items,config=m.resources(o)
for item in items:
 if item['kind']=='StatefulSet':
  pod=item['spec']['template']['spec'];runtime=next(c for c in pod['containers']if c['name']=='runtime')
  agent=next(c for c in pod['containers']if c['name']=='fault-agent')
  pod['volumes'].append({'name':'profile-observer','configMap':{'name':'profile-observer'}})
  agent['command']=['python3','/profile-observer/agent-profile.py']
  agent['volumeMounts']=[{'name':'profile-observer','mountPath':'/profile-observer','readOnly':True}]
  # This fixture is allowed to bootstrap only because both namespace and VM storage
  # were proven absent. A marker alone makes the normal automatic existing-state
  # check conservative, so explicitly bootstrap fresh pod zero for both geometries.
  runtime['env'].append({'name':'SlimData__Files__RequiredDurableCopies','value':str(a.required_copies)})
  runtime['env'].append({'name':'SlimFaas__AsyncBodyOffloadThresholdBytes','value':str(a.offload_threshold)})
  runtime['env'].append({'name':'POD_NAME','valueFrom':{'fieldRef':{'fieldPath':'metadata.name'}}})
  pod['volumes'].extend([{'name':'campaign-control','hostPath':{'path':'/evidence/runs/'+a.namespace+'/control','type':'Directory'}},{'name':'storage-fixture','configMap':{'name':'storage-fixture'}}])
  runtime['volumeMounts'].append({'name':'campaign-control','mountPath':'/campaign-control','readOnly':True})
  runtime['command']=['python3','-c']
  runtime['args']=["from pathlib import Path\nimport json,os,time\nwhile Path('/campaign-control/disabled-'+os.environ['POD_NAME']).exists():time.sleep(.1)\np=Path('/database/.profile-bootstrap-once');cold=False\nif os.environ['POD_NAME']=='slimfaas-0':\n try:\n  p.rename('/database/.profile-bootstrap-consumed');fd=os.open('/database',os.O_RDONLY|os.O_DIRECTORY)\n  try:os.fsync(fd)\n  finally:os.close(fd)\n  cold=True\n except FileNotFoundError:pass\nos.environ['SlimData__Configuration']=json.dumps({'coldStart':'true'if cold else'false'})\nos.execv('/app/SlimFaas',['/app/SlimFaas'])"]
  # Match the original HTTP snapshot policy, rather than the chaos stress policy.
  runtime['env']=[v for v in runtime['env']if v['name']not in ['SlimData__SnapshotIntervalEntries','SlimData__SnapshotIntervalBytes']]
  pod['initContainers'].append({'name':'verify-campaign-wal-geometry','image':IMAGE,'imagePullPolicy':'IfNotPresent','command':['python3','/storage-fixture/slimdata_kubernetes_storage.py','--root','/database','--control','/campaign-control','--node','$(POD_NAME)','--chunk-bytes',str(a.chunk_size),'--namespace',a.namespace,'--source',SOURCE],'env':[{'name':'POD_NAME','valueFrom':{'fieldRef':{'fieldPath':'metadata.name'}}}],'volumeMounts':[{'name':'state','mountPath':'/database'},{'name':'campaign-control','mountPath':'/campaign-control'},{'name':'storage-fixture','mountPath':'/storage-fixture','readOnly':True}]})
 if item['kind']=='Job'and item['metadata']['name']=='campaign-driver':
  pod=item['spec']['template']['spec'];driver=pod['containers'][0];base='/evidence/runs/'+a.namespace
  driver['command']=['python3','/profile/driver.py','--chunk-size',str(a.chunk_size),'--offload-threshold',str(a.offload_threshold),'--payload-bytes',str(a.payload_bytes),'--messages',str(a.messages),'--runtime','/app/SlimFaas','--backend-config','/config/backend.json','--output',base+'/profile','--source-commit',SOURCE,'--concurrency',str(a.load_concurrency),'--request-timeout','15','--recovery-timeout','180','--scenarios','payloads']+(['--ready-only']if a.ready_only else[])+(['--chunked']if a.chunked else[])
  pod['volumes'].append({'name':'profile-source','configMap':{'name':'profile-source'}});driver['volumeMounts'].append({'name':'profile-source','mountPath':'/profile','readOnly':True})
  if a.fault_case!='none':
   driver['command'][1]='/profile/file-admission-driver.py'
   driver['command']+=['--case',a.fault_case,'--ingress-role',a.ingress_role,'--kind',a.kind]
  item['spec']['activeDeadlineSeconds']=1800
items.append({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'storage-fixture','namespace':a.namespace,'labels':{'slimfaas-campaign':a.namespace,'app':'storage-fixture'}},'immutable':True,'data':{'slimdata_kubernetes_storage.py':(ROOT/'.bin/slimdata_kubernetes_storage.py').read_text()}})
items.append({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'profile-observer','namespace':a.namespace,'labels':{'slimfaas-campaign':a.namespace,'app':'profile-observer'}},'immutable':True,'data':{'agent-profile.py':(BASE/'agent-profile.py').read_text()}})
items.append({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'profile-source','namespace':a.namespace,'labels':{'slimfaas-campaign':a.namespace,'app':'profile-source'}},'immutable':True,'data':{'driver.py':(BASE/'driver.py').read_text(),'file-admission-driver.py':(BASE/'file-admission-driver.py').read_text(),'slimdata_kubernetes_storage.py':(ROOT/'.bin/slimdata_kubernetes_storage.py').read_text(),'observer.py':(BASE/'observer.py').read_text(),'measurements.py':(BASE/'measurements.py').read_text(),'variants.json':(BASE/'variants.json').read_text()}})
write('resources.json',{'apiVersion':'v1','kind':'List','items':items});write('backend.json',config)
write('provenance.json',{'source':SOURCE,'controller_checkout':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'image':IMAGE,'launcher_sha256':sha(ROOT/'.bin/run-kubernetes-campaign.py'),'driver_sha256':sha(BASE/'driver.py'),'observer_sha256':sha(BASE/'observer.py'),'coordinator_sha256':sha(Path(__file__)),'fresh_storage_required':True,'bootstrap_policy':'Durable one-shot coldStart true for fresh pod zero, false for every later process start and followers; identical across geometries. Never reinterpret or cold-bootstrap existing WALs.','snapshot_policy':'HTTP defaults: 500 entries / 32 MiB','note':'Diagnostic only; Python fsynced receipts/client ledger are reused without weakening their SHA/length/confirmed/unknown accounting. No existing WAL geometry is changed.'})
with(ROOT/'artifacts/platform-measurement.lock').open('a+')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 marker=ROOT/'artifacts/platform-measurement.json';assert not marker.exists();marker.write_text(json.dumps({'pid':os.getpid(),'output':str(OUT),'started':time.time(),'suite':'producer-session-memory-diagnostic'})+'\n')
 applied=False;terminal=False
 try:
  with(OUT/'apply.log').open('w')as log:subprocess.run(K+['apply','-f',str(OUT/'resources.json')],stdout=log,stderr=subprocess.STDOUT,check=True)
  applied=True;deadline=time.monotonic()+2100
  while time.monotonic()<deadline:
   job=json.loads(subprocess.check_output(K+['get','job','campaign-driver','-n',a.namespace,'-o','json'],text=True));status=job.get('status',{})
   state.update({'updated':time.time(),'phase':'driver-running','job_uid':job['metadata']['uid'],'job_status':status,'mac_free_bytes':shutil.disk_usage(ROOT).free});write('state.json',state)
   if(status.get('succeeded')or status.get('failed'))and not status.get('active'):terminal=True;break
   runtime_pods=json.loads(subprocess.check_output(K+['get','pods','-n',a.namespace,'-l','app=slimfaas,slimfaas-campaign='+a.namespace,'-o','json'],text=True))['items']
   m.collect_pod_logs(K,a.namespace,runtime_pods,OUT/'controller',previous_only=True)
   time.sleep(10)
  assert terminal,'Do not hash or discard while the diagnostic driver is active'
 finally:
  if applied:
   assert terminal,'Retain an active diagnostic for explicit cleanup; never hash live state'
   for action in ['collect','stop']:
    with(OUT/(action+'.log')).open('w')as log:subprocess.run([sys.executable,str(ROOT/'.bin/run-kubernetes-campaign.py'),action,'--kubeconfig',str(E/'kubernetes/kubeconfig'),'--namespace',a.namespace,'--output',str(OUT/'controller')],stdout=log,stderr=subprocess.STDOUT,check=True)
   assert json.loads((OUT/'controller/shutdown.json').read_text())['passed']
  report_code='from pathlib import Path\nprint(Path('+repr(vmroot+'/profile/report.json')+').read_text())\n'
  audit_report=json.loads(subprocess.check_output(['podman','machine','ssh','sudo python3 -'],input=report_code,text=True))
  log_audit=m.audit_runtime_logs(OUT/'controller',audit_report.get('ready_utc',audit_report['started_utc']),audit_report['finished_utc'])
  write('runtime-log-audit.json',log_audit)
  write('managed-oom-audit.json',{'nodes':[{'file':row['path'],'sha256':row['sha256'],'log_occurrences':row['managed_oom_log_occurrences']}for row in log_audit['instances']],
      'passed':log_audit['runtime_log_coverage_complete'] and not any(row['managed_oom_log_occurrences']for row in log_audit['instances']),
      'note':'Canonical current/previous logs by pod UID and restart index. Missing history cannot establish absence of managed OOM; OOM occurrences are not distinct exceptions.'})
  marker.unlink()
remote='from pathlib import Path\nimport hashlib,json\nr=Path('+repr(vmroot)+')\nfiles={}\nfor p in sorted(r.rglob("*")):\n if p.is_file()and not p.is_symlink():\n  with p.open("rb")as f:s=hashlib.file_digest(f,"sha256").hexdigest()\n  files[str(p.relative_to(r))]={"bytes":p.stat().st_size,"allocated_bytes":p.stat().st_blocks*512,"sha256":s}\nprint(json.dumps({"root":str(r),"files":files}))\n'
raw=json.loads(subprocess.check_output(['podman','machine','ssh','sudo python3 -'],input=remote,text=True));write('vm-file-index.json',raw)
report_code='from pathlib import Path\np=Path('+repr(vmroot+'/profile/report.json')+')\nprint(p.read_text()if p.exists()else "null")\n'
report=json.loads(subprocess.check_output(['podman','machine','ssh','sudo python3 -'],input=report_code,text=True));write('report.json',report)
with(OUT/'between-diagnostics-discard.log').open('w')as log:subprocess.run(['podman','machine','ssh','sudo','fstrim','-v','/'],stdout=log,stderr=subprocess.STDOUT,check=True)
state.update({'finished':time.time(),'phase':'closed','passed':bool(report and report['passed']and json.loads((OUT/'managed-oom-audit.json').read_text())['passed']and (a.fault_case!='none' or json.loads((OUT/'runtime-log-audit.json').read_text())['passed'])),'workload_started':bool(report and report['workload_started']),'originals_retained':vmroot,'quiescent_originals_indexed':True});write('state.json',state)
print(json.dumps(state),flush=True)
raise SystemExit(0 if state['passed']else 1)
