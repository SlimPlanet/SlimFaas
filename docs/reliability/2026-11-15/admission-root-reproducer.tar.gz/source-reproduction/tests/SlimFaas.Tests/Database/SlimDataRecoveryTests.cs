using System.Collections.Concurrent;
using System.IO.Pipelines;
using System.Net;
using DotNext.IO.Log;
using DotNext.Net.Cluster.Consensus.Raft;
using DotNext.Net.Cluster.Consensus.Raft.StateMachine;
using MemoryPack;
using Microsoft.AspNetCore.Connections;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using SlimData;
using SlimFaas.Database;
using SlimFaas.Jobs;
using SlimFaas.Options;

namespace SlimFaas.Tests.Database;

public sealed partial class SlimDataRecoveryTests
{
    private static readonly TimeSpan TestDeadline = TimeSpan.FromSeconds(12);

    [Theory]
    [InlineData(SlimDataBatchMode.Global)]
    [InlineData(SlimDataBatchMode.PartitionedByKey)]
    public async Task Known_length_body_that_never_arrives_times_out_and_retries_the_same_batch(SlimDataBatchMode mode)
    {
        var pipe = new Pipe();
        var requests = new ConcurrentQueue<byte[]>();
        using var handler = new Handler(async (request, token) =>
        {
            byte[] bytes = await request.Content!.ReadAsByteArrayAsync(token);
            requests.Enqueue(bytes);
            if (requests.Count == 1)
            {
                var content = new StreamContent(pipe.Reader.AsStream());
                content.Headers.ContentLength = 1;
                return new HttpResponseMessage(HttpStatusCode.OK) { Content = content };
            }
            return Reply(MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(bytes)!, "accepted");
        });
        await using var fixture = await Fixture.CreateAsync(handler, TimeSpan.FromSeconds(1), mode);
        try
        {
            IList<QueueData>? result = await fixture.Service.ListRightPopAsync("Job:recovery", "transaction").WaitAsync(TestDeadline);

            Assert.Equal("accepted", Assert.Single(result!).Id);
            byte[][] sent = requests.ToArray();
            Assert.Equal(2, sent.Length);
            Assert.Equal(sent[0], sent[1]);
        }
        finally
        {
            await pipe.Writer.CompleteAsync();
        }
    }

    [Theory]
    [InlineData(SlimDataBatchMode.Global)]
    [InlineData(SlimDataBatchMode.PartitionedByKey)]
    public async Task Large_batch_reply_is_read_from_its_stream_without_duplicating_the_body(SlimDataBatchMode mode)
    {
        byte[] value = Enumerable.Range(0, 1048576).Select(static index => (byte)(index % 251)).ToArray();
        StreamedContent? content = null;
        using var handler = new Handler(async (request, token) =>
        {
            byte[] bytes = await request.Content!.ReadAsByteArrayAsync(token);
            SlimDataCommandBatchRequest batch = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(bytes)!;
            SlimDataBatchOperation operation = Assert.Single(batch.Operations);
            content = new StreamedContent(MemoryPackSerializer.Serialize(new SlimDataCommandBatchResponse
            {
                ProducerId = batch.ProducerId,
                Sequence = batch.Sequence,
                RequestId = batch.RequestId,
                Results = [new SlimDataBatchOperationResult
                {
                    Kind = operation.Kind,
                    RequestId = operation.RequestId,
                    Applied = true,
                    QueueItems = [new QueueData("large", value, 0, false, 0, 0)]
                }]
            }));
            return new HttpResponseMessage(HttpStatusCode.OK) { Content = content };
        });
        await using var fixture = await Fixture.CreateAsync(handler, mode: mode);

        IList<QueueData>? result = await fixture.Service.ListRightPopAsync("Job:recovery", "transaction").WaitAsync(TestDeadline);

        Assert.Equal(value, Assert.Single(result!).Data);
        Assert.NotNull(content);
        Assert.Equal(0, content.BufferCopies);
        Assert.True(content.Disposed);
    }

    [Theory]
    [InlineData(SlimDataBatchMode.Global, false)]
    [InlineData(SlimDataBatchMode.Global, true)]
    [InlineData(SlimDataBatchMode.PartitionedByKey, false)]
    [InlineData(SlimDataBatchMode.PartitionedByKey, true)]
    public async Task Leader_epoch_change_cancels_the_old_http_request_without_waiting_for_client_timeout(
        SlimDataBatchMode mode, bool loseConsensus)
    {
        using var stalled = new StalledContent();
        using var oldConsensus = new CancellationTokenSource();
        CancellationToken consensus = oldConsensus.Token;
        var requests = new ConcurrentQueue<(Uri Uri, byte[] Payload)>();
        using var handler = new Handler(async (request, token) =>
        {
            byte[] bytes = await request.Content!.ReadAsByteArrayAsync(token);
            requests.Enqueue((request.RequestUri!, bytes));
            if (requests.Count == 1)
                return new(HttpStatusCode.OK) { Content = stalled };
            SlimDataCommandBatchRequest batch = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(bytes)!;
            return Reply(batch, "");
        });
        await using var fixture = await Fixture.CreateAsync(handler, Timeout.InfiniteTimeSpan, mode);
        fixture.Cluster.SetupGet(cluster => cluster.ConsensusToken).Returns(() => consensus);
        var queue = new JobQueue(fixture.Service);
        var first = queue.EnqueueAsync("recovery", [1]);
        await stalled.Started.Task.WaitAsync(TestDeadline);
        var next = queue.EnqueueAsync("recovery", [2]);

        fixture.LeaderPort = 3263;
        consensus = CancellationToken.None;
        if (loseConsensus)
            await oldConsensus.CancelAsync();
        else
            fixture.Cluster.Raise(cluster => cluster.LeaderChanged += null, fixture.Cluster.Object, fixture.Cluster.Object.Leader!);

        await first.WaitAsync(TestDeadline);
        await next.WaitAsync(TestDeadline);
        Assert.True(stalled.Disposed);
        var sent = requests.ToArray();
        Assert.Equal(3, sent.Length);
        Assert.Equal(3262, sent[0].Uri.Port);
        Assert.Equal(3263, sent[1].Uri.Port);
        Assert.Equal(sent[0].Payload, sent[1].Payload);
        SlimDataCommandBatchRequest retried = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(sent[1].Payload)!;
        SlimDataCommandBatchRequest following = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(sent[2].Payload)!;
        Assert.Equal(retried.Sequence + 1, following.Sequence);
        Assert.Equal(retried.GenerationId, following.GenerationId);
    }

    [Theory]
    [InlineData(SlimDataBatchMode.Global)]
    [InlineData(SlimDataBatchMode.PartitionedByKey)]
    public async Task Accepted_job_is_dequeued_after_response_body_timeout_and_leader_change(SlimDataBatchMode mode)
    {
        using var stalled = new StalledContent();
        var requests = new ConcurrentQueue<(Uri Uri, byte[] Payload)>();
        var popAttempts = 0;
        var acceptedJobId = string.Empty;
        using var handler = new Handler(async (request, token) =>
        {
            var bytes = await request.Content!.ReadAsByteArrayAsync(token);
            requests.Enqueue((request.RequestUri!, bytes));
            var batch = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(bytes)!;
            var operation = Assert.Single(batch.Operations);
            if (operation.Kind == SlimDataBatchOperationKind.ListLeftPush)
                acceptedJobId = operation.ElementId;
            // The leader has committed this dequeue, but its first response stalls.
            if (operation.Kind == SlimDataBatchOperationKind.ListRightPop &&
                Interlocked.Increment(ref popAttempts) == 1)
                return new(HttpStatusCode.OK) { Content = stalled };
            return Reply(batch, acceptedJobId);
        });
        await using var fixture = await Fixture.CreateAsync(handler, TimeSpan.FromSeconds(1), mode);
        var queue = new JobQueue(fixture.Service);
        var acceptedId = await queue.EnqueueAsync("recovery", [42]).WaitAsync(TestDeadline);
        var dequeue = queue.DequeueAsync("recovery");
        await stalled.Started.Task.WaitAsync(TestDeadline);
        fixture.LeaderPort = 3263;
        // A later mutation must stay behind the unresolved dequeue.
        var nextJob = queue.EnqueueAsync("recovery", [43]);

        var jobs = await dequeue.WaitAsync(TestDeadline);
        await nextJob.WaitAsync(TestDeadline);

        Assert.Equal(acceptedId, Assert.Single(jobs!).Id);
        Assert.False(string.IsNullOrEmpty(acceptedId));
        Assert.True(stalled.Disposed);
        var sent = requests.ToArray();
        Assert.Equal(4, sent.Length);
        Assert.Equal(3262, sent[1].Uri.Port);
        Assert.Equal(3263, sent[2].Uri.Port);
        Assert.Equal(sent[1].Payload, sent[2].Payload);
        var before = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(sent[1].Payload)!;
        var after = MemoryPackSerializer.Deserialize<SlimDataCommandBatchRequest>(sent[3].Payload)!;
        Assert.Equal(before.Sequence + 1, after.Sequence);
        Assert.Equal(before.ProducerId, after.ProducerId);
        Assert.Equal(before.GenerationId, after.GenerationId);
        Assert.NotEqual(before.RequestId, after.RequestId);
    }

    [Fact]
    public async Task Shutdown_cancels_stalled_body_and_queued_mutations_without_retrying()
    {
        using var stalled = new StalledContent();
        var attempts = 0;
        using var handler = new Handler((_, _) =>
        {
            Interlocked.Increment(ref attempts);
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = stalled });
        });
        await using var fixture = await Fixture.CreateAsync(handler, Timeout.InfiniteTimeSpan);
        var queue = new JobQueue(fixture.Service);
        var first = queue.EnqueueAsync("recovery", [1]);
        await stalled.Started.Task.WaitAsync(TestDeadline);
        var second = queue.EnqueueAsync("recovery", [2]);

        await fixture.Service.DisposeAsync().AsTask().WaitAsync(TestDeadline);

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => first.WaitAsync(TestDeadline));
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => second.WaitAsync(TestDeadline));
        Assert.True(stalled.Disposed);
        Assert.Equal(1, attempts);
    }

    [Theory]
    [InlineData("elements")]
    [InlineData("count")]
    [InlineData("dispatch")]
    [InlineData("hash")]
    public async Task Read_retries_after_local_apply_timeout_and_recovers(string readKind)
    {
        using Handler handler = new((_, _) => throw new InvalidOperationException("Read must not mutate"));
        await using Fixture fixture = await Fixture.CreateAsync(handler);
        using CancellationTokenSource cleanup = new();
        var attempts = 0;
        fixture.Log.WaitForApply = token =>
            Interlocked.Increment(ref attempts) == 1 ? StallApplyAsync(token, cleanup.Token) : ValueTask.CompletedTask;

        var read = ReadAsync(fixture.Service, readKind);
        try
        {
            await read.WaitAsync(TestDeadline);
            Assert.Equal(2, attempts);
        }
        finally
        {
            await cleanup.CancelAsync();
            try { await read.WaitAsync(TestDeadline); }
            catch (Exception) { /* Observe failures after releasing the test's stalled operation. */ }
        }
    }

    [Fact]
    public async Task Hashset_read_waits_for_the_leaders_read_barrier_before_observing_local_state()
    {
        using Handler handler = new((_, _) => throw new InvalidOperationException("Read must not mutate"));
        await using Fixture fixture = await Fixture.CreateAsync(handler);
        TaskCompletionSource barrier = new(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Cluster.Setup(c => c.ApplyReadBarrierAsync(ReadBarrierType.Weak, It.IsAny<CancellationToken>()))
            .Returns((ReadBarrierType _, CancellationToken token) => new ValueTask(barrier.Task.WaitAsync(token)));

        Task<IDictionary<string, byte[]>> read = fixture.Service.HashGetAllAsync("recovery");
        try
        {
            Assert.False(read.IsCompleted);
            fixture.Cluster.Verify(c => c.ApplyReadBarrierAsync(ReadBarrierType.Weak, It.IsAny<CancellationToken>()), Times.Once);
            barrier.SetResult();
            Assert.Empty(await read.WaitAsync(TestDeadline));
        }
        finally
        {
            barrier.TrySetResult();
            await read.WaitAsync(TestDeadline);
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Completed_weak_leader_barrier_does_not_expose_state_before_local_application(bool hashset)
    {
        using Handler handler = new((_, _) => throw new InvalidOperationException("Read must not mutate"));
        await using Fixture fixture = await Fixture.CreateAsync(handler);
        TaskCompletionSource applied = new(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Cluster.Setup(c => c.ApplyReadBarrierAsync(ReadBarrierType.Weak, It.IsAny<CancellationToken>()))
            .Returns(ValueTask.CompletedTask);
        fixture.Log.WaitForApply = token => new ValueTask(applied.Task.WaitAsync(token));
        Task read = hashset ? fixture.Service.HashGetAllAsync("recovery") : fixture.Service.GetAsync("recovery");
        try
        {
            Assert.False(read.IsCompleted);
        }
        finally
        {
            applied.TrySetResult();
            await read.WaitAsync(TestDeadline);
        }
    }

    [Fact]
    public async Task Persistent_local_apply_timeout_is_reported_as_unavailable()
    {
        using Handler handler = new((_, _) => throw new InvalidOperationException("Read must not mutate"));
        await using Fixture fixture = await Fixture.CreateAsync(handler);
        using CancellationTokenSource cleanup = new();
        fixture.Log.WaitForApply = token => StallApplyAsync(token, cleanup.Token);

        try
        {
            SlimDataUnavailableException error = await Assert.ThrowsAsync<SlimDataUnavailableException>(() =>
                fixture.Service.ListCountAsync("Job:recovery", [CountType.Available])
                    .WaitAsync(TimeSpan.FromSeconds(30)));
            Assert.Contains("local", error.Message, StringComparison.OrdinalIgnoreCase);
        }
        finally
        {
            await cleanup.CancelAsync();
        }
    }

    private static async ValueTask StallApplyAsync(CancellationToken token, CancellationToken cleanup)
    {
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(token, cleanup);
        await Task.Delay(Timeout.InfiniteTimeSpan, linked.Token);
    }

    private static async Task ReadAsync(SlimDataService service, string kind)
    {
        switch (kind)
        {
            case "elements": Assert.Empty(await service.ListCountElementAsync("Job:recovery", [CountType.Available])); break;
            case "count": Assert.Equal(0, await service.ListCountAsync("Job:recovery", [CountType.Available])); break;
            case "dispatch": Assert.Equal(QueueDispatchState.Empty, await service.GetQueueDispatchStateAsync("Job:recovery")); break;
            case "hash": Assert.Empty(await service.HashGetAllAsync("recovery")); break;
        }
    }

    private static HttpResponseMessage Reply(SlimDataCommandBatchRequest request, string acceptedJobId)
    {
        var operation = Assert.Single(request.Operations);
        var response = new SlimDataCommandBatchResponse
        {
            ProducerId = request.ProducerId,
            Sequence = request.Sequence,
            RequestId = request.RequestId,
            Results = [new SlimDataBatchOperationResult
            {
                Kind = operation.Kind, RequestId = operation.RequestId, Applied = true,
                ElementId = operation.ElementId,
                QueueItems = [new QueueData(acceptedJobId, [42], 1, false, 0, 0, "")]
            }]
        };
        return new(HttpStatusCode.OK) { Content = new ByteArrayContent(MemoryPackSerializer.Serialize(response)) };
    }

    private sealed class Fixture : IAsyncDisposable
    {
        private readonly string _directory;
        private readonly SlimPersistentState _state;
        private readonly ServiceProvider _services;
        private readonly HttpClient _client;
        public Mock<IRaftCluster> Cluster { get; } = new();
        public ControlledLog Log { get; }
        public int LeaderPort { get; set; } = 3262;
        public SlimDataService Service { get; }

        public static async Task<Fixture> CreateAsync(HttpMessageHandler handler, TimeSpan? timeout = null,
            SlimDataBatchMode mode = SlimDataBatchMode.Global)
        {
            var directory = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(directory);
            var state = new SlimPersistentState(directory);
            await state.RestoreAsync(CancellationToken.None);
            return new Fixture(handler, timeout, mode, directory, state);
        }

        private Fixture(HttpMessageHandler handler, TimeSpan? timeout, SlimDataBatchMode mode,
            string directory, SlimPersistentState state)
        {
            _directory = directory;
            _state = state;
            Log = new ControlledLog(new WriteAheadLog.Options { Location = Path.Combine(_directory, "wal") }, _state);
            _services = new ServiceCollection().AddSingleton(_state).BuildServiceProvider();
            var member = new Mock<IRaftClusterMember>();
            member.SetupGet(m => m.EndPoint).Returns(() => new UriEndPoint(new Uri($"http://127.0.0.1:{LeaderPort}")));
            Cluster.SetupGet(c => c.Leader).Returns(member.Object);
            Cluster.SetupGet(c => c.AuditTrail).Returns(Log);
            Cluster.Setup(c => c.ApplyReadBarrierAsync(ReadBarrierType.Weak, It.IsAny<CancellationToken>()))
                .Returns(ValueTask.CompletedTask);
            // Follower reads do not need a leader lease after local application.
            Cluster.SetupGet(c => c.LeadershipToken).Returns(new CancellationToken(true));
            var compatibility = new Mock<ISlimDataProtocolCompatibility>();
            compatibility.SetupGet(c => c.IsCompatible).Returns(true);
            _client = new HttpClient(handler, disposeHandler: false) { Timeout = timeout ?? TimeSpan.FromSeconds(10) };
            var factory = new Mock<IHttpClientFactory>();
            factory.Setup(f => f.CreateClient(SlimDataService.HttpClientName)).Returns(_client);
            Service = new SlimDataService(factory.Object, _services, Cluster.Object, compatibility.Object,
                new SlimDataInfo(3262), Microsoft.Extensions.Options.Options.Create(new SlimDataOptions { BatchMode = mode }),
                NullLogger<SlimDataService>.Instance);
        }

        public async ValueTask DisposeAsync()
        {
            await Service.DisposeAsync();
            _client.Dispose();
            await _services.DisposeAsync();
            await Log.DisposeAsync();
            await _state.DisposeAsync();
            Directory.Delete(_directory, recursive: true);
        }
    }

    // Keep DotNext's persistent-state implementation (its internal setter cannot
    // be proxied by Castle), overriding only the local-application observation.
    private sealed class ControlledLog(WriteAheadLog.Options options, IStateMachine state)
        : WriteAheadLog(options, state), IAuditTrail
    {
        public Func<CancellationToken, ValueTask> WaitForApply { get; set; } = _ => ValueTask.CompletedTask;
        long IAuditTrail.LastCommittedEntryIndex => 7L;
        ValueTask IAuditTrail.WaitForApplyAsync(long index, CancellationToken token)
        {
            Assert.Equal(7L, index);
            return WaitForApply(token);
        }
        ValueTask<TResult> IAuditTrail.ReadAsync<TResult>(ILogEntryConsumer<ILogEntry, TResult> reader,
            long startIndex, long endIndex, CancellationToken token) => throw new NotSupportedException();
    }

    private sealed class Handler(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> send) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            => send(request, cancellationToken);
    }

    private sealed class StreamedContent(byte[] bytes) : HttpContent
    {
        public int BufferCopies { get; private set; }
        public bool Disposed { get; private set; }
        protected override bool TryComputeLength(out long length) { length = bytes.Length; return true; }
        protected override Task<Stream> CreateContentReadStreamAsync()
            => Task.FromResult<Stream>(new MemoryStream(bytes, writable: false));
        protected override Task<Stream> CreateContentReadStreamAsync(CancellationToken cancellationToken)
            => CreateContentReadStreamAsync();
        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context)
        {
            BufferCopies++;
            return stream.WriteAsync(bytes).AsTask();
        }
        protected override void Dispose(bool disposing) { Disposed = true; base.Dispose(disposing); }
    }

    private sealed class StalledContent : HttpContent
    {
        public TaskCompletionSource Started { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public bool Disposed { get; private set; }
        protected override bool TryComputeLength(out long length) { length = 0; return false; }
        protected override Task SerializeToStreamAsync(Stream stream, TransportContext? context)
            => SerializeToStreamAsync(stream, context, CancellationToken.None);
        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext? context, CancellationToken cancellationToken)
        {
            Started.TrySetResult();
            await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
        }
        protected override void Dispose(bool disposing) { Disposed = true; base.Dispose(disposing); }
    }
}
