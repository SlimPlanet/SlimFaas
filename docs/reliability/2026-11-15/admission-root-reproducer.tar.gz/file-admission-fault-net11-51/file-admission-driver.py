"""Owned single-PV-content loss, absent-notification and fresh-volume recovery."""
import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback
from urllib.parse import quote

sys.path.insert(0, '/src/.bin')
spec = importlib.util.spec_from_file_location('local', '/src/.bin/test-slimdata-local-chaos.py')
local = importlib.util.module_from_spec(spec)
spec.loader.exec_module(local)
from slimdata_kubernetes_backend import create_campaign
from slimdata_kubernetes_storage import initialize_storage, sync_directory, write_new

parser = argparse.ArgumentParser()
parser.add_argument('--case', choices=['volume-loss'], required=True)
parser.add_argument('--ingress-role', choices=['leader', 'follower'], required=True)
parser.add_argument('--kind', choices=['async', 'file'], required=True)
parser.add_argument('--chunk-size', type=int, required=True)
parser.add_argument('--offload-threshold', type=int, required=True)
parser.add_argument('--payload-bytes', type=int, required=True)
parser.add_argument('--messages', type=int, required=True)
parser.add_argument('--chunked', action='store_true')
extra, remaining = parser.parse_known_args()
options = local.parse_arguments(remaining)
campaign = create_campaign(options, vars(local))
config = json.loads(options.backend_config.read_text())
output = campaign.output
run_root = Path(config['state_root']).parent
control = run_root / 'control'
result = {'started_utc': time.time(), 'source': options.source_commit, 'case': extra.case,
          'ingress_role': extra.ingress_role, 'kind': extra.kind, 'passed': False,
          'workload_started': False, 'injected_fault': True, 'actual_target_requests': 1, 'actual_concurrency': 1,
          'scope': 'Single owned runtime killed; its complete data-PV contents moved outside active mounts and never restored. Other data volumes retained. A paused third runtime is killed and returns without its in-memory announcements. Source rejoins with fresh storage. All kind workers share their VM; this is logical PV-content loss, not independent-host hardware proof.',
          'events': [], 'post_delivery_observation_seconds': 180}


def event(name, **values):
    row = {'utc': time.time(), 'event': name, **values}
    result['events'].append(row)
    campaign.client.append(row)
    (output / 'progress.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(row), flush=True)


def node_request(index, path, **kwargs):
    try:
        return local.request(campaign.ports[index], path, timeout=2, **kwargs)
    except local.NETWORK_ERRORS:
        return None, {}, b''


def file_root(index):
    return campaign.node_state_directory(index) / 'files'


def volume_root(index):
    value = campaign.node_state_directory(index).parent
    assert value.resolve().parent == (Path(config['state_root']) / 'data').resolve()
    assert value.name == f'slimfaas-{index}' and not value.is_symlink()
    return value


def storage_identity(index):
    path = volume_root(index) / '.slimfaas-files-storage-identity'
    return path.read_text().strip() if path.exists() else None


def local_file_ready(index, identifier, checksum):
    # Internal HEAD only inspects this repository: it cannot initiate a pull.
    try:
        status, _, _ = local.request(campaign.raft + index,
            '/cluster/files/' + quote(identifier, safe='') + '?sha=' + checksum,
            method='HEAD', timeout=2, redirects=False)
        return status == 200 and storage_identity(index) is not None
    except local.NETWORK_ERRORS:
        return False


def verify_local_body(index, identifier, checksum):
    status, _, body = local.request(campaign.raft + index,
        '/cluster/files/' + quote(identifier, safe='') + '?sha=' + checksum, timeout=10)
    assert status == 200 and len(body) == extra.payload_bytes and hashlib.sha256(body).hexdigest() == checksum


def gate_function():
    path = campaign.resource('deployments/chaos', apps=True)
    deployment = campaign.owned(campaign.api('GET', path))
    container = deployment['spec']['template']['spec']['containers'][0]
    original = container['command'] + container.get('args', [])
    gate = control / 'function-release'
    script = ('from pathlib import Path\nimport os,time\n'
              'while not Path(' + repr(str(gate)) + ').exists():time.sleep(.1)\n'
              'os.execvp(' + repr(original[0]) + ',' + repr(original) + ')')
    container['command'] = ['python3', '-c', script]
    container['args'] = []
    campaign.api('PATCH', path, {'spec': {'strategy': {'type': 'Recreate', 'rollingUpdate': None}, 'template': {'spec': {'containers': [container]}}}})

    def not_ready():
        for index in range(3):
            status, _, body = node_request(index, '/status-functions')
            if status != 200: return False
            row = next((row for row in json.loads(body) if row['Name'] == 'chaos'), None)
            if row is None or row['NumberReady'] != 0: return False
        return True
    local.wait_until('all runtime inventories see the gated function without a ready endpoint', not_ready, 180)
    event('function-gated')
    return gate


def quarantine_volume(index):
    root = volume_root(index)
    destination = run_root / 'volume-quarantine' / (f'slimfaas-{index}-' + str(time.time_ns()))
    destination.mkdir(parents=True, exist_ok=False)
    entries = []
    for child in list(root.iterdir()):
        stat = child.stat(follow_symlinks=False)
        target = destination / child.name
        child.rename(target)
        assert target.stat(follow_symlinks=False).st_ino == stat.st_ino
        entries.append({'name': child.name, 'device': stat.st_dev, 'inode': stat.st_ino})
    sync_directory(root)
    sync_directory(destination)
    assert not list(root.iterdir())
    (root / 'backup').mkdir()
    (root / 'backup').chmod(0o777)
    initialization = initialize_storage(root, control, f'slimfaas-{index}', extra.chunk_size,
                                        config['namespace'], options.source_commit)
    assert not initialization['fresh_bootstrap_permission']
    event('data-volume-contents-permanently-removed', node=index, quarantine=str(destination),
          retained_entries=entries, initialization=initialization)


try:
    campaign.start()
    result['ready_utc'] = time.time()
    result['initial_identities'] = [json.loads(campaign.node_pid(index)) for index in range(3)]
    expected = json.loads((Path(__file__).parent / 'variants.json').read_text())['after']['hashes']
    for identity in result['initial_identities']:
        for key, name in [('runtime', 'SlimFaas'), ('slimfaas_dll', 'SlimFaas.dll'), ('slimdata_dll', 'SlimData.dll')]:
            assert identity['binaries_sha256'][name] == expected[key]
    result['driver_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output / 'parameters.json').write_text(json.dumps(result | {'backend': config, 'configuration': vars(extra)}, indent=2) + '\n')
    gate = gate_function() if extra.kind == 'async' else None
    leader = campaign.leader()
    assert leader is not None
    ingress = leader if extra.ingress_role == 'leader' else next(index for index in range(3) if index != leader)
    absent = next(index for index in range(3) if index != ingress and (extra.ingress_role == 'leader' or index != leader))
    survivor = next(index for index in range(3) if index not in [ingress, absent])
    absent_handle = campaign.node_pid(absent)
    campaign.pause(absent_handle, True)
    campaign.suspended.add(absent_handle)
    event('third-node-suspended-before-upload', node=absent, identity=json.loads(absent_handle))
    before = {p.name for p in file_root(ingress).glob('*.bin')}
    body = (bytes(range(251)) * ((extra.payload_bytes + 250) // 251))[:extra.payload_bytes]
    checksum = hashlib.sha256(body).hexdigest()
    public_id = 'accepted-file-' + os.urandom(8).hex()
    path = '/async-function/chaos/volume-loss' if extra.kind == 'async' else '/data/files?id=' + public_id
    campaign.phase = 'acceptance-before-permanent-ingress-volume-loss'
    result['workload_started'] = True
    start = time.monotonic()
    status, _, _, identifier = campaign.mutate(extra.kind, path, body, port=campaign.ports[ingress],
        timeout=15, chunked=extra.chunked)
    assert status == (202 if extra.kind == 'async' else 200), (status, len(campaign.unknown))
    candidates = [p for p in file_root(ingress).glob('*.bin') if p.name not in before]
    assert len(candidates) == 1, candidates
    encoded = candidates[0].name[:-4]
    physical_id = base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4)).decode()
    assert physical_id.startswith('sf-internal-') and physical_id.endswith('-internal')
    head_status, head_headers, _ = local.request(campaign.raft + ingress,
        '/cluster/files/' + quote(physical_id, safe='') + '?sha=' + checksum, method='HEAD', timeout=2)
    tags = next(value for key, value in head_headers.items() if key.lower() == 'x-slimfaas-tags')
    def decode(value): return base64.urlsafe_b64decode(value + '=' * (-len(value) % 4)).decode()
    decoded_tags = {decode(key): decode(value) for key, value in (part.split('=', 1) for part in tags.split(';'))}
    assert head_status == 200 and decoded_tags['SlimFaasFileAdmissionToken']
    result.update(ingress_node=ingress, absent_node=absent, survivor_node=survivor,
                  identifier=identifier, physical_id=physical_id, sha256=checksum,
                  payload_bytes=len(body), acceptance_seconds=time.monotonic() - start)
    original_identity = storage_identity(ingress)
    assert original_identity and storage_identity(survivor) and original_identity != storage_identity(survivor)
    assert local_file_ready(survivor, physical_id, checksum)
    assert not list(file_root(absent).glob('*.bin'))
    event('accepted-with-two-declared-volume-copies', status=status, ingress_storage_identity=original_identity,
          survivor_storage_identity=storage_identity(survivor))
    write_new(control / f'disabled-slimfaas-{ingress}', b'permanent-original-volume-loss')
    ingress_handle = campaign.node_pid(ingress)
    campaign.kill_node(ingress_handle)
    event('ingress-runtime-killed', identity=json.loads(ingress_handle))
    local.wait_until('ingress no longer serves HTTP', lambda: node_request(ingress, '/health')[0] is None, 30)
    quarantine_volume(ingress)

    # SIGKILL discards both the in-memory notification mailbox and old socket
    # receive queues. Restart the third node rather than resuming old requests.
    campaign.kill_node(absent_handle)
    campaign.suspended.remove(absent_handle)
    event('absent-runtime-killed-without-consuming-historical-announcements', node=absent)
    local.wait_until('returned runtime listener', lambda: node_request(absent, '/health')[0] == 200, 180)
    majority_started = time.monotonic()
    local.wait_until('healthy-majority leader/readiness after listener recovery', lambda:
        node_request(survivor, '/ready')[0] == 200 and node_request(absent, '/ready')[0] == 200, 15)
    result['healthy_majority_recovery_seconds'] = time.monotonic() - majority_started
    ready_utc = time.time()
    event('returned-node-ready', node=absent, body_already_local=local_file_ready(absent, physical_id, checksum),
          identity=json.loads(campaign.node_pid(absent)))
    local.wait_until('durable-reference repair without historical announcements', lambda:
        local_file_ready(absent, physical_id, checksum), 180)
    verify_local_body(absent, physical_id, checksum)
    result['absent_node_catchup_after_ready_seconds'] = time.time() - ready_utc
    verify_local_body(survivor, physical_id, checksum)

    # The original bytes remain only in quarantine. Return the ingress with a
    # new identity over the empty data directory, never restoring those bytes.
    (control / f'disabled-slimfaas-{ingress}').unlink()
    sync_directory(control)
    local.wait_until('fresh-volume ingress readiness', lambda: node_request(ingress, '/ready')[0] == 200, 180)
    fresh_ready = time.time()
    local.wait_until('fresh ingress reference repair', lambda: local_file_ready(ingress, physical_id, checksum), 180)
    verify_local_body(ingress, physical_id, checksum)
    assert storage_identity(ingress) != original_identity
    result['fresh_ingress_catchup_after_ready_seconds'] = time.time() - fresh_ready
    event('fresh-ingress-repaired-without-bootstrap', node=ingress, original_storage_identity=original_identity,
          fresh_storage_identity=storage_identity(ingress), identity=json.loads(campaign.node_pid(ingress)))
    verified_file_nodes = []
    if gate is not None:
        write_new(gate, b'release-after-data-recovery')
        campaign.reconcile()
    else:
        for index in range(3):
            status, _, downloaded = local.request(campaign.ports[index], '/data/files/' + public_id, timeout=10)
            assert status == 200 and len(downloaded) == len(body) and hashlib.sha256(downloaded).hexdigest() == checksum
            verified_file_nodes.append(index)
    observation = time.monotonic()
    while time.monotonic() - observation < 180:
        for row in local.read_receipts(campaign.receipts):
            campaign.receipt_succeeded(row)
        time.sleep(.25)
    result['observed_after_delivery_seconds'] = time.monotonic() - observation
    accounting = campaign.audit()
    assert not accounting['repeated_deliveries'], accounting['repeated_deliveries']
    result.update(accounting=accounting, accepted=len(campaign.accepted), unknown_count=len(campaign.unknown),
                  missing_confirmed=campaign.missing if extra.kind == 'async' else sorted(set(range(3)) - set(verified_file_nodes)),
                  verified_public_file_nodes=verified_file_nodes, final_identities=[json.loads(campaign.node_pid(index)) for index in range(3)])
    campaign.capture('final')
    result['passed'] = True
except Exception:
    result['error'] = traceback.format_exc()
    (output / 'error.txt').write_text(result['error'])
finally:
    for handle in list(campaign.suspended):
        try: campaign.pause(handle, False)
        except Exception as error: result.setdefault('resume_errors', []).append(repr(error))
        campaign.suspended.discard(handle)
    result['finished_utc'] = time.time()
    (output / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ['events', 'accounting']}), flush=True)
raise SystemExit(0 if result['passed'] else 1)
