"""Bounded diagnostic: reuse the existing confirmed/unknown ledger and fsynced receipts."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import threading
import time
import traceback
from urllib.request import build_opener, ProxyHandler
from measurements import ledger_latencies, parse_metrics, resource_delta

sys.path.insert(0, '/src/.bin')
spec = importlib.util.spec_from_file_location('local', '/src/.bin/test-slimdata-local-chaos.py')
local = importlib.util.module_from_spec(spec)
spec.loader.exec_module(local)
from slimdata_kubernetes_backend import create_campaign

parser = argparse.ArgumentParser()
parser.add_argument('--chunk-size', type=int, required=True)
parser.add_argument('--offload-threshold',type=int,required=True)
parser.add_argument('--payload-bytes',type=int,required=True)
parser.add_argument('--messages',type=int,required=True)
parser.add_argument('--chunked',action='store_true')
parser.add_argument('--ready-only', action='store_true')
extra, remaining = parser.parse_known_args()
options = local.parse_arguments(remaining)
campaign = create_campaign(options, vars(local))
config = json.loads(options.backend_config.read_text())
output = campaign.output
result = {'started_utc': time.time(), 'source': options.source_commit,
          'chunk_size_marker_requested': extra.chunk_size, 'ready_only': extra.ready_only,
          'workload_started': False, 'passed': False,
          'mode': 'Linux ARM64 managed/trimmed .NET 11, bounded diagnostic, not formal performance acceptance',
          'messages_requested': 0 if extra.ready_only else extra.messages, 'payload_bytes': extra.payload_bytes, 'concurrency': options.concurrency,
          'offload_threshold_bytes':extra.offload_threshold,'chunked':extra.chunked,
          'post_send_observation_seconds': 180, 'request_timeout_seconds': 15,
          'fixture_note': 'Existing chaos function/client journals fsync every record; this instrumentation differs from the aggregate-only HTTP target.'}
for name, path in [('runtime', campaign.runtime), ('slimfaas_dll', campaign.runtime.parent / 'SlimFaas.dll'),
                   ('slimdata_dll', campaign.runtime.parent / 'SlimData.dll'), ('harness', Path(local.__file__)),
                   ('driver', Path(__file__))]:
    with path.open('rb') as stream:
        result[name + '_sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
expected = next(v for v in json.loads((Path(__file__).parent / 'variants.json').read_text()).values() if v['source'] == options.source_commit)
for key, digest in expected['hashes'].items():
    assert result[key + '_sha256'] == digest, (key, result[key + '_sha256'], digest)
(output / 'parameters.json').write_text(json.dumps(result | {'backend': config}, indent=2) + '\n')


sample_sequence = 0
runtime_samples = []
resource_frames = []
resource_errors = []
resource_lock = threading.Lock()
sampler_stop = threading.Event()
sampler_thread = None


def inventory(root):
    files = []
    races = 0
    for path in root.rglob('*'):
        try:
            if path.is_file() and not path.is_symlink():
                stat = path.stat()
                files.append({'path':str(path.relative_to(root)), 'bytes':stat.st_size, 'allocated_bytes':stat.st_blocks * 512})
        except FileNotFoundError:
            races += 1
    return {'files':files, 'files_disappeared_during_scan':races,
            'scope':'Live retained files only; neither cumulative bytes written nor a guarantee that a subsecond peak was observed.'}


def capture_resources(phase):
    frame = {'utc_started':time.time(), 'phase':phase, 'nodes':[]}
    opener = build_opener(ProxyHandler({}))
    for index, node in enumerate(config['nodes']):
        status, _, body = local.request(campaign.ports[index], '/metrics', timeout=2, redirects=False)
        if status != 200:
            raise RuntimeError(f'Resource metrics node {index}: HTTP {status}')
        with opener.open(node['control'] + '/profile', timeout=2) as response:
            proc = json.load(response)
        state_root = campaign.node_state_directory(index)
        frame['nodes'].append({'node':index, 'metrics':parse_metrics(body), 'process':proc,
                               'wal':inventory(state_root/'wal'), 'files':inventory(state_root/'files')})
    frame['utc_finished'] = time.time()
    with resource_lock:
        sequence = len(resource_frames)
        (output/f'resources-{sequence:04}-{phase}.json').write_text(json.dumps(frame,indent=2)+'\n')
        resource_frames.append(frame)
    return frame


def sample_resources():
    while not sampler_stop.wait(1):
        try:
            capture_resources('periodic')
        except Exception as error:
            resource_errors.append({'utc':time.time(),'error':repr(error)})


def summarize_resources():
    client = [json.loads(line) for line in campaign.client.path.read_text().splitlines()]
    result['latencies'] = ledger_latencies(client, local.read_receipts(campaign.receipts))
    frames = list(resource_frames)
    before = next(x for x in frames if x['phase']=='before-send')
    scopes = {}
    for phase in ['after-send','after-drain','final']:
        after = next((x for x in frames if x['phase']==phase),None)
        if after is None:
            continue
        for a,b in zip(before['nodes'],after['nodes']):
            if a['process']['identity']!=b['process']['identity']:
                raise RuntimeError('Runtime process identity changed during resource comparison')
        scopes[phase] = resource_delta([x['metrics']for x in before['nodes']],
                                      [x['metrics']for x in after['nodes']],len(campaign.accepted))
        scopes[phase]['utc_window']=[before['utc_started'],after['utc_finished']]
        scopes[phase]['runtime_io_delta']=[{key: b['process']['runtime_io'][key]-value
                                            for key,value in a['process']['runtime_io'].items()}
                                           for a,b in zip(before['nodes'],after['nodes'])]
        scopes[phase]['pod_network_delta']=[{interface:{key:b['process']['pod_network'][interface][key]-value
                                                       for key,value in counters.items()}
                                             for interface,counters in a['process']['pod_network'].items()}
                                            for a,b in zip(before['nodes'],after['nodes'])]
    result['resources']={'scopes':scopes,'sampling_interval_seconds':1,'sampling_errors':resource_errors,
                         'sampled_peak_aggregate_runtime_rss_bytes':max(sum(n['process']['rss_bytes']for n in x['nodes'])for x in frames),
                         'sampled_peak_aggregate_wal_logical_bytes':max(sum(f['bytes']for n in x['nodes']for f in n['wal']['files'])for x in frames),
                         'sampled_peak_aggregate_wal_file_count':max(sum(len(n['wal']['files'])for n in x['nodes'])for x in frames),
                         'sampled_peak_aggregate_files_logical_bytes':max(sum(f['bytes']for n in x['nodes']for f in n['files']['files'])for x in frames),
                         'scope':'All three runtime processes; network includes probes/measurement/function traffic. Kernel I/O is not attributed to WAL vs Files. Inventories/peak RSS are sampled, not continuous maxima. The after-drain sample is within observer cadence of the first all-confirmed reconciliation, while the full 180-second window still runs.'}


def sample(deadline):
    global sample_sequence
    if time.monotonic() + 24 >= deadline:
        return
    sequence = sample_sequence
    sample_sequence += 1
    captured = {'utc': time.time(), 'nodes': [],
                'guest_diskstats': Path('/proc/diskstats').read_text(),
                'guest_io_pressure': Path('/proc/pressure/io').read_text()}
    failures = []
    for index, port in enumerate(campaign.ports):
        node = {'node': index, 'url': local.endpoint(port)}
        try:
            status, headers, body = local.request(port, '/metrics', timeout=1, redirects=False)
            (output / f'sample-{sequence:03}-node-{index}.prom').write_bytes(body)
            node.update({'metrics_status': status, 'metrics_location': headers.get('Location')})
            if status != 200:
                failures.append(f'node {index}: metrics HTTP {status}')
            leader_status, headers, address = local.request(campaign.raft + index, '/SlimData/leader', timeout=1, redirects=False)
            node.update({'leader_status': leader_status, 'leader_address': address[:1000].decode(errors='replace'), 'leader_location': headers.get('Location')})
        except local.NETWORK_ERRORS as error:
            node['error'] = repr(error)
            failures.append(f'node {index}: {error!r}')
        captured['nodes'].append(node)
    pods = campaign.api('GET', campaign.resource('pods'))['items']
    captured['runtime_pods'] = [{'name': pod['metadata']['name'], 'uid': pod['metadata']['uid'],
                                'node': pod['spec'].get('nodeName'),
                                'containers': pod.get('status', {}).get('containerStatuses', [])}
                               for pod in pods if pod['metadata'].get('labels', {}).get('app') == 'slimfaas']
    runtime_samples.append(captured['runtime_pods'])
    campaign.client.append({'event': 'diagnostic-sample', **captured})
    if failures:
        raise RuntimeError('; '.join(failures))


try:
    campaign.start()
    result['ready_utc'] = time.time()
    markers = []
    for node in range(3):
        path = campaign.node_state_directory(node) / 'wal/slimdata-chunk-size'
        value = path.read_text() if path.exists() else None
        assert value == (str(extra.chunk_size) if extra.chunk_size else None)
        markers.append({'node': node, 'path': str(path), 'value': value})
    result['markers'] = markers
    campaign.capture('initial')
    if not extra.ready_only:
        campaign.phase = f'bounded-{extra.messages}-messages-{extra.payload_bytes}-bytes-c{options.concurrency}'
        capture_resources('before-send')
        sampler_thread=threading.Thread(target=sample_resources,daemon=True)
        sampler_thread.start()
        result['workload_started'] = True
        started = time.monotonic()
        def send(_):
            import uuid
            identifier = uuid.uuid4().hex
            return campaign.mutate('async', '/async-function/chaos/consume',
                                   local.payload(extra.payload_bytes, identifier), identifier=identifier,chunked=extra.chunked)
        with ThreadPoolExecutor(max_workers=options.concurrency) as pool:
            responses = list(pool.map(send, range(extra.messages)))
        result['send_seconds'] = time.monotonic() - started
        result['accepted'] = len(campaign.accepted)
        result['unknown_count'] = len(campaign.unknown)
        result['unexpected_http_statuses'] = [status for status, _, _, _ in responses if status != 202]
        result['accepted_per_second'] = len(campaign.accepted) / result['send_seconds']
        capture_resources('after-send')
        from observer import observe_window
        cutoff = time.time() + 180
        observation_started = time.monotonic()
        drain_captured = False
        def observation_sample(deadline):
            global drain_captured
            if not drain_captured and campaign.accepted:
                completed = {row['id'] for row in local.read_receipts(campaign.receipts) if campaign.receipt_succeeded(row)}
                if set(campaign.accepted).issubset(completed):
                    capture_resources('after-drain')
                    drain_captured = True
            sample(deadline)
        errors = observe_window(180, lambda: local.read_receipts(campaign.receipts),
                                campaign.receipt_succeeded, observation_sample)
        result['observation_errors'] = errors
        result['observed_after_send_seconds'] = time.monotonic() - observation_started
        rows = [row for row in local.read_receipts(campaign.receipts) if row['utc'] <= cutoff]
        valid = []
        for row in rows:
            try:
                if campaign.receipt_succeeded(row):
                    valid.append(row)
            except Exception as error:
                errors['integrity'].append({'id': row.get('id'), 'error': repr(error)})
        counts = {}
        for row in valid:
            counts[row['id']] = counts.get(row['id'], 0) + 1
        result['missing_confirmed'] = sorted(set(campaign.accepted) - counts.keys())
        result['bounded_repeated_deliveries'] = {key: count for key, count in counts.items() if count > 1}
        result['accounting'] = campaign.audit()
        result['max_observed_container_restarts'] = max((container.get('restartCount', 0)
            for frame in runtime_samples for pod in frame for container in pod['containers']), default=0)
        result['passed'] = (not result['missing_confirmed']
                            and not result['bounded_repeated_deliveries']
                            and not result['unexpected_http_statuses']
                            and not any(errors.values())
                            and result['max_observed_container_restarts'] == 0)
        sampler_stop.set()
        sampler_thread.join(timeout=20)
        if sampler_thread.is_alive():
            raise RuntimeError('Resource sampler did not close before final export')
        capture_resources('final')
        summarize_resources()
        result['passed'] = result['passed'] and not resource_errors
    else:
        preflight = capture_resources('preflight')
        resource_delta([x['metrics'] for x in preflight['nodes']],
                       [x['metrics'] for x in preflight['nodes']],1)
        if any(x['process']['rss_bytes'] <= 0 for x in preflight['nodes']):
            raise RuntimeError('Runtime RSS is unavailable')
        result['passed'] = True
    campaign.capture('final')
except Exception:
    result['passed'] = False
    result['error'] = traceback.format_exc()
    (output / 'error.txt').write_text(result['error'])
finally:
    sampler_stop.set()
    if sampler_thread is not None:
        sampler_thread.join(timeout=20)
    result['finished_utc'] = time.time()
    (output / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['markers', 'accounting', 'error']}), flush=True)
    if result.get('error'):
        print(result['error'], flush=True)
raise SystemExit(0 if result['passed'] else 1)
