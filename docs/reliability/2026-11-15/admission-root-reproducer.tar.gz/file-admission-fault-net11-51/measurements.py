"""Conservative summaries; absent/reset measurements are never treated as zero."""
import math


def distribution(values):
    values = sorted(values)
    if not values:
        return {"count": 0, "mean": None, "p50": None, "p95": None, "p99": None}
    if any(not math.isfinite(x) or x < 0 for x in values):
        raise ValueError("Invalid latency observation")
    def percentile(p):
        position = (len(values) - 1) * p
        left = int(position)
        return values[left] + (values[min(left + 1, len(values) - 1)] - values[left]) * (position - left)
    return {"count": len(values), "mean": sum(values) / len(values),
            "p50": percentile(.5), "p95": percentile(.95), "p99": percentile(.99)}


def parse_metrics(body):
    result = {}
    for line in body.decode().splitlines():
        if not line or line.startswith("#"):
            continue
        key, value = line.rsplit(" ", 1)
        result[key] = float(value)
    return result


def resource_delta(before, after, accepted):
    if len(before) != 3 or len(after) != 3:
        raise ValueError("All three nodes are required")
    if not accepted:
        raise ValueError("No confirmed acceptance denominator")
    names = {"cpu_seconds": "process_cpu_seconds_total",
             "allocated_bytes": "system_runtime_dotnet_gc_heap_total_allocated"}
    names.update({f"gc_gen{g}": f'dotnet_collection_count_total{{generation="{g}"}}' for g in range(3)})
    totals = {}
    for name, metric in names.items():
        values = [b[metric] - a[metric] for a, b in zip(before, after)]
        if any(not math.isfinite(x) or x < 0 for x in values):
            raise ValueError("Missing, nonfinite or reset cumulative counter: " + metric)
        totals[name] = sum(values)
    return {"total_all_three_runtime_processes": totals,
            "per_confirmed_message": {key: value / accepted for key, value in totals.items()},
            "scope": "Runtime processes only, including Raft/Files/proxy/telemetry. Excludes generator, agents and functions. Cumulative allocated bytes differ from retained managed heap or RSS."}


def ledger_latencies(client, receipts):
    accepted = {x["id"]: x for x in client if x.get("event") == "accepted" and x.get("kind") == "async"}
    intents = {x["id"]: x for x in client if x.get("event") == "intent" and x.get("kind") == "async"}
    unknown = {x["id"] for x in client if x.get("event") == "unknown" and x.get("kind") == "async"}
    delivered = {}
    for row in receipts:
        identifier = row.get("id")
        if identifier not in accepted or row.get("event") != "completed" or not 200 <= row.get("status", 0) < 300:
            continue
        expected = accepted[identifier]
        if row["sha256"] != expected["sha256"] or row["bytes"] != expected["bytes"]:
            raise ValueError("Corrupt successful receipt for " + identifier)
        delivered[identifier] = min(delivered.get(identifier, math.inf), row["utc"])
    acceptance = distribution([x["seconds"] for x in accepted.values()])
    delivery = distribution([utc - intents[identifier]["utc"] for identifier, utc in delivered.items()])
    complete = bool(accepted) and set(delivered) == set(accepted)
    seconds = max(delivered.values()) - min(intents[identifier]["utc"] for identifier in accepted) if complete else None
    return {"confirmed": len(accepted), "unknown": len(unknown), "confirmed_delivered": len(delivered),
            "acceptance_http_seconds": acceptance, "delivery_intent_to_first_success_seconds": delivery,
            "delivery_rate_per_second": len(accepted) / seconds if seconds and seconds > 0 else None,
            "all_confirmed_delivered": complete,
            "scope": "Acceptance uses client HTTP elapsed time. Delivery starts at the fsynced client intent timestamp and ends at the first successful handler completion record, before receipt fsync. All pods share the same VM UTC clock. Unknown outcomes stay separate even if delivered; extra deliveries are evaluated independently."}
