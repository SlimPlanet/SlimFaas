"""Read-only resource observations for the exact runtime already fenced by the fault agent."""
from http.server import ThreadingHTTPServer
import importlib.util
import os
from pathlib import Path
import time

spec = importlib.util.spec_from_file_location("fault_agent", "/src/.bin/slimdata_fault_agent.py")
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
identity = None


def sample():
    global identity
    if identity is None:
        identity = agent.runtime_identity()
    root = Path("/proc") / str(identity["pid"])
    stat = (root / "stat").read_text().rsplit(")", 1)[1].split()
    if (root.stat().st_uid != 1000 or str((root / "exe").readlink()) != "/app/SlimFaas"
            or stat[19] != identity["started"] or identity["pod_uid"] != os.environ["POD_UID"]):
        raise RuntimeError("Runtime identity changed during the resource window")
    io = {k.strip(): int(v.strip()) for k, v in
          (line.split(":", 1) for line in (root / "io").read_text().splitlines())}
    network = {}
    for line in (root / "net/dev").read_text().splitlines()[2:]:
        interface, counters = line.split(":", 1)
        values = counters.split()
        if interface.strip() != "lo":
            network[interface.strip()] = {"rx_bytes": int(values[0]), "tx_bytes": int(values[8])}
    with (root / "maps").open() as mappings:
        mapping_count = sum(1 for _ in mappings)
    return {"utc": time.time(), "identity": identity, "runtime_io": io,
            "pod_network": network, "cpu_user_ticks": int(stat[11]), "cpu_system_ticks": int(stat[12]),
            "clock_ticks_per_second": os.sysconf("SC_CLK_TCK"), "rss_bytes": int(stat[21]) * os.sysconf("SC_PAGE_SIZE"),
            "mappings": mapping_count,
            "file_descriptors": sum(1 for _ in (root / "fd").iterdir()),
            "scope": "Runtime process I/O and CPU; pod network includes Raft, Files, functions, probes and measurement traffic. No per-WAL physical write attribution."}


class Handler(agent.Handler):
    def do_GET(self):
        if self.path != "/profile":
            return super().do_GET()
        try:
            self.reply(200, sample())
        except (OSError, ValueError, RuntimeError) as error:
            self.reply(503, {"error": str(error)})


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", 39777), Handler).serve_forever()
