"""Keep Raft writable while denying body persistence on both remote repositories."""
import argparse, hashlib, importlib.util, json, os, stat, sys, time, traceback
from pathlib import Path

sys.path.insert(0, '/src/.bin')
spec = importlib.util.spec_from_file_location('local', '/src/.bin/test-slimdata-local-chaos.py')
local = importlib.util.module_from_spec(spec)
spec.loader.exec_module(local)
from slimdata_kubernetes_backend import create_campaign

p = argparse.ArgumentParser()
p.add_argument('--case', choices=['no-remote'], required=True)
p.add_argument('--chunk-size', type=int, required=True)
p.add_argument('--offload-threshold', type=int, required=True)
p.add_argument('--payload-bytes', type=int, required=True)
p.add_argument('--messages', type=int, required=True)
p.add_argument('--ingress-role')
p.add_argument('--kind')
p.add_argument('--chunked', action='store_true')
extra, remaining = p.parse_known_args()
options = local.parse_arguments(remaining)
c = create_campaign(options, vars(local))
result = {'started_utc': time.time(), 'source': options.source_commit, 'case': extra.case,
          'passed': False, 'workload_started': False, 'events': [], 'post_send_observation_seconds': 180,
          'scope': 'Both remote Files directories are read-only for the UID1000 runtimes; their WAL directories remain writable. No process interruption or quorum loss is injected. HTTP 5xx remain unknown outcomes in the original ledger.'}
permissions = []

def event(name, **values):
    row = {'event': name, 'utc': time.time(), **values}
    result['events'].append(row)
    c.client.append(row)
    print(json.dumps(row), flush=True)

try:
    c.start()
    result['ready_utc'] = time.time()
    result['initial_identities'] = [json.loads(c.node_pid(i)) for i in range(3)]
    expected = json.loads((Path(__file__).parent / 'variants.json').read_text())['after']['hashes']
    for identity in result['initial_identities']:
        for key, name in [('runtime', 'SlimFaas'), ('slimfaas_dll', 'SlimFaas.dll'), ('slimdata_dll', 'SlimData.dll')]:
            assert identity['binaries_sha256'][name] == expected[key]
    ingress = c.leader()
    assert ingress is not None
    for i in range(3):
        if i == ingress: continue
        root = c.node_state_directory(i) / 'files'
        permissions.append((root, stat.S_IMODE(root.stat().st_mode)))
        root.chmod(0o500)
    event('remote-files-writes-denied', ingress=ingress, directories=[str(r) for r, _ in permissions])
    result['workload_started'] = True
    c.phase = 'no-remote-copy-with-healthy-raft'
    body = bytes(range(251)) * (extra.payload_bytes // 251) + bytes(range(251))[:extra.payload_bytes % 251]
    public_id = 'no-remote-' + os.urandom(8).hex()
    attempts = []
    for kind, path in [('async', '/async-function/chaos/no-remote'), ('file', '/data/files?id=' + public_id)]:
        status, _, _, identifier = c.mutate(kind, path, body, port=c.ports[ingress], timeout=15, chunked=extra.chunked)
        attempts.append({'kind': kind, 'status': status, 'id': identifier})
        assert status == 503, attempts
    # Prove a fresh consensus mutation still succeeds while Files writes fail.
    c.require_mutation('set', '/data/sets/no-remote-raft-control', b'quorum-remains-writable', port=c.ports[ingress])
    event('both-body-publications-unconfirmed', attempts=attempts, raft_write_succeeded=True)
    result['attempts'] = attempts
    for root, mode in permissions: root.chmod(mode)
    permissions.clear()
    event('remote-files-permissions-restored')
    started = time.monotonic()
    while time.monotonic() - started < 180:
        rows = local.read_receipts(c.receipts)
        assert not rows, rows
        time.sleep(.25)
    result['observed_after_send_seconds'] = time.monotonic() - started
    for port in c.ports:
        assert local.request(port, '/data/files/' + public_id, timeout=5)[0] == 404
    result['remaining_local_bodies'] = {str(i): [f.name for f in (c.node_state_directory(i) / 'files').glob('*.bin')] for i in range(3)}
    assert all(not files for files in result['remaining_local_bodies'].values()), result['remaining_local_bodies']
    result['accounting'] = c.audit()
    result['accepted'] = len(c.accepted)
    result['unknown_count'] = len(c.unknown)
    result['final_identities'] = [json.loads(c.node_pid(i)) for i in range(3)]
    assert result['initial_identities'] == result['final_identities']
    c.capture('final')
    result['passed'] = True
except Exception:
    result['error'] = traceback.format_exc()
finally:
    for root, mode in permissions:
        try: root.chmod(mode)
        except Exception as error: result.setdefault('restore_errors', []).append(repr(error))
    result['finished_utc'] = time.time()
    (c.output / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['events','initial_identities','final_identities']}), flush=True)
raise SystemExit(0 if result['passed'] else 1)
