Reproduce from a fresh isolated checkout of f13e8a60ad3f02b987eda45e1459787418a4999c, with .NET11 and Node26.
Extract this archive into a NEW directory. Copy source-reproduction/tests/ into the checkout tests/ (preserving paths).
Before applying product-fix.patch, run:
dotnet test tests/SlimFaas.Tests/SlimFaas.Tests.csproj -p:SkipClientAppBuild=true -nr:false --filter FullyQualifiedName~Root_formatter_registration_window
dotnet test tests/SlimData.Tests/SlimData.Tests.csproj -nr:false --filter FullyQualifiedName~Admission_result_publication_does_not_use_a_pending_root_formatter
Expect14 failing client cases and1 failing server case. Four client response cases reach the12s test deadline through the existing retry path.
Then git apply product-fix.patch and rerun both commands; all15 pass. Existing six replay controls also pass.
The frozen Kubernetes profiles record five passing source189 controls and all four healthy same-guarantee source511/source189/source189/source511 observations. The earlier failed reference remains in the separate original root-registration archive. Use NEW owned namespace prefixes/VM roots before replay; never bootstrap or modify the retained originals. Images/source hashes remain in variants.json and original reports.
