namespace SlimFaas.Tests.Integration;

internal static class RaftMembershipBootstrap
{
    internal static async Task SeedAsync(Func<Task> write, Action leadershipChanged, CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(write);
        ArgumentNullException.ThrowIfNull(leadershipChanged);
        token.ThrowIfCancellationRequested();
        await write();
    }
}
