from pathlib import Path
import json,subprocess,time
ROOT=Path.cwd();E=ROOT/'artifacts/pr506';SHA='189826231fe43fe3069e8a1f7724f83589432c6f';IMAGE='localhost/slimfaas-pr506:after-tools-net11-71';KCFG=str(E/'kubernetes/kubeconfig');K=['kubectl','--kubeconfig',KCFG,'--context','kind-slimfaas-pr506'];base=['python3','.bin/run-kubernetes-campaign.py']
with(E/'logs/net11-189-105-fault-controls.log').open('w')as log:subprocess.run(['python3',str(E/'run-net11-189-105-fault-controls.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
vm='/var/home/core/slimfaas-pr506/podman/linux-final-net11-189-105-01';subprocess.run(['podman','machine','ssh','mkdir','-p',vm],check=True);subprocess.run(['podman','machine','ssh','chmod','0777',vm],check=True)
command=['podman','run','--rm','--name','slimfaas-pr506-linux-final-net11-189-105-01','--user','1000:1000','--cpus','4','--memory','8g','--volume',vm+':/evidence:Z','--entrypoint','python3',IMAGE,'/src/.bin/test-slimdata-local-chaos.py','--runtime','/app/SlimFaas','--source-commit',SHA,'--output','/evidence/campaign','--recovery-timeout','180','--scenarios','protocol-timeout,payloads,api,files,wake,retries,streams,schedules,job-environments,job-recovery,startup-jobs,job-during-node-stop,websocket,websocket-timeout,lease-burst,leader-route,chaos,restarts','--request-timeout','120']
with(E/'logs/linux-final-net11-189-105-01.log').open('w')as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
with(E/'logs/linux-dotnet-sdk-net11-189-105-01.log').open('w')as log:subprocess.run(['python3',str(E/'linux-dotnet-sdk-net11-189-105-01.py')],stdout=log,stderr=subprocess.STDOUT,check=True)

def campaign(name,scenarios,profile='endurance',extra=(),stop=True):
 ns='slimfaas-pr506-'+name;out=E/'kubernetes'/name;args=['--kubeconfig',KCFG,'--namespace',ns,'--output',str(out)]
 with(E/'logs'/('kubernetes-'+name+'.log')).open('w')as log:
  subprocess.run(base+['launch']+args+['--image',IMAGE,'--controller-image',IMAGE,'--source-commit',SHA,'--probes',profile,'--recovery-timeout','180','--scenarios',scenarios]+list(extra),stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(base+['wait']+args+['--timeout','1800'],stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(base+['collect']+args,stdout=log,stderr=subprocess.STDOUT,check=True)
  if stop:subprocess.run(base+['stop']+args,stdout=log,stderr=subprocess.STDOUT,check=True)
 return ns,out
campaign('net11-189-105-quick-01','payloads,api,files,retries,job-during-node-stop,lease-burst,leader-route,chaos,restarts','normal')
campaign('net11-189-105-protocol-01','api,protocol-timeout,restarts')
campaign('net11-189-105-python-01','api,wake,streams,schedules,websocket,websocket-timeout,lease-burst,leader-route,restarts',extra=['--request-timeout','120'])
ns,out=campaign('net11-189-105-dotnet-01','api','normal',stop=False)
with(E/'logs/kubernetes-net11-189-105-dotnet-sdk-01.log').open('w')as log:
 subprocess.run(['python3','.bin/test-dotnet-sdk-kubernetes.py','--kubeconfig',KCFG,'--namespace',ns,'--image',IMAGE,'--worker-image','localhost/slimfaas-pr506:dotnet-worker-net11-01','--output',str(out/'sdk')],stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(base+['stop','--kubeconfig',KCFG,'--namespace',ns,'--output',str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
(E/'preflight/net11-189-105-container-short-controls.json').write_text(json.dumps({'passed':True,'source':SHA,'finished':time.time()},indent=2)+'\n')
