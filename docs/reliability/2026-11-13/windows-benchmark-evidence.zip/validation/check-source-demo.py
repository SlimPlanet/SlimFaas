import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
from urllib.request import build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/windows-benchmark'
NATIVE = OUT / 'native-final/SlimFaas.exe'
ENV = os.environ.copy()
ENV['DOTNET_ROOT'] = r'C:\tools\slimfaas-dotnet-11'
ENV['PATH'] = ENV['DOTNET_ROOT'] + os.pathsep + ENV['PATH']
HTTP = build_opener(ProxyHandler({}))
ports = [30020, 30021, 30022, 30023, 3262, 3263, 3264]
for port in ports:
    with socket.socket() as probe:
        if probe.connect_ex(('127.0.0.1', port)) == 0:
            raise RuntimeError('Source demo port is occupied: ' + str(port))
subprocess.run([str(NATIVE), 'local', 'validate', '-f', str(ROOT / 'slimfaas.local.yaml')],
               cwd=ROOT, env=ENV, check=True)
result = {'passed': False}
with (OUT / 'source-demo.log').open('wb') as log:
    process = subprocess.Popen([str(NATIVE), 'local', 'up', '-f', str(ROOT / 'slimfaas.local.yaml')],
                               cwd=ROOT, env=ENV, stdout=log, stderr=subprocess.STDOUT,
                               creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
    try:
        deadline = time.monotonic() + 300
        while True:
            if process.poll() is not None:
                raise RuntimeError('Source demo supervisor exited before readiness')
            try:
                with HTTP.open('http://127.0.0.1:30020/ready', timeout=2) as response:
                    if response.status == 200:
                        break
            except OSError:
                pass
            if time.monotonic() >= deadline:
                raise TimeoutError('Source demo readiness deadline')
            time.sleep(.2)
        with HTTP.open('http://127.0.0.1:30020/status-functions', timeout=5) as response:
            status = response.read()
            assert response.status == 200 and b'fibonacci1' in status
            (OUT / 'source-demo-status.json').write_bytes(status)
        with HTTP.open('http://127.0.0.1:30020/function/fibonacci1/hello/local', timeout=180) as response:
            body = response.read()
            assert response.status == 200 and body == b'Hello local!'
            result.update({'passed': True, 'function_status': response.status, 'body': body.decode()})
    finally:
        if process.poll() is None:
            process.send_signal(signal.CTRL_BREAK_EVENT)
            try:
                process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                result['passed'] = False
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], check=True)
                raise
        (OUT / 'source-demo-result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
