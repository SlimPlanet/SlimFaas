import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / 'artifacts/windows-benchmark'
DEST = ROOT / 'docs/reliability/2026-11-13'
BASE = 'a8b5a34e4a31ecf8f8bc0ded658b704b4e2afca2'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def hash_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

archive = {}
runs = []
names = ['ci-a8b5a34e/websocket', 'before-websocket', 'control-private-websocket',
         'private-diagnostic', 'control-direct-websocket', 'control-chunk-websocket']
if (RAW / 'final-validation.json').exists():
    names += [row['name'] for row in json.loads((RAW / 'final-validation.json').read_text())]
for name in names:
    folder = RAW / name
    if not (folder / 'report.json').is_file():
        continue
    files = list(folder.glob('*.json')) + list(folder.glob('*.jsonl')) + list(folder.glob('*.prom'))
    files += list(folder.glob('*.log')) + list(folder.glob('*.yaml')) + list(folder.glob('*.py'))
    files += list((folder / 'receipts').glob('*.jsonl'))
    for path in files:
        archive['runs/' + name + '/' + path.relative_to(folder).as_posix()] = path
    rows = [json.loads(line) for line in (folder / 'client.jsonl').read_text().splitlines()]
    initial_streams = [row['seconds'] for row in rows if row.get('kind') == 'stream'
                       and row['event'] == 'accepted' and row['phase'] == 'websocket-cross-node']
    markers = list((folder / 'state/data').glob('*/wal/slimdata-chunk-size'))
    runs.append({'name': name, 'parameters': json.loads((folder / 'parameters.json').read_text()),
                 'report': json.loads((folder / 'report.json').read_text()),
                 'initial_stream_seconds': initial_streams,
                 'markers': {path.relative_to(folder).as_posix(): path.read_text() for path in markers},
                 'raw_state': 'Preserved locally; WAL/snapshot files and heap dumps are not included in the compact archive.'})

for pattern in ('*.log', '*stack*.txt', '*runtime.patch', 'final-validation.json', 'source-demo*.json',
                '*.py', 'run-http-smoke.ps1', 'final-http.exit'):
    for path in RAW.glob(pattern):
        archive['validation/' + path.name] = path
for path in (RAW / 'private-diagnostic').glob('async-node-*.txt'):
    archive['validation/' + path.name] = path
for path in (RAW / 'final-http').glob('*'):
    if path.is_file():
        archive['http/' + path.name] = path
sources = ['src/SlimData/Startup.cs', 'src/SlimData/WalChunkSize.cs', 'tests/SlimData.Tests/WalChunkSizeTests.cs',
           '.bin/test-slimdata-local-chaos.py', 'tests/SlimFaas.Tests/Local/chaos_function.py',
           '.bin/slimfaas-local-benchmark.sh', '.bin/run-local-benchmark-host.py',
           'benchmarks/slimfaas.local.benchmark.yaml',
           'global.json', 'Directory.Build.props', 'Directory.Build.targets', 'Directory.Packages.props']
for name in sources:
    archive['source/' + name] = ROOT / name

binary_paths = ['runtime-reference/SlimFaas.dll', 'runtime-reference/SlimData.dll',
                'runtime-direct/SlimData.dll', 'runtime-chunk/SlimData.dll', 'native-final/SlimFaas.exe']
binaries = {name: {'sha256': hash_file(RAW / name), 'bytes': (RAW / name).stat().st_size}
            for name in binary_paths if (RAW / name).is_file()}
for name in ('src/SlimFaas/bin/Release/net11.0/SlimFaas.dll', 'src/SlimFaas/bin/Release/net11.0/SlimData.dll'):
    binaries[name] = {'sha256': hash_file(ROOT / name), 'bytes': (ROOT / name).stat().st_size}

zip_path = DEST / 'windows-benchmark-evidence.zip'
index = []
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, path in sorted(archive.items()):
        data = path.read_bytes()
        output.writestr(name, data)
        index.append({'path': name, 'bytes': len(data), 'sha256': digest(data)})

solution_tests = []
for path in sorted(RAW.glob('full-tests*.log')):
    contents = path.read_text(encoding='utf-8', errors='replace')
    summaries = re.findall(r'(?:Réussi!|Échoué!).*échec\s*:\s*(\d+), réussite\s*:\s*(\d+).*total\s*:\s*(\d+).*?-\s*(\S+\.Tests\.dll)', contents)
    solution_tests.append({'log': path.name, 'suites': [
        {'suite': suite, 'failed': int(failed), 'passed': int(passed), 'total': int(total)}
        for failed, passed, total, suite in summaries]})
http = json.loads((RAW / 'final-http/results.json').read_text())
http_summary = {'measured_cases': len(http['LatencyRuns']),
                'failed_requests': sum(row['Failed'] for row in http['LatencyRuns']),
                'missing_async': sum(row['AsyncMissing'] for row in http['LatencyRuns']),
                'duplicate_async': sum(row['AsyncDuplicates'] for row in http['LatencyRuns']),
                'settings': http['Settings'], 'scaling': http['Scaling']}
document = {'schema': 1, 'base_commit': BASE, 'host': platform.platform(),
            'toolchain': {'sdk': '11.0.100', 'framework': '.NET 11', 'final_python': '3.11.5',
                          'initial_diagnostic_python': '3.12.11', 'websockets': '16.1.1',
                          'documentation_node': '24.21.0', 'documentation_pnpm': '12.18.0'},
            'provenance': 'Candidate binaries were built from the base commit plus the retained final-runtime.patch; the working tree was uncommitted during validation.',
            'runtime_patch_sha256': hash_file(RAW / 'final-runtime.patch'),
            'source_sha256': {name: hash_file(ROOT / name) for name in sources},
            'binaries': binaries, 'runs': runs, 'solution_tests': solution_tests,
            'http_smoke': http_summary,
            'source_demo': json.loads((RAW / 'source-demo-result.json').read_text()),
            'diagnostic_variants': {
                'before-websocket': 'Unmodified source; Python 3.12.11; managed.',
                'control-private-websocket': 'Unmodified source with explicit PrivateMemory; managed.',
                'private-diagnostic': 'Explicit PrivateMemory, Information logging and intrusive heap captures; diagnostic only.',
                'control-direct-websocket': 'Base Startup with NoBuffering=OperatingSystem.IsWindows(), explicit PrivateMemory; managed.',
                'control-chunk-websocket': 'Base Startup with ChunkSize=OperatingSystem.IsWindows()?65536:Environment.SystemPageSize; managed, unmarked experimental volumes.'},
            'validation_commands': json.loads((RAW / 'final-validation.json').read_text())
                if (RAW / 'final-validation.json').exists() else [],
            'archive': {'path': zip_path.name, 'bytes': zip_path.stat().st_size,
                        'sha256': hash_file(zip_path), 'files': index}}
(DEST / 'windows-benchmark.json').write_text(json.dumps(document, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'runs': len(runs), 'archive_files': len(index), 'archive_bytes': zip_path.stat().st_size}))
