import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/windows-benchmark'
PYTHON = ROOT / 'client/python/slimfaas-client/.venv/Scripts/python.exe'
HARNESS = ROOT / '.bin/test-slimdata-local-chaos.py'
NATIVE = OUT / 'native-final/SlimFaas.exe'
environment = os.environ.copy()
environment['DOTNET_ROOT'] = r'C:\tools\slimfaas-dotnet-11'
environment['PATH'] = environment['DOTNET_ROOT'] + os.pathsep + environment['PATH']
environment['PYTHONPATH'] = str(ROOT / 'client/python/slimfaas-client/src')

cases = [
    ('reference-payloads-311', OUT / 'runtime-reference/SlimFaas.dll',
     ['--scenarios', 'payloads'], False),
    ('final-managed-websocket', ROOT / 'src/SlimFaas/bin/Release/net11.0/SlimFaas.dll',
     ['--scenarios', 'websocket', '--delivery-diagnostics', '--request-timeout', '120', '--recovery-timeout', '300'], True),
    ('final-native-quick', NATIVE, ['--durations', '1,5,10'], True),
    ('final-native-websocket', NATIVE,
     ['--scenarios', 'websocket', '--delivery-diagnostics', '--request-timeout', '120', '--recovery-timeout', '300'], True),
    ('final-native-owner-timeout', NATIVE,
     ['--scenarios', 'websocket-timeout', '--delivery-diagnostics', '--request-timeout', '30', '--recovery-timeout', '60'], True),
    ('final-native-lease', NATIVE,
     ['--scenarios', 'lease-burst,leader-route,protocol-timeout', '--request-timeout', '15', '--recovery-timeout', '180'], True),
]

results = []
for name, runtime, arguments, must_pass in cases:
    started = time.time()
    command = [str(PYTHON), str(HARNESS), '--runtime', str(runtime), '--output', str(OUT / name)] + arguments
    print('Starting ' + name, flush=True)
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
    results.append({'name': name, 'command': command, 'started_utc_epoch': started,
                    'finished_utc_epoch': time.time(), 'exit_code': result.returncode, 'must_pass': must_pass})
    (OUT / 'final-validation.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(name + ': exit ' + str(result.returncode), flush=True)

sys.exit(1 if any(row['must_pass'] and row['exit_code'] != 0 for row in results) else 0)
