$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\github\SlimFaas-pr506-windows'
$env:DOTNET_ROOT = 'C:\tools\slimfaas-dotnet-11'
$env:PATH = "$env:DOTNET_ROOT;$env:PATH"
$env:BENCHMARK_PROFILE = 'quick'
$env:BENCHMARK_SKIP_BUILD = 'true'
$env:BENCHMARK_RUNTIME = 'C:/github/SlimFaas-pr506-windows/artifacts/windows-benchmark/native-final/SlimFaas.exe'
$env:BENCHMARK_RUNTIME_MODE = 'aot'
$env:BENCHMARK_RUN_ROOT = 'C:/github/SlimFaas-pr506-windows/artifacts/windows-benchmark/final-http'
Set-Location -LiteralPath $taskRoot
& 'C:\Program Files\Git\bin\bash.exe' .bin/slimfaas-local-benchmark.sh *> artifacts/windows-benchmark/final-http.log
$taskHttpExit = $LASTEXITCODE
Set-Content -LiteralPath artifacts/windows-benchmark/final-http.exit -Value $taskHttpExit
Get-Content artifacts/windows-benchmark/final-http.log -Tail 20
exit $taskHttpExit
