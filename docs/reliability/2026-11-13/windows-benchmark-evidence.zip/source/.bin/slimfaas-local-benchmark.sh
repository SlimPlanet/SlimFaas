#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
profile="${BENCHMARK_PROFILE:-standard}"
run_profile="standard"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
run_root="${BENCHMARK_RUN_ROOT:-$repo_root/artifacts/slimfaas-local-benchmark/$profile-$timestamp}"
manifest="$repo_root/benchmarks/slimfaas.local.benchmark.yaml"
slimfaas_project="$repo_root/src/SlimFaas/SlimFaas.csproj"
benchmark_project="$repo_root/benchmarks/SlimFaasBenchmark/SlimFaasBenchmark.csproj"
slimfaas_dll="${BENCHMARK_RUNTIME:-${BENCHMARK_RUNTIME_PATH:-${BENCHMARK_SLIMFAAS_DLL:-$repo_root/src/SlimFaas/bin/Release/net11.0/SlimFaas.dll}}}"
if [[ "$slimfaas_dll" == *.dll ]]; then
  slimfaas_command=(dotnet "$slimfaas_dll")
else
  slimfaas_command=("$slimfaas_dll")
fi
benchmark_dll="$repo_root/benchmarks/SlimFaasBenchmark/bin/Release/net11.0/SlimFaasBenchmark.dll"
local_log="$run_root/slimfaas-local.log"
if [[ "$OSTYPE" == msys* || "$OSTYPE" == cygwin* ]]; then
  slimfaas_command=(python "$repo_root/.bin/run-local-benchmark-host.py" --ports 31020,31021,31022,31023,3162,3163,3164,31080,32000,32001,32002,32003,32004,32005,32006,32007,32008,32009,32010,32011,32012,32013,32014,32015 "${slimfaas_command[@]}")
fi

case "$profile" in
  quick)
    duration_seconds="${BENCHMARK_DURATION_SECONDS:-3}"
    warmup_seconds="${BENCHMARK_WARMUP_SECONDS:-1}"
    repetitions="${BENCHMARK_REPETITIONS:-1}"
    ;;
  standard)
    duration_seconds="${BENCHMARK_DURATION_SECONDS:-10}"
    warmup_seconds="${BENCHMARK_WARMUP_SECONDS:-2}"
    repetitions="${BENCHMARK_REPETITIONS:-3}"
    ;;
  async-queue)
    run_profile="async-queue"
    duration_seconds="${BENCHMARK_DURATION_SECONDS:-10}"
    warmup_seconds="${BENCHMARK_WARMUP_SECONDS:-2}"
    repetitions="${BENCHMARK_REPETITIONS:-3}"
    ;;
  *)
    echo "BENCHMARK_PROFILE must be quick, standard, or async-queue" >&2
    exit 2
    ;;
esac

payload_bytes="${BENCHMARK_PAYLOAD_BYTES:-64,4096,262144,2097152}"
concurrency="${BENCHMARK_CONCURRENCY:-1,16}"
scale_messages="${BENCHMARK_SCALE_MESSAGES:-200}"
scale_concurrency="${BENCHMARK_SCALE_CONCURRENCY:-32}"
scale_timeout="${BENCHMARK_SCALE_TIMEOUT_SECONDS:-120}"
async_drain_timeout="${BENCHMARK_ASYNC_DRAIN_TIMEOUT_SECONDS:-180}"
async_paced_messages="${BENCHMARK_ASYNC_PACED_MESSAGES:-100}"
async_paced_interval_ms="${BENCHMARK_ASYNC_PACED_INTERVAL_MS:-100}"
async_burst_messages="${BENCHMARK_ASYNC_BURST_MESSAGES:-1000}"
async_burst_concurrency="${BENCHMARK_ASYNC_BURST_CONCURRENCY:-64}"

mkdir -p "$run_root"

if [[ "${BENCHMARK_SKIP_BUILD:-false}" == "true" ]]; then
  echo "Skipping build; using existing Release binaries"
else
  echo "Building SlimFaas and the benchmark target/driver"
  dotnet build "$slimfaas_project" -c Release -p:SkipClientAppBuild=true --nologo
  dotnet build "$benchmark_project" -c Release --nologo
fi

"${slimfaas_command[@]}" local validate -f "$manifest"

{
  echo "started_at=$timestamp"
  echo "profile=$profile"
  echo "commit=$(git -C "$repo_root" rev-parse HEAD)"
  echo "worktree_dirty=$(git -C "$repo_root" status --porcelain | grep -q . && echo true || echo false)"
  echo "dotnet_sdk=$(dotnet --version)"
  echo "runtime=$slimfaas_dll"
  echo "local_manifest=$manifest"
  echo "local_manifest_sha256=$(sha256sum "$manifest" | cut -d ' ' -f 1)"
  echo "runtime_sha256=$(sha256sum "$slimfaas_dll" | cut -d ' ' -f 1)"
  echo "host=$(uname -s)-$(uname -m)"
  echo "runtime_path=$slimfaas_dll"
  echo "runtime_mode=${BENCHMARK_RUNTIME_MODE:-jit}"
  echo "duration_seconds=$duration_seconds"
  echo "warmup_seconds=$warmup_seconds"
  echo "repetitions=$repetitions"
  echo "payload_bytes=$payload_bytes"
  echo "concurrency=$concurrency"
  echo "scale_messages=$scale_messages"
  echo "scale_concurrency=$scale_concurrency"
  echo "async_paced_messages=$async_paced_messages"
  echo "async_paced_interval_ms=$async_paced_interval_ms"
  echo "async_burst_messages=$async_burst_messages"
  echo "async_burst_concurrency=$async_burst_concurrency"
} >"$run_root/benchmark-manifest.txt"

local_pid=""
cleanup() {
  if [[ -n "$local_pid" ]] && kill -0 "$local_pid" 2>/dev/null; then
    kill -TERM "$local_pid" 2>/dev/null || true
    for _ in $(seq 1 100); do
      if ! kill -0 "$local_pid" 2>/dev/null; then
        break
      fi
      sleep 0.1
    done
    if kill -0 "$local_pid" 2>/dev/null; then
      kill -KILL "$local_pid" 2>/dev/null || true
    fi
    wait "$local_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT
trap 'exit 130' INT TERM

echo "Starting the three-node native local cluster"
(
  cd "$repo_root"
  exec "${slimfaas_command[@]}" local up -f "$manifest" --clean
) >"$local_log" 2>&1 &
local_pid="$!"

ready=0
for attempt in $(seq 1 180); do
  if ! kill -0 "$local_pid" 2>/dev/null; then
    echo "slimfaas local exited before readiness; see $local_log" >&2
    exit 1
  fi
  if curl --silent --fail "http://127.0.0.1:31020/ready" >/dev/null &&
     curl --silent --fail "http://127.0.0.1:31080/health" >/dev/null; then
    ready=1
    break
  fi
  if (( attempt % 10 == 0 )); then
    echo "Waiting for cluster and direct target readiness (${attempt}s)"
  fi
  sleep 1
done
if [[ "$ready" != "1" ]]; then
  echo "Benchmark environment did not become ready; see $local_log" >&2
  exit 1
fi

dotnet "$benchmark_dll" run \
  --profile "$run_profile" \
  --slimfaas-url http://127.0.0.1:31020 \
  --direct-url http://127.0.0.1:31080 \
  --node-urls http://127.0.0.1:31021,http://127.0.0.1:31022,http://127.0.0.1:31023 \
  --duration "$duration_seconds" \
  --warmup "$warmup_seconds" \
  --repetitions "$repetitions" \
  --payload-bytes "$payload_bytes" \
  --concurrency "$concurrency" \
  --async-drain-timeout "$async_drain_timeout" \
  --scale-messages "$scale_messages" \
  --scale-concurrency "$scale_concurrency" \
  --scale-timeout "$scale_timeout" \
  --async-paced-messages "$async_paced_messages" \
  --async-paced-interval-ms "$async_paced_interval_ms" \
  --async-burst-messages "$async_burst_messages" \
  --async-burst-concurrency "$async_burst_concurrency" \
  --output "$run_root"

echo "SlimFaas local benchmark artifacts: $run_root"
