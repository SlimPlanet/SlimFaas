# SlimFaas local latency and scaling benchmark

Generated at `2026-11-13T23:27:39.3967967+00:00` on `Microsoft Windows NT 10.0.26300.0` with `.NET 11.0.0`.

## Runtime process resources

CPU and sampled peak working set are summed across all configured runtime nodes, excluding the local supervisor, target and load generator. Direct-route rows measure idle runtime activity, not target CPU. Sampling is every 500 ms; async measurements include queue drain. Values are medians across repetitions.

| mode | payload | concurrency | CPU/request | sampled peak working set |
|---|---:|---:|---:|---:|
| direct | 64 B | 1 | 0.161 ms | 178.0 MiB |
| sync | 64 B | 1 | 2.095 ms | 185.2 MiB |
| async | 64 B | 1 | 29.930 ms | 199.6 MiB |
| sync | 64 B | 16 | 1.106 ms | 217.9 MiB |
| direct | 64 B | 16 | 0.023 ms | 213.4 MiB |
| async | 64 B | 16 | 4.182 ms | 238.4 MiB |
| direct | 4 KiB | 1 | 0.127 ms | 243.0 MiB |
| sync | 4 KiB | 1 | 1.980 ms | 246.9 MiB |
| async | 4 KiB | 1 | 26.159 ms | 257.7 MiB |
| sync | 4 KiB | 16 | 1.198 ms | 268.5 MiB |
| direct | 4 KiB | 16 | 0.009 ms | 268.5 MiB |
| async | 4 KiB | 16 | 4.686 ms | 303.6 MiB |
| direct | 256 KiB | 1 | 0.552 ms | 302.4 MiB |
| sync | 256 KiB | 1 | 6.772 ms | 302.8 MiB |
| async | 256 KiB | 1 | 129.112 ms | 387.5 MiB |
| sync | 256 KiB | 16 | 5.128 ms | 394.6 MiB |
| direct | 256 KiB | 16 | 0.066 ms | 396.0 MiB |
| async | 256 KiB | 16 | 142.157 ms | 640.4 MiB |
| direct | 2 MiB | 1 | 5.777 ms | 640.4 MiB |
| sync | 2 MiB | 1 | 43.658 ms | 640.9 MiB |
| async | 2 MiB | 1 | 255.208 ms | 644.2 MiB |
| sync | 2 MiB | 16 | 31.356 ms | 629.1 MiB |
| direct | 2 MiB | 16 | 0.477 ms | 629.9 MiB |
| async | 2 MiB | 16 | 140.381 ms | 578.7 MiB |

## Synchronous overhead

| payload | concurrency | direct p50 | SlimFaas p50 | added p50 | direct p95 | SlimFaas p95 | added p95 | direct p99 | SlimFaas p99 | added p99 | rate ratio |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 64 B | 1 | 0.917 ms | 2.712 ms | +1.796 ms (+195.9%) | 2.351 ms | 9.393 ms | +7.042 ms (+299.5%) | 5.455 ms | 15.209 ms | +9.754 ms (+178.8%) | 31.6 % |
| 64 B | 16 | 1.383 ms | 6.229 ms | +4.846 ms (+350.3%) | 6.077 ms | 11.312 ms | +5.235 ms (+86.1%) | 10.459 ms | 16.278 ms | +5.819 ms (+55.6%) | 31.5 % |
| 4 KiB | 1 | 0.468 ms | 2.607 ms | +2.140 ms (+457.2%) | 0.868 ms | 6.329 ms | +5.461 ms (+629.0%) | 1.578 ms | 9.735 ms | +8.157 ms (+516.8%) | 16.6 % |
| 4 KiB | 16 | 1.268 ms | 7.134 ms | +5.866 ms (+462.7%) | 2.844 ms | 11.550 ms | +8.706 ms (+306.1%) | 4.202 ms | 14.627 ms | +10.425 ms (+248.1%) | 19.7 % |
| 256 KiB | 1 | 3.025 ms | 4.965 ms | +1.939 ms (+64.1%) | 19.914 ms | 13.228 ms | -6.686 ms (-33.6%) | 26.091 ms | 24.723 ms | -1.369 ms (-5.2%) | 84.7 % |
| 256 KiB | 16 | 6.467 ms | 25.124 ms | +18.657 ms (+288.5%) | 11.723 ms | 34.209 ms | +22.486 ms (+191.8%) | 15.546 ms | 42.894 ms | +27.348 ms (+175.9%) | 27.3 % |
| 2 MiB | 1 | 20.899 ms | 27.904 ms | +7.005 ms (+33.5%) | 43.783 ms | 42.621 ms | -1.161 ms (-2.7%) | 53.182 ms | 48.428 ms | -4.754 ms (-8.9%) | 85.5 % |
| 2 MiB | 16 | 50.503 ms | 165.677 ms | +115.175 ms (+228.1%) | 80.468 ms | 225.824 ms | +145.356 ms (+180.6%) | 107.584 ms | 271.933 ms | +164.349 ms (+152.8%) | 31.2 % |

## Asynchronous ingress and delivery

The HTTP columns measure client-to-202 enqueue latency. Target columns measure client send to handler arrival and completion.

| payload | concurrency | accepted | failed | missing | duplicates | rate | HTTP mean | HTTP p50 | HTTP p95 | HTTP p99 | arrival mean | arrival p50 | arrival p95 | arrival p99 | CPU/msg | Raft/msg |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 64 B | 1 | 71 | 0 | 0 | 0 | 23.6/s | 42.257 ms | 40.616 ms | 64.622 ms | 94.810 ms | 115.557 ms | 109.134 ms | 163.567 ms | 280.532 ms | 33.671 ms | 2.1127 |
| 64 B | 16 | 979 | 0 | 0 | 0 | 324.9/s | 49.082 ms | 36.001 ms | 118.660 ms | 183.128 ms | 128.848 ms | 109.197 ms | 257.604 ms | 363.667 ms | 0.000 ms | 0.0000 |
| 4 KiB | 1 | 89 | 0 | 0 | 0 | 29.5/s | 33.916 ms | 31.959 ms | 48.267 ms | 54.353 ms | 90.759 ms | 91.457 ms | 130.332 ms | 145.146 ms | 33.181 ms | 0.8539 |
| 4 KiB | 16 | 1117 | 0 | 0 | 0 | 368.6/s | 43.187 ms | 45.207 ms | 53.099 ms | 57.621 ms | 122.238 ms | 122.942 ms | 165.029 ms | 182.571 ms | 3.203 ms | 0.0922 |
| 256 KiB | 1 | 38 | 0 | 0 | 0 | 12.0/s | 83.046 ms | 74.586 ms | 128.131 ms | 198.290 ms | 253.620 ms | 252.271 ms | 371.068 ms | 502.872 ms | 152.961 ms | 1.3421 |
| 256 KiB | 16 | 51 | 0 | 0 | 0 | 10.4/s | 1361.345 ms | 915.152 ms | 2635.724 ms | 2636.568 ms | 2981.124 ms | 3113.269 ms | 4336.749 ms | 4682.163 ms | 183.211 ms | 0.5098 |
| 2 MiB | 1 | 21 | 0 | 0 | 0 | 6.9/s | 143.882 ms | 133.952 ms | 193.927 ms | 226.891 ms | 176.896 ms | 171.982 ms | 219.220 ms | 268.819 ms | 290.923 ms | 4.4286 |
| 2 MiB | 16 | 64 | 0 | 0 | 0 | 16.7/s | 885.974 ms | 860.788 ms | 1329.939 ms | 1655.898 ms | 2424.648 ms | 2522.124 ms | 2807.537 ms | 2973.757 ms | 112.061 ms | 0.5938 |

## Scaling burst

Burst: `200` messages, concurrency `32`, target `4` replicas.

| milestone from first send | observed time |
|---|---:|
| first HTTP 202 | 82.015 ms |
| all HTTP 202 responses | 626.953 ms |
| desired replicas >= 1 | 1091.303 ms |
| ready replicas >= 1 | 4298.839 ms |
| desired replicas >= 4 | 4298.839 ms |
| ready replicas >= 4 | 7474.583 ms |
| queue drained | 23577.391 ms |

Peak observed ready queue: `200`. Timed out: `False`.

## Interpretation boundaries

- Direct and sync calls hit the exact same target process; their delta isolates the warm proxy path on this host.
- Async delivery uses UTC timestamps across local processes and includes enqueue, queue wait, dispatch, and request-body transfer.
- The async payload matrix includes 2 MiB, above SlimFaas' 1 MiB body-offload threshold.
- Scaling uses native local processes. It measures SlimFaas decisions and process readiness, not Kubernetes scheduling or image pulls.
- Function status endpoints have short caches; scaling milestones are observed values rather than internal nanosecond timestamps.
